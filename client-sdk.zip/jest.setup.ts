// packages/client-sdk/jest.setup.ts
import "@testing-library/jest-dom";
import { jest, beforeEach, afterEach } from "@jest/globals";

// Mock fetch globally
global.fetch = jest.fn() as jest.MockedFunction<typeof fetch>;

// Save original process.env
const originalProcessEnv = process.env;

beforeEach(() => {
  // Reset process.env to original state
  process.env = { ...originalProcessEnv };
});

afterEach(() => {
  jest.clearAllMocks();
});

// Mock localStorage
const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
  length: 0,
  key: jest.fn(),
};

Object.defineProperty(window, "localStorage", {
  value: localStorageMock,
});

// Mock sessionStorage
const sessionStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
  length: 0,
  key: jest.fn(),
};

Object.defineProperty(window, "sessionStorage", {
  value: sessionStorageMock,
});

// Mock navigator.sendBeacon
Object.defineProperty(navigator, "sendBeacon", {
  value: jest.fn(() => true),
});

// Mock performance
Object.defineProperty(window, "performance", {
  value: {
    now: jest.fn(() => Date.now()),
    getEntriesByType: jest.fn(() => []),
    memory: {
      usedJSHeapSize: 1000000,
      totalJSHeapSize: 2000000,
      jsHeapSizeLimit: 3000000,
    },
  },
});

// Mock Intl
Object.defineProperty(Intl, "DateTimeFormat", {
  value: jest.fn(() => ({
    resolvedOptions: () => ({ timezone: "UTC" }),
  })),
});

// Mock Screen
Object.defineProperty(window, "screen", {
  value: {
    width: 1920,
    height: 1080,
  },
});

// Mock navigator
Object.defineProperty(window.navigator, "userAgent", {
  value: "jest-test-user-agent",
});

Object.defineProperty(window.navigator, "language", {
  value: "en-US",
});

// Add Response constructor for fetch mocking
global.Response = class Response {
  constructor(
    public body?: BodyInit | null,
    public init?: ResponseInit,
  ) {}

  static error = jest.fn();
  static json = jest.fn();
  static redirect = jest.fn();
} as any;

// Add AbortController for fetch timeout testing
global.AbortController = class AbortController {
  signal: AbortSignal;

  // NOTE: must live on the instance (not a constructor-local const) so both
  // the signal object built in the constructor AND the abort() field method
  // below can see the same array. Previously this was a constructor-local
  // `const listeners`, which the abort() class field could not reach — so
  // addEventListener('abort', cb) subscribers were silently never notified,
  // only signal.onabort was. Both are standard AbortSignal usage patterns.
  private listeners: EventListener[] = [];

  constructor() {
    const listeners = this.listeners;

    // A minimal AbortSignal-compatible object
    const signal = {
      aborted: false,
      onabort: null as ((this: AbortSignal, ev: Event) => any) | null,
      reason: undefined as any,

      addEventListener: (
        type: string,
        cb: EventListenerOrEventListenerObject | null,
      ) => {
        if (cb) {
          listeners.push(cb as EventListener);
        }
      },

      removeEventListener: (
        type: string,
        cb: EventListenerOrEventListenerObject | null,
      ) => {
        const idx = listeners.indexOf(cb as EventListener);

        if (idx >= 0) {
          listeners.splice(idx, 1);
        }
      },

      dispatchEvent: (_event: Event) => false,
    } as unknown as AbortSignal;

    this.signal = signal;
  }

  abort = jest.fn((reason?: any) => {
    (this.signal as any).aborted = true;
    (this.signal as any).reason = reason;

    const event = new Event("abort");

    const onabort = (this.signal as any).onabort;

    if (typeof onabort === "function") {
      try {
        onabort.call(this.signal, event);
      } catch {}
    }

    for (const cb of this.listeners.slice()) {
      try {
        (cb as EventListener).call(this.signal, event);
      } catch {}
    }
  });
} as any;

// Stub the 2D canvas context so analytics/fingerprint.ts's canvas-hash
// fingerprinting exercises its real code path under jsdom instead of hitting
// "Not implemented: HTMLCanvasElement.prototype.getContext" and silently
// falling into its catch block on every test run.
HTMLCanvasElement.prototype.getContext = jest.fn(() => ({
  textBaseline: "",
  font: "",
  fillStyle: "",
  fillRect: jest.fn(),
  fillText: jest.fn(),
})) as unknown as typeof HTMLCanvasElement.prototype.getContext;

HTMLCanvasElement.prototype.toDataURL = jest.fn(
  () => "data:image/png;base64,mock",
);
