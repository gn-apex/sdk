//packages/client-sdk/src/types.ts
import { MinimalNexusConfig } from "./config";

// Extend the minimal config to full config
export interface NexusConfig extends MinimalNexusConfig {
  debug?: boolean;
  cacheStrategy?: "memory" | "localStorage" | "none";
  revalidateTime?: number | false;
  timeout?: number;
  retries?: number;
  /** Internal/runtime version; populated automatically. */
  sdkVersion?: string;
  /** GN-Apex owns cache invalidation. Forever is intentional by default. */
  cacheInvalidation?: "platform" | "manual";
  environment?: "development" | "staging" | "production";
  privacy?: { analytics?: boolean; fingerprinting?: boolean; redact?: boolean };
  autoTracking?: boolean;
  publicKeyOnly?: boolean;
}

// Make sure projectId and apiUrl are required in full config
export interface NexusConfig {
  projectId: string;
  apiUrl: string;
}

export interface ContentResponse<T = any> {
  id: string;
  type: string;
  data: T;
  meta: {
    version: number;
    updatedAt: string;
    locale?: string;
    cacheStatus: "hit" | "miss" | "stale";
  };
}

export interface CollectionResponse<T = any> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
  meta?: {
    fetchedAt: string;
    cacheStatus: string;
    filters?: Record<string, any>;
  };
}

export interface CacheMetadata {
  timestamp: number;
  etag?: string;
  expiresAt: number;
  tags: string[];
}

export interface CacheEntry<T = any> {
  data: T;
  metadata: CacheMetadata;
}

export interface CollectionQuery {
  page?: number;
  limit?: number;
  sort?: string;
  order?: "asc" | "desc";
  filter?: Record<string, any>;
  fields?: string[];
  search?: string;
  include?: string[];
}

export interface ErrorResponse {
  code: string;
  message: string;
  details?: any;
  timestamp: string;
}
