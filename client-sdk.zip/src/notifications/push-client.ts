// packages/client-sdk/src/notifications/push-client.ts

import { NexusConfig } from "../types";

export class NexusPushClient {
  private config: NexusConfig;

  constructor(config: NexusConfig) {
    this.config = config;
  }

  /**
   * Helper to convert Base64 VAPID key to Uint8Array for WebPush security
   */
  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding)
      .replace(/\-/g, "+")
      .replace(/_/g, "/");

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  /**
   * Requests browser notification permissions and registers the WebPush subscription
   */
  public async requestSubscription(
    serviceWorkerPath = "/sw.js",
  ): Promise<boolean> {
    if (
      typeof window === "undefined" ||
      !("serviceWorker" in navigator) ||
      !("PushManager" in window)
    ) {
      console.warn(
        "[GnApex] Push notifications are not supported in this browser environment.",
      );
      return false;
    }

    try {
      // 1. Request Browser Permission
      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        console.warn("[GnApex] Notification permission denied by user.");
        return false;
      }

      // 2. Fetch VAPID Public Key from the NestJS Backend
      const vapidRes = await fetch(
        `${this.config.apiUrl}/notifications/vapid-key`,
        {
          headers: {
            Authorization: `Bearer ${this.config.apiKey}`,
            "x-nexus-project": this.config.projectId,
          },
        },
      );
      if (!vapidRes.ok) throw new Error("Failed to fetch VAPID public key.");
      const { publicKey } = await vapidRes.json();

      // 3. Register the Service Worker
      const registration =
        await navigator.serviceWorker.register(serviceWorkerPath);
      await navigator.serviceWorker.ready;

      // 4. Subscribe to WebPush via Browser PushManager
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        // 🚀 RESOLVED: Cast as 'any' to bypass strict DOM BufferSource typings
        applicationServerKey: this.urlBase64ToUint8Array(publicKey) as any,
      });

      const rawSub = subscription.toJSON();
      if (!rawSub.endpoint || !rawSub.keys?.auth || !rawSub.keys?.p256dh) {
        throw new Error(
          "Malformed subscription payload received from browser.",
        );
      }

      // 5. Send Credentials to the NestJS Public Push Gateway
      const res = await fetch(
        `${this.config.apiUrl}/notifications/project/${this.config.projectId}/subscribe`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.config.apiKey}`,
            "x-nexus-project": this.config.projectId,
          },
          body: JSON.stringify({
            endpoint: rawSub.endpoint,
            auth: rawSub.keys.auth,
            p256dh: rawSub.keys.p256dh,
            provider: "WEB_PUSH",
          }),
        },
      );

      return res.ok;
    } catch (err) {
      console.error("[GnApex] WebPush subscription failed:", err);
      return false;
    }
  }
}
