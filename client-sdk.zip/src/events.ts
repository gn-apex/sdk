export type NexusEventMap = {
  "request:start": { requestId: string; url: string; method: string };
  "request:end": { requestId: string; url: string; status: number; duration: number };
  "cache:hit": { key: string; stale?: boolean };
  "cache:miss": { key: string };
  "analytics:queued": { count: number };
  "analytics:flushed": { sent: number; remaining: number };
  "content:updated": { type: string; slug?: string; collectionId?: string; id?: string };
  "error": { error: unknown };
};

type Listener<T> = (payload: T) => void;
export class NexusEventBus<M extends Record<string, any> = NexusEventMap> {
  private listeners = new Map<keyof M, Set<Listener<any>>>();
  on<K extends keyof M>(event: K, listener: Listener<M[K]>): () => void {
    const set = this.listeners.get(event) ?? new Set(); set.add(listener); this.listeners.set(event, set);
    return () => set.delete(listener);
  }
  emit<K extends keyof M>(event: K, payload: M[K]) { this.listeners.get(event)?.forEach(l => { try { l(payload); } catch {} }); }
  clear() { this.listeners.clear(); }
}
