// packages/client-sdk/src/components/NexusProvider.tsx

"use client";

import React, {
  createContext,
  useEffect,
  useRef,
  useMemo,
  useState,
  useCallback,
  Suspense,
} from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { nexus } from "../client";
import { AnalyticsEngine } from "../analytics";
import { AuthProvider } from "../auth/context";
import { NexusPushClient } from "../notifications/push-client";

export const NexusContext = createContext<typeof nexus>(nexus);

export interface NexusProviderProps {
  children: React.ReactNode;
  projectId?: string;
  disableAnalytics?: boolean;
  hasConsent?: boolean;
  enableLiveFeed?: boolean;
  onLiveEvent?: (event: LiveAnalyticsEvent) => void;
  autoPromptPush?: boolean;
}

export interface LiveAnalyticsEvent {
  eventType: string;
  projectId: string;
  sessionId: string;
  visitorId: string;
  userId?: string;
  data: {
    event_id: string;
    event_name?: string;
    url: string;
    timestamp: string;
    geo?: Record<string, any>;
    device?: Record<string, any>;
    performance?: Record<string, any>;
    ecommerce?: Record<string, any>;
  };
  timestamp: string;
  sequence: number;
}

interface LiveFeedContextValue {
  latestEvent: LiveAnalyticsEvent | null;
  isConnected: boolean;
}

export const NexusLiveFeedContext = createContext<LiveFeedContextValue>({
  latestEvent: null,
  isConnected: false,
});

export const useNexusLiveFeed = () => React.useContext(NexusLiveFeedContext);

function NexusAnalyticsTracker({
  disableAnalytics,
}: {
  disableAnalytics: boolean;
}) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const prevPathRef = useRef<string>("");
  const searchParamsString = searchParams.toString();

  useEffect(() => {
    if (nexus.analytics && !disableAnalytics) {
      nexus.analytics.pageView(prevPathRef.current || document.referrer);
      prevPathRef.current = pathname;
    }
  }, [pathname, searchParamsString, disableAnalytics]);

  return <div id="__nexus_react_active" style={{ display: "none" }} />;
}

export const NexusProvider = ({
  children,
  projectId,
  disableAnalytics = false,
  hasConsent = true,
  enableLiveFeed = false,
  onLiveEvent,
  autoPromptPush = true, // 🚀 Default: true for zero-config automatic visitor subscription
}: NexusProviderProps) => {
  const isInitialized = useRef(false);
  const socketRef = useRef<any>(null);

  const [latestEvent, setLatestEvent] = useState<LiveAnalyticsEvent | null>(
    null,
  );
  const [isConnected, setIsConnected] = useState(false);

  const liveFeedValue = useMemo(
    () => ({ latestEvent, isConnected }),
    [latestEvent, isConnected],
  );

  const config = useMemo(() => {
    if (projectId && nexus.getConfig().projectId !== projectId) {
      nexus.updateConfig({ projectId });
    }
    return nexus.getConfig();
  }, [projectId]);

  // 🚀 1. ZERO-CONFIG: Service Worker Auto-Registration & Push Sync
  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator))
      return;

    // Register our unified sw.js
    navigator.serviceWorker
      .register("/sw.js")
      .then(async (registration) => {
        if (nexus.getConfig().debug) {
          console.log("[GnApex] ⚡ Sovereign Service Worker Active.");
        }

        // Auto-Prompt if enabled (Now default: true)
        if (
          autoPromptPush &&
          "Notification" in window &&
          Notification.permission === "default"
        ) {
          const pushClient = new NexusPushClient(nexus.getConfig());
          await pushClient.requestSubscription("/sw.js");
          return;
        }

        // Silently synchronize subscription if the visitor has already granted permission
        if ("Notification" in window && Notification.permission === "granted") {
          try {
            const pushClient = new NexusPushClient(nexus.getConfig());
            await pushClient.requestSubscription("/sw.js");
          } catch {
            // Silently swallow network timeouts during local dev
          }
        }
      })
      .catch((err) => {
        console.warn("[GnApex] Service Worker registration failed:", err);
      });
  }, [autoPromptPush]);

  // Analytics init
  useEffect(() => {
    if (typeof window === "undefined" || disableAnalytics || !hasConsent)
      return;

    if (!isInitialized.current) {
      if (!nexus.analytics) {
        nexus.analytics = new AnalyticsEngine(nexus.getConfig());
      }
      nexus.analytics.start();
      isInitialized.current = true;

      if (nexus.getConfig().debug) {
        console.log("[GnApex] 🚀 Provider initialized analytics");
      }
    }

    return () => {
      if (nexus.analytics) {
        nexus.analytics.stop();
        isInitialized.current = false;
      }
    };
  }, [disableAnalytics, hasConsent]);

  // WebSocket live feed connection
  const connectLiveFeed = useCallback(async () => {
    if (typeof window === "undefined" || !enableLiveFeed) return;

    try {
      const { io } = await import("socket.io-client");
      const cfg = nexus.getConfig();
      const wsUrl = cfg.apiUrl || "https://gnapex.co.tz";

      const socket = io(`${wsUrl}/analytics`, {
        auth: { token: cfg.apiKey },
        query: { projectId: cfg.projectId },
        transports: ["websocket"],
        reconnectionAttempts: 5,
        reconnectionDelay: 2000,
      });

      socket.on("connect", () => {
        setIsConnected(true);
        if (cfg.debug) console.log("[GnApex] 🔴 Live feed connected");
      });

      socket.on("disconnect", () => {
        setIsConnected(false);
        if (cfg.debug) console.log("[GnApex] Live feed disconnected");
      });

      socket.on("live_event", (event: LiveAnalyticsEvent) => {
        setLatestEvent(event);
        onLiveEvent?.(event);
      });

      socketRef.current = socket;
    } catch (err) {
      console.error("[GnApex] Live feed connection failed:", err);
    }
  }, [enableLiveFeed, onLiveEvent]);

  useEffect(() => {
    if (enableLiveFeed) {
      connectLiveFeed();
    }

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
        setIsConnected(false);
      }
    };
  }, [enableLiveFeed, connectLiveFeed]);

  return (
    <NexusContext.Provider value={nexus}>
      <NexusLiveFeedContext.Provider value={liveFeedValue}>
        <AuthProvider config={config}>
          <Suspense fallback={null}>
            <NexusAnalyticsTracker disableAnalytics={disableAnalytics} />
          </Suspense>
          {children}
        </AuthProvider>
      </NexusLiveFeedContext.Provider>
    </NexusContext.Provider>
  );
};

export const useNexus = () => {
  const context = React.useContext(NexusContext);
  if (!context) {
    throw new Error("useNexus must be used within a NexusProvider");
  }
  return context;
};

export const useNexusAnalytics = () => {
  const client = useNexus();
  if (!client.analytics) {
    return {
      track: () => {},
      identify: async () => false,
      group: async () => false,
      alias: async () => false,
      trackPurchase: () => {},
      trackError: () => {},
      reset: () => {},
    };
  }
  return {
    track: client.analytics.track.bind(client.analytics),
    identify: client.analytics.identify.bind(client.analytics),
    group: client.analytics.group.bind(client.analytics),
    alias: client.analytics.alias.bind(client.analytics),
    trackPurchase: client.analytics.trackPurchase.bind(client.analytics),
    trackError: client.analytics.trackError.bind(client.analytics),
    reset: client.analytics.reset.bind(client.analytics),
  };
};
