// packages/client-sdk/src/components/NexusRenderer.tsx
"use client";

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type MouseEvent,
} from "react";
import { createPortal } from "react-dom";

function cn(...classes: (string | undefined | null | false)[]) {
  return classes.filter(Boolean).join(" ");
}

export interface NexusRendererProps {
  content: string;
  className?: string;
  onCommentClick?: (commentId: string) => void;
  onImageClick?: (src: string, alt?: string) => void;
  hydrateCharts?: boolean;
  enableImageInteraction?: boolean;
  documentClassName?: string;
}

type ChartType = "bar" | "line" | "pie" | "donut" | "area";

interface ChartSeries {
  label: string;
  color: string;
  data: number[];
}

interface ChartAttrs {
  chartType: ChartType;
  title: string;
  categories: string[];
  series: ChartSeries[];
  showLegend: boolean;
  showGrid: boolean;
  width: number;
  height: number;
  sourceNote: string | null;
}

const DEFAULT_CHART: ChartAttrs = {
  chartType: "bar",
  title: "Untitled Chart",
  categories: ["Category A", "Category B", "Category C", "Category D"],
  series: [
    {
      label: "Series 1",
      color: "#6366f1",
      data: [40, 65, 30, 80],
    },
  ],
  showLegend: true,
  showGrid: true,
  width: 560,
  height: 320,
  sourceNote: null,
};

const FALLBACK_CHART_COLORS = [
  "#6366f1",
  "#f97316",
  "#10b981",
  "#ec4899",
  "#0ea5e9",
  "#eab308",
  "#a855f7",
  "#ef4444",
  "#14b8a6",
  "#84cc16",
];

function decodeChartSpec(raw: string | null): ChartAttrs | null {
  if (!raw) return null;
  try {
    const decoded = JSON.parse(
      decodeURIComponent(atob(raw)),
    ) as Partial<ChartAttrs>;
    if (!decoded || typeof decoded !== "object") return null;

    const categories = Array.isArray(decoded.categories)
      ? decoded.categories.map(String)
      : DEFAULT_CHART.categories;

    const series = Array.isArray(decoded.series)
      ? decoded.series.filter(Boolean).map((s, index) => ({
          label: typeof s.label === "string" ? s.label : `Series ${index + 1}`,
          color:
            typeof s.color === "string"
              ? s.color
              : FALLBACK_CHART_COLORS[index % FALLBACK_CHART_COLORS.length],
          data: Array.isArray(s.data)
            ? s.data.map((v) => {
                const n = Number(v);
                return Number.isFinite(n) ? n : 0;
              })
            : [],
        }))
      : DEFAULT_CHART.series;

    return {
      ...DEFAULT_CHART,
      ...decoded,
      categories,
      series: series.length ? series : DEFAULT_CHART.series,
      chartType: (
        ["bar", "line", "pie", "donut", "area"] as ChartType[]
      ).includes(decoded.chartType as ChartType)
        ? (decoded.chartType as ChartType)
        : DEFAULT_CHART.chartType,
      title:
        typeof decoded.title === "string" ? decoded.title : DEFAULT_CHART.title,
      showLegend:
        typeof decoded.showLegend === "boolean"
          ? decoded.showLegend
          : DEFAULT_CHART.showLegend,
      showGrid:
        typeof decoded.showGrid === "boolean"
          ? decoded.showGrid
          : DEFAULT_CHART.showGrid,
      width:
        typeof decoded.width === "number" && decoded.width > 0
          ? decoded.width
          : DEFAULT_CHART.width,
      height:
        typeof decoded.height === "number" && decoded.height > 0
          ? decoded.height
          : DEFAULT_CHART.height,
      sourceNote:
        typeof decoded.sourceNote === "string" ? decoded.sourceNote : null,
    };
  } catch {
    return null;
  }
}

function recoverChartFromElement(element: Element): ChartAttrs {
  const spec = decodeChartSpec(element.getAttribute("data-chart-spec"));
  if (spec) return spec;
  const title = element.getAttribute("data-chart-title") || DEFAULT_CHART.title;
  const chartType = element.getAttribute("data-chart-type") as ChartType | null;

  return {
    ...DEFAULT_CHART,
    title,
    chartType: (
      ["bar", "line", "pie", "donut", "area"] as ChartType[]
    ).includes(chartType as ChartType)
      ? (chartType as ChartType)
      : "bar",
  };
}

// 🛡️ SECURITY FIX: Strip malicious scripts, event handlers, and javascript links
function prepareDocumentHTML(html: string): string {
  if (typeof window === "undefined") return html;
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  doc.querySelectorAll("script, noscript").forEach((node) => node.remove());
  doc.querySelectorAll<HTMLElement>("*").forEach((element) => {
    [...element.attributes].forEach((attr) => {
      if (attr.name.toLowerCase().startsWith("on")) {
        element.removeAttribute(attr.name);
      }
    });

    const href = element.getAttribute("href");
    const src = element.getAttribute("src");
    if (href && /^\s*javascript:/i.test(href)) element.removeAttribute("href");
    if (src && /^\s*javascript:/i.test(src)) element.removeAttribute("src");
  });

  return doc.body.innerHTML;
}

// ─── PURE LIGHTWEIGHT SVG CHART COMPONENT (0-DEPENDENCY) ───────────────────────
function NativeNexusChart({ chart }: { chart: ChartAttrs }) {
  const [hoveredValue, setHoveredValue] = useState<string | null>(null);

  const categories = chart.categories;
  const series = chart.series;

  const allNumbers = series.flatMap((s) => s.data);
  const maxVal = Math.max(...allNumbers, 10);
  const minVal = Math.min(0, ...allNumbers);

  const width = 560;
  const height = Math.max(220, Math.min(chart.height || 300, 450));
  const padLeft = 45;
  const padRight = 20;
  const padTop = 20;
  const padBottom = 35;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const getY = (val: number) => {
    const range = maxVal - minVal;
    return padTop + plotH - ((val - minVal) / range) * plotH;
  };

  const getX = (catIndex: number) => {
    return padLeft + (catIndex / Math.max(categories.length - 1, 1)) * plotW;
  };

  const renderGridAndAxes = () => (
    <>
      {chart.showGrid && (
        <>
          {[0, 0.25, 0.5, 0.75, 1].map((pct, i) => {
            const y = padTop + plotH * (1 - pct);
            const val = Math.round(minVal + (maxVal - minVal) * pct);
            return (
              <g key={`grid-${i}`}>
                <line
                  x1={padLeft}
                  y1={y}
                  x2={width - padRight}
                  y2={y}
                  stroke="currentColor"
                  strokeOpacity={0.08}
                  strokeDasharray="3 3"
                />
                <text
                  x={padLeft - 8}
                  y={y + 3}
                  textAnchor="end"
                  fontSize={10}
                  fill="currentColor"
                  opacity={0.5}
                  className="font-mono"
                >
                  {val}
                </text>
              </g>
            );
          })}
        </>
      )}
      {categories.map((cat, i) => {
        const x = categories.length === 1 ? padLeft + plotW / 2 : getX(i);
        return (
          <text
            key={`cat-${i}`}
            x={x}
            y={height - 10}
            textAnchor="middle"
            fontSize={11}
            fill="currentColor"
            opacity={0.6}
            className="font-mono"
          >
            {cat}
          </text>
        );
      })}
    </>
  );

  const renderBars = () => {
    const groupW = plotW / categories.length;
    const barWidth = Math.max(6, Math.min(28, (groupW * 0.7) / series.length));

    return categories.map((cat, catIdx) => {
      const groupCenterX = padLeft + catIdx * groupW + groupW / 2;
      const startX = groupCenterX - (series.length * barWidth) / 2;

      return series.map((s, sIdx) => {
        const val = s.data[catIdx] || 0;
        const barH = ((val - minVal) / (maxVal - minVal)) * plotH;
        const x = startX + sIdx * barWidth;
        const y = padTop + plotH - barH;

        return (
          <rect
            key={`bar-${catIdx}-${sIdx}`}
            x={x}
            y={y}
            width={barWidth - 2}
            height={Math.max(barH, 2)}
            rx={3}
            fill={s.color}
            opacity={0.9}
            className="transition-all duration-300 hover:opacity-100 cursor-pointer"
            onMouseEnter={() =>
              setHoveredValue(`${cat} • ${s.label}: ${val.toLocaleString()}`)
            }
            onMouseLeave={() => setHoveredValue(null)}
          />
        );
      });
    });
  };

  const renderLinesOrArea = (isArea: boolean) => {
    return series.map((s, sIdx) => {
      const points = s.data
        .map((val, catIdx) => `${getX(catIdx)},${getY(val)}`)
        .join(" ");
      const areaPoints = `${getX(0)},${padTop + plotH} ${points} ${getX(s.data.length - 1)},${padTop + plotH}`;

      return (
        <g key={`series-${sIdx}`}>
          {isArea && (
            <polygon points={areaPoints} fill={s.color} fillOpacity={0.15} />
          )}
          <polyline
            points={points}
            fill="none"
            stroke={s.color}
            strokeWidth={2.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {s.data.map((val, catIdx) => (
            <circle
              key={`dot-${catIdx}`}
              cx={getX(catIdx)}
              cy={getY(val)}
              r={4}
              fill={s.color}
              className="cursor-pointer transition-transform hover:scale-150"
              onMouseEnter={() =>
                setHoveredValue(
                  `${categories[catIdx]} • ${s.label}: ${val.toLocaleString()}`,
                )
              }
              onMouseLeave={() => setHoveredValue(null)}
            />
          ))}
        </g>
      );
    });
  };

  const renderPieOrDonut = () => {
    const s = series[0] || { data: [] };
    const total = s.data.reduce((a, b) => a + (Number(b) || 0), 0) || 1;
    let accumulated = 0;
    const cx = width / 2;
    const cy = height / 2;
    const r = Math.min(cx, cy) - 30;
    const isDonut = chart.chartType === "donut";

    return (
      <g transform={`translate(${cx}, ${cy})`}>
        {categories.map((cat, idx) => {
          const val = s.data[idx] || 0;
          const sliceAngle = (val / total) * 2 * Math.PI;
          const startAngle = accumulated;
          const endAngle = accumulated + sliceAngle;
          accumulated += sliceAngle;

          const x1 = Math.cos(startAngle) * r;
          const y1 = Math.sin(startAngle) * r;
          const x2 = Math.cos(endAngle) * r;
          const y2 = Math.sin(endAngle) * r;
          const largeArc = sliceAngle > Math.PI ? 1 : 0;
          const color =
            FALLBACK_CHART_COLORS[idx % FALLBACK_CHART_COLORS.length];

          return (
            <path
              key={`pie-${idx}`}
              d={`M 0 0 L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`}
              fill={color}
              className="cursor-pointer transition-transform duration-200 hover:scale-105"
              onMouseEnter={() =>
                setHoveredValue(
                  `${cat}: ${val.toLocaleString()} (${Math.round((val / total) * 100)}%)`,
                )
              }
              onMouseLeave={() => setHoveredValue(null)}
            />
          );
        })}
        {isDonut && (
          <circle
            cx={0}
            cy={0}
            r={r * 0.55}
            className="fill-white dark:fill-zinc-900"
          />
        )}
      </g>
    );
  };

  return (
    <figure className="nexus-chart-rendered my-6 w-full rounded-2xl border border-zinc-200 bg-white/70 p-4 backdrop-blur-md dark:border-zinc-800 dark:bg-zinc-900/60">
      <div className="flex items-center justify-between mb-2">
        {chart.title && (
          <figcaption className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
            {chart.title}
          </figcaption>
        )}
        {hoveredValue && (
          <span className="font-mono text-xs font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 px-2 py-0.5 rounded-md">
            {hoveredValue}
          </span>
        )}
      </div>

      <div className="w-full overflow-hidden text-zinc-700 dark:text-zinc-300">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[360px] overflow-visible"
        >
          {chart.chartType === "pie" || chart.chartType === "donut" ? (
            renderPieOrDonut()
          ) : (
            <>
              {renderGridAndAxes()}
              {chart.chartType === "bar" && renderBars()}
              {chart.chartType === "line" && renderLinesOrArea(false)}
              {chart.chartType === "area" && renderLinesOrArea(true)}
            </>
          )}
        </svg>
      </div>

      {chart.showLegend && (
        <div className="flex flex-wrap items-center justify-center gap-3 mt-3 text-xs font-medium text-zinc-600 dark:text-zinc-400">
          {(chart.chartType === "pie" || chart.chartType === "donut"
            ? categories
            : series
          ).map((item, idx) => (
            <div key={`legend-${idx}`} className="flex items-center gap-1.5">
              <span
                className="h-2.5 w-2.5 rounded-full"
                style={{
                  backgroundColor:
                    (item as any).color ||
                    FALLBACK_CHART_COLORS[idx % FALLBACK_CHART_COLORS.length],
                }}
              />
              <span>{(item as any).label || item}</span>
            </div>
          ))}
        </div>
      )}

      {chart.sourceNote && (
        <figcaption className="mt-2 text-center text-xs text-zinc-400">
          {chart.sourceNote}
        </figcaption>
      )}
    </figure>
  );
}

// ─── MAIN RENDERER ─────────────────────────────────────────────────────────────
export function NexusRenderer({
  content,
  className,
  onCommentClick,
  onImageClick,
  hydrateCharts = true,
  enableImageInteraction = true,
  documentClassName,
}: NexusRendererProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mounted = typeof window !== "undefined";
  const preparedHTML = useMemo(
    () => prepareDocumentHTML(content || ""),
    [content],
  );

  const isEmpty =
    !content ||
    content.trim() === "" ||
    content.trim() === "<p></p>" ||
    content.trim() === "<p><br></p>";

  const handleDocumentClick = useCallback(
    (event: MouseEvent<HTMLDivElement>) => {
      const target = event.target;
      if (!(target instanceof Element)) return;

      const commentElement = target.closest("[data-comment-id]");
      if (commentElement && onCommentClick) {
        const commentId = commentElement.getAttribute("data-comment-id");
        if (commentId) {
          event.preventDefault();
          onCommentClick(commentId);
          return;
        }
      }

      if (
        enableImageInteraction &&
        onImageClick &&
        target instanceof HTMLImageElement
      ) {
        const src = target.currentSrc || target.src;
        if (src) {
          event.preventDefault();
          onImageClick(src, target.alt || undefined);
        }
      }
    },
    [enableImageInteraction, onCommentClick, onImageClick],
  );

  const [chartTargets, setChartTargets] = useState<
    Array<{ element: HTMLElement; chart: ChartAttrs }>
  >([]);

  const updateChartTargets = useCallback(() => {
    if (!hydrateCharts) {
      setChartTargets([]);
      return;
    }
    const container = containerRef.current;
    if (!container) return;

    setChartTargets(
      Array.from(
        container.querySelectorAll<HTMLElement>("[data-nexus-chart]"),
      ).map((element) => ({
        element,
        chart: recoverChartFromElement(element),
      })),
    );
  }, [hydrateCharts]);

  useEffect(() => {
    updateChartTargets();
  }, [preparedHTML, updateChartTargets]);

  if (isEmpty) {
    return (
      <p className={cn("text-sm italic text-zinc-500", className)}>
        No descriptive data provisioned for this node.
      </p>
    );
  }

  return (
    <>
      <article
        ref={containerRef}
        onClick={handleDocumentClick}
        className={cn(
          "nexus-renderer max-w-none w-full min-w-0 text-[15px] leading-7 md:text-base text-zinc-700 dark:text-zinc-300",
          documentClassName,
          className,
        )}
        dangerouslySetInnerHTML={{ __html: preparedHTML }}
      />
      {mounted &&
        hydrateCharts &&
        chartTargets.map(({ element, chart }, index) =>
          createPortal(
            <NativeNexusChart key={`nexus-chart-${index}`} chart={chart} />,
            element,
          ),
        )}
    </>
  );
}

export default NexusRenderer;
