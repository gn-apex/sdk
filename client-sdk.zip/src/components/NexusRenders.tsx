// packages/client-sdk/src/components/NexusRenders.tsx
"use client";

import React, { useState } from "react";
import * as LucideIcons from "lucide-react";
import { NexusRenderer } from "./NexusRenderer";

// ─── UTILITY: ISOMORPHIC HTML SANITIZER ─────────────────────────────────────
function sanitizeHtml(html: string): string {
  if (!html) return "";
  if (typeof window === "undefined") {
    return html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
      .replace(/<noscript\b[^<]*(?:(?!<\/noscript>)<[^<]*)*<\/noscript>/gi, "")
      .replace(/\bon\w+\s*=\s*(?:'[^']*'|"[^"]*"|[^\s>]+)/gi, "")
      .replace(/href\s*=\s*['"]\s*javascript:[^'"]*['"]/gi, 'href="#"')
      .replace(/src\s*=\s*['"]\s*javascript:[^'"]*['"]/gi, 'src=""');
  }

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  doc.querySelectorAll("script, noscript").forEach((n) => n.remove());
  doc.querySelectorAll<HTMLElement>("*").forEach((el) => {
    [...el.attributes].forEach((attr) => {
      if (attr.name.toLowerCase().startsWith("on")) {
        el.removeAttribute(attr.name);
      }
    });
    const href = el.getAttribute("href");
    const src = el.getAttribute("src");
    if (href && /^\s*javascript:/i.test(href)) el.removeAttribute("href");
    if (src && /^\s*javascript:/i.test(src)) el.removeAttribute("src");
  });
  return doc.body.innerHTML;
}

// ─── 1. RICH TEXT RENDERER ──────────────────────────────────────────────────
export interface NexusRichTextProps {
  value: string;
  className?: string;
  hydrateCharts?: boolean;
  onCommentClick?: (commentId: string) => void;
  onImageClick?: (src: string, alt?: string) => void;
}

export function NexusRichText({
  value,
  className = "",
  hydrateCharts = true,
  onCommentClick,
  onImageClick,
}: NexusRichTextProps) {
  if (!value) return null;

  return (
    <NexusRenderer
      content={value}
      className={className}
      hydrateCharts={hydrateCharts}
      onCommentClick={onCommentClick}
      onImageClick={onImageClick}
    />
  );
}

// ─── 2. LONG TEXT RENDERER ──────────────────────────────────────────────────
export interface NexusLongTextProps {
  value: string;
  className?: string;
}

export function NexusLongText({ value, className = "" }: NexusLongTextProps) {
  if (!value) return null;

  return (
    <p
      className={`text-sm text-muted-foreground whitespace-pre-line leading-relaxed ${className}`}
      dangerouslySetInnerHTML={{ __html: sanitizeHtml(value) }}
    />
  );
}

// ─── 3. DYNAMIC ICON RENDERER ───────────────────────────────────────────────
export interface NexusIconProps {
  name: string;
  className?: string;
  size?: number;
  strokeWidth?: number;
}

export function NexusIcon({
  name,
  className = "",
  size = 20,
  strokeWidth = 2,
}: NexusIconProps) {
  if (!name) return null;

  const IconComponent = (LucideIcons as any)[name];

  if (!IconComponent) {
    const Fallback = LucideIcons.HelpCircle;
    return (
      <Fallback className={className} size={size} strokeWidth={strokeWidth} />
    );
  }

  return (
    <IconComponent
      className={className}
      size={size}
      strokeWidth={strokeWidth}
    />
  );
}

// ─── 4. IMAGE RENDERER ──────────────────────────────────────────────────────
export interface NexusImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  value: string | { url: string; alt?: string } | null;
}

export function NexusImage({
  value,
  className = "",
  alt = "",
  ...props
}: NexusImageProps) {
  if (!value) return null;

  const imageUrl = typeof value === "string" ? value : value.url;
  const imageAlt = typeof value === "string" ? alt : value.alt || alt;

  if (!imageUrl) return null;

  return (
    /* eslint-disable-next-line @next/next/no-img-element */
    <img
      src={imageUrl}
      alt={imageAlt}
      loading="lazy"
      decoding="async"
      className={`max-w-full h-auto object-cover rounded-xl ${className}`}
      {...props}
    />
  );
}

// ─── 5. GALLERY RENDERER ────────────────────────────────────────────────────
export interface NexusGalleryProps {
  value: Array<string | { url: string; alt?: string }> | null;
  className?: string;
  imageClassName?: string;
}

export function NexusGallery({
  value,
  className = "",
  imageClassName = "",
}: NexusGalleryProps) {
  if (!value || value.length === 0) return null;

  return (
    <div
      className={`grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 ${className}`}
    >
      {value.map((img, idx) => (
        <div
          key={idx}
          className="overflow-hidden rounded-xl aspect-square bg-muted/20 border border-border"
        >
          <NexusImage
            value={img}
            className={`w-full h-full object-cover hover:scale-105 transition-transform duration-500 ${imageClassName}`}
          />
        </div>
      ))}
    </div>
  );
}

// ─── 6. VIDEO PLAYER RENDERER ───────────────────────────────────────────────
export interface NexusVideoProps {
  value: string | null;
  className?: string;
  autoplay?: boolean;
}

export function NexusVideo({
  value,
  className = "",
  autoplay = false,
}: NexusVideoProps) {
  if (!value) return null;

  const isYouTube = value.includes("youtube.com") || value.includes("youtu.be");
  const isVimeo = value.includes("vimeo.com");

  if (isYouTube) {
    const videoId = value.includes("youtu.be")
      ? value.split("/").pop()?.split("?")[0]
      : value.split("v=")[1]?.split("&")[0];

    return (
      <iframe
        src={`https://www.youtube.com/embed/${videoId}?autoplay=${autoplay ? 1 : 0}`}
        className={`w-full aspect-video rounded-xl border-0 ${className}`}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        title="YouTube Video"
      />
    );
  }

  if (isVimeo) {
    const videoId = value.split("/").pop()?.split("?")[0];
    return (
      <iframe
        src={`https://player.vimeo.com/video/${videoId}?autoplay=${autoplay ? 1 : 0}`}
        className={`w-full aspect-video rounded-xl border-0 ${className}`}
        allow="autoplay; fullscreen; picture-in-picture"
        allowFullScreen
        title="Vimeo Video"
      />
    );
  }

  return (
    <video
      src={value}
      controls
      autoPlay={autoplay}
      muted={autoplay}
      playsInline
      className={`w-full rounded-xl border border-border object-contain ${className}`}
    />
  );
}

// ─── 7. MAP / LOCATION RENDERER ─────────────────────────────────────────────
export interface NexusMapProps {
  value: { lat: number; lng: number; address?: string } | null;
  className?: string;
}

export function NexusMap({ value, className = "" }: NexusMapProps) {
  if (!value || !value.lat || !value.lng) return null;

  const query = encodeURIComponent(
    value.address || `${value.lat},${value.lng}`,
  );
  const embedUrl = `https://maps.google.com/maps?q=${query}&t=&z=13&ie=UTF8&iwloc=&output=embed`;

  return (
    <div
      className={`overflow-hidden rounded-xl border border-border aspect-video w-full ${className}`}
    >
      <iframe
        title="Embedded Map"
        width="100%"
        height="100%"
        src={embedUrl}
        className="border-0"
        allowFullScreen
        loading="lazy"
      />
    </div>
  );
}

// ─── 8. COLOR SWATCH RENDERER ───────────────────────────────────────────────
export interface NexusColorProps {
  value: string | null;
  className?: string;
  showHexLabel?: boolean;
}

export function NexusColor({
  value,
  className = "",
  showHexLabel = true,
}: NexusColorProps) {
  if (!value) return null;

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div
        className="h-6 w-6 rounded-full border border-border/80 shadow-xs shrink-0"
        style={{ backgroundColor: value }}
      />
      {showHexLabel && (
        <span className="font-mono text-xs font-semibold text-foreground/80 uppercase">
          {value}
        </span>
      )}
    </div>
  );
}

// ─── 9. GRADIENT TEXT & CONTAINER ───────────────────────────────────────────
export interface NexusGradientProps {
  value: string | null;
  children?: React.ReactNode;
  className?: string;
  asTextMask?: boolean;
}

export function NexusGradient({
  value,
  children,
  className = "",
  asTextMask = false,
}: NexusGradientProps) {
  if (!value) return <>{children}</>;

  if (asTextMask) {
    return (
      <span
        className={`bg-clip-text text-transparent font-bold ${className}`}
        style={{ backgroundImage: value, WebkitBackgroundClip: "text" }}
      >
        {children}
      </span>
    );
  }

  return (
    <div
      className={`rounded-xl ${className}`}
      style={{ backgroundImage: value }}
    >
      {children}
    </div>
  );
}

// ─── 10. ADDRESS CARD RENDERER ──────────────────────────────────────────────
export interface NexusAddressProps {
  value: {
    street?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  } | null;
  className?: string;
}

export function NexusAddress({ value, className = "" }: NexusAddressProps) {
  if (!value) return null;

  const lines = [
    value.street,
    [value.city, value.state, value.postalCode].filter(Boolean).join(", "),
    value.country,
  ].filter(Boolean);

  if (lines.length === 0) return null;

  return (
    <div
      className={`flex items-start gap-2.5 p-3 rounded-xl border border-border bg-card/50 ${className}`}
    >
      <LucideIcons.MapPin className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
      <div className="text-xs text-foreground/80 leading-relaxed font-medium">
        {lines.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
      </div>
    </div>
  );
}

// ─── 11. KEY VALUE SPEC GRID ────────────────────────────────────────────────
export interface NexusKeyValueProps {
  value: Record<string, string> | null;
  className?: string;
}

export function NexusKeyValue({ value, className = "" }: NexusKeyValueProps) {
  if (!value || Object.keys(value).length === 0) return null;

  return (
    <div
      className={`border border-border rounded-xl overflow-hidden bg-card/30 divide-y divide-border ${className}`}
    >
      {Object.entries(value).map(([k, v]) => (
        <div key={k} className="flex text-xs px-4 py-3 gap-4">
          <div className="w-1/3 font-bold text-muted-foreground select-none uppercase tracking-wider text-[10px]">
            {k}
          </div>
          <div className="flex-1 font-medium text-foreground">{v}</div>
        </div>
      ))}
    </div>
  );
}

// ─── 12. TAG LIST BADGES ────────────────────────────────────────────────────
export interface NexusTagsProps {
  value: string[] | null;
  className?: string;
  badgeClassName?: string;
}

export function NexusTags({
  value,
  className = "",
  badgeClassName = "",
}: NexusTagsProps) {
  if (!value || value.length === 0) return null;

  return (
    <div className={`flex flex-wrap gap-1.5 ${className}`}>
      {value.map((tag) => (
        <span
          key={tag}
          className={`inline-flex items-center rounded-lg border border-border bg-muted/40 px-2.5 py-1 text-xs font-semibold text-foreground/80 ${badgeClassName}`}
        >
          {tag}
        </span>
      ))}
    </div>
  );
}

// ─── 13. SOLID PROGRESS BAR ─────────────────────────────────────────────────
export interface NexusProgressProps {
  value: number | null;
  max?: number;
  className?: string;
  color?: string;
}

export function NexusProgress({
  value,
  max = 100,
  className = "",
  color = "bg-primary",
}: NexusProgressProps) {
  if (value === null) return null;

  const percent = Math.min(Math.max((value / max) * 100, 0), 100);

  return (
    <div className={`w-full ${className}`}>
      <div className="h-2 w-full rounded-full bg-muted overflow-hidden border border-border/30">
        <div
          className={`h-full rounded-full transition-all duration-500 ${color}`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}

// ─── 14. BLEND MODE WRAPPER ─────────────────────────────────────────────────
export interface NexusBlendContainerProps {
  mode: string | null;
  children: React.ReactNode;
  className?: string;
}

export function NexusBlendContainer({
  mode,
  children,
  className = "",
}: NexusBlendContainerProps) {
  const blendStyle = mode
    ? { mixBlendMode: mode as React.CSSProperties["mixBlendMode"] }
    : {};

  return (
    <div className={className} style={blendStyle}>
      {children}
    </div>
  );
}

// ─── 15. SECURE CODE BLOCK & COPY TRIGGER ───────────────────────────────────
export interface NexusCodeProps {
  value: string | null;
  language?: string;
  className?: string;
  showLineNumbers?: boolean;
}

export function NexusCode({
  value,
  language = "json",
  className = "",
  showLineNumbers = false,
}: NexusCodeProps) {
  const [copied, setCopied] = useState(false);

  if (!value) return null;

  const handleCopy = () => {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(value);
    } else {
      const textArea = document.createElement("textarea");
      textArea.value = value;
      textArea.style.position = "fixed";
      textArea.style.left = "-999999px";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        document.execCommand("copy");
      } catch {}
      textArea.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const lines = value.split("\n");

  return (
    <div
      className={`relative rounded-xl border border-border bg-[#090A0F] overflow-hidden ${className}`}
    >
      <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-white/2 select-none">
        <span className="text-[10px] font-black uppercase text-muted-foreground tracking-wider">
          {language}
        </span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground hover:text-primary transition-colors cursor-pointer"
        >
          {copied ? (
            <>
              <LucideIcons.Check className="h-3 w-3 text-emerald-400" />
              <span className="text-emerald-400">Copied!</span>
            </>
          ) : (
            <>
              <LucideIcons.Copy className="h-3 w-3" />
              <span>Copy Code</span>
            </>
          )}
        </button>
      </div>

      <div className="flex overflow-x-auto p-4 font-mono text-[11px] leading-relaxed text-emerald-400 select-text">
        {showLineNumbers && (
          <div className="flex flex-col text-right text-gray-600 select-none pr-3.5 border-r border-border/30 mr-3.5">
            {lines.map((_, i) => (
              <span key={i}>{i + 1}</span>
            ))}
          </div>
        )}
        <pre className="flex-1 whitespace-pre">{value}</pre>
      </div>
    </div>
  );
}

// ─── 16. GRAPHICAL STATUS BADGE ─────────────────────────────────────────────
export interface NexusBooleanProps {
  value: boolean | null;
  className?: string;
  trueLabel?: string;
  falseLabel?: string;
}

export function NexusBoolean({
  value,
  className = "",
  trueLabel = "Active",
  falseLabel = "Inactive",
}: NexusBooleanProps) {
  if (value === null) return null;

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-wider border shadow-sm ${
        value
          ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-400"
          : "border-muted-foreground/20 bg-muted-foreground/10 text-muted-foreground"
      } ${className}`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${value ? "bg-emerald-500 animate-pulse" : "bg-muted-foreground"}`}
      />
      {value ? trueLabel : falseLabel}
    </span>
  );
}
