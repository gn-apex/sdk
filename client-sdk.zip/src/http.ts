import { NexusConfig } from "./types";
import { NexusError } from "./errors";
import { NexusEventBus } from "./events";
import {
  ExponentialBackoff,
  RateLimiter,
  CircuitBreaker,
} from "./content/strategies";

export interface NexusRequestOptions extends RequestInit {
  timeout?: number;
  retries?: number;
  next?: { tags?: string[]; revalidate?: number | false };
}

const uuid = () =>
  typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `nx_${Date.now()}_${Math.random().toString(36).slice(2)}`;

export class NexusHttpClient {
  private readonly limiter: RateLimiter;
  private readonly breaker = new CircuitBreaker();
  private readonly backoff: ExponentialBackoff;

  constructor(
    private config: NexusConfig,
    private events = new NexusEventBus(),
  ) {
    this.limiter = new RateLimiter({
      maxRequests: config.debug ? 200 : 100,
      timeWindow: 60_000,
    });
    this.backoff = new ExponentialBackoff({
      maxRetries: config.retries ?? 3,
      baseDelay: 150,
      maxDelay: 8_000,
      jitter: true,
    });
  }

  updateConfig(config: NexusConfig) {
    this.config = config;
  }

  async request(
    input: string,
    options: NexusRequestOptions = {},
  ): Promise<Response> {
    if (this.breaker.isOpen()) {
      throw new NexusError(
        "GN-Apex service circuit is open",
        "CIRCUIT_OPEN",
        undefined,
        undefined,
        undefined,
        true,
      );
    }

    const requestId = uuid();
    const url = input;
    const started = Date.now();
    const headers = new Headers(options.headers);
    headers.set("X-Nexus-Request-ID", requestId);
    headers.set(
      "X-Nexus-Client",
      `gnexus-sdk/${this.config.sdkVersion ?? "1.1.0"}`,
    );
    headers.set("X-Nexus-Project", this.config.projectId);
    if (this.config.apiKey)
      headers.set("Authorization", `Bearer ${this.config.apiKey}`);

    this.events.emit("request:start", {
      requestId,
      url,
      method: options.method ?? "GET",
    });

    try {
      await this.limiter.checkLimit();

      const response = await this.backoff.execute(async () => {
        const controller = new AbortController();
        const timeout = options.timeout ?? this.config.timeout ?? 10_000;
        const timer = setTimeout(() => controller.abort(), timeout);
        try {
          return await fetch(url, {
            ...options,
            headers,
            signal: options.signal ?? controller.signal,
          });
        } catch (e: any) {
          if (e?.name === "AbortError") {
            throw new NexusError(
              `Request timed out after ${timeout}ms`,
              "TIMEOUT",
              undefined,
              requestId,
              undefined,
              true,
              e,
            );
          }
          throw new NexusError(
            "Network request failed",
            "NETWORK_ERROR",
            undefined,
            requestId,
            undefined,
            true,
            e,
          );
        } finally {
          clearTimeout(timer);
        }
      });

      if (!response.ok) {
        const retryable =
          response.status === 408 ||
          response.status === 429 ||
          response.status >= 500;
        let details: unknown;
        try {
          details = await response.clone().json();
        } catch {}

        const code =
          response.status === 404
            ? "NOT_FOUND"
            : response.status === 429
              ? "RATE_LIMITED"
              : "HTTP_ERROR";
        const err = new NexusError(
          `API request failed (${response.status})`,
          code,
          response.status,
          response.headers.get("x-nexus-request-id") ?? requestId,
          details,
          retryable,
        );
        throw err;
      }

      // Successful 2xx response
      this.breaker.recordSuccess();
      this.events.emit("request:end", {
        requestId,
        url,
        status: response.status,
        duration: Date.now() - started,
      });
      return response;
    } catch (e: any) {
      // 🛡️ FIX: Only record failure if it's a server crash (5xx), rate limit (429), or network timeout.
      // 404 Not Found and 401 Unauthorized are ignored so your site NEVER goes down from broken links.
      if (e instanceof NexusError) {
        if (
          e.retryable ||
          (e.status && (e.status >= 500 || e.status === 429))
        ) {
          this.breaker.recordFailure();
        } else {
          this.breaker.recordSuccess(); // Server responded cleanly (e.g. 404), so it's alive!
        }
      } else {
        this.breaker.recordFailure();
      }

      this.events.emit("error", { error: e });
      throw e;
    }
  }

  getStats() {
    return {
      rateLimit: this.limiter.getStats(),
      circuit: this.breaker.getState(),
    };
  }
}
