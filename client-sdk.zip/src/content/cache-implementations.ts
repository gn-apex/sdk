// packages/client-sdk/src/content/cache-implementations.ts

/**
 * GnApex Shared Cache Implementations
 *
 * Contains MemoryCache (LRU) and BrowserCache (LocalStorage)
 * which are safe for universal usage.
 */

export interface CacheOptions {
  maxSize?: number;
  ttl?: number;
  /** false means platform-controlled immutable cache. */
  revalidate?: number | false;
  tags?: string[];
}

export interface CacheStats {
  size: number;
  hits: number;
  misses: number;
  hitRate: number;
  evictions: number;
}

// Cache Tag Generators for precise invalidation
export const CacheTags = {
  project: (projectId: string) => `nexus_project_${projectId}`,
  content: (slug: string) => `content_${slug}`,
  collection: (collectionId: string) => `collection_${collectionId}`,
  global: "nexus_global_config",
  user: (userId: string) => `user_${userId}`,
  media: (mediaId: string) => `media_${mediaId}`,
};

// Memory Cache Implementation with LRU (Least Recently Used) eviction
export class MemoryCache {
  private cache = new Map<string, { data: any; metadata: any }>();
  private tagIndex = new Map<string, Set<string>>();
  private stats: CacheStats = {
    size: 0,
    hits: 0,
    misses: 0,
    hitRate: 0,
    evictions: 0,
  };
  private maxSize: number;
  private defaultTTL: number;

  constructor(options: CacheOptions = {}) {
    this.maxSize = options.maxSize || 1000;
    this.defaultTTL = options.ttl || 5 * 60 * 1000; // 5 minutes
  }

  set<T = any>(key: string, data: T, options: CacheOptions = {}): void {
    // Check if we need to evict based on max item count
    if (this.cache.size >= this.maxSize) {
      this.evictLRU();
    }

    const metadata = {
      timestamp: Date.now(),
      expiresAt: Date.now() + (options.ttl || this.defaultTTL),
      tags: options.tags || [],
      size: this.calculateSize(data),
    };

    this.cache.set(key, { data, metadata });
    this.stats.size = this.cache.size;

    // Update tag index for targeted invalidation
    metadata.tags.forEach((tag) => {
      if (!this.tagIndex.has(tag)) {
        this.tagIndex.set(tag, new Set());
      }
      this.tagIndex.get(tag)!.add(key);
    });
  }

  get<T = any>(key: string): { data: T; metadata: any } | null {
    const entry = this.cache.get(key);

    if (!entry) {
      this.stats.misses++;
      this.updateHitRate();
      return null;
    }

    // Check if expired
    if (Date.now() > entry.metadata.expiresAt) {
      this.delete(key);
      this.stats.misses++;
      this.updateHitRate();
      return null;
    }

    // Update timestamp for LRU policy
    entry.metadata.timestamp = Date.now();
    this.stats.hits++;
    this.updateHitRate();

    return entry;
  }

  delete(key: string): boolean {
    const entry = this.cache.get(key);
    if (!entry) return false;

    // Remove key from tag index
    entry.metadata.tags.forEach((tag: string) => {
      const keys = this.tagIndex.get(tag);
      if (keys) {
        keys.delete(key);
        if (keys.size === 0) {
          this.tagIndex.delete(tag);
        }
      }
    });

    this.cache.delete(key);
    this.stats.size = this.cache.size;
    return true;
  }

  invalidateByTags(tags: string[]): void {
    const keysToDelete = new Set<string>();

    tags.forEach((tag) => {
      const keys = this.tagIndex.get(tag);
      if (keys) {
        keys.forEach((key) => keysToDelete.add(key));
        // Clear the tag index for this tag
        this.tagIndex.delete(tag);
      }
    });

    keysToDelete.forEach((key) => this.delete(key));

    if (process.env.NODE_ENV === "development") {
      console.log(
        `[MemoryCache] Invalidated ${keysToDelete.size} entries by tags: ${tags.join(", ")}`,
      );
    }
  }

  clear(): void {
    this.cache.clear();
    this.tagIndex.clear();
    this.stats = {
      size: 0,
      hits: 0,
      misses: 0,
      hitRate: 0,
      evictions: 0,
    };
  }

  getStats(): CacheStats {
    return { ...this.stats };
  }

  private evictLRU(): void {
    let oldestKey: string | null = null;
    let oldestTime = Infinity;

    for (const [key, entry] of this.cache.entries()) {
      if (entry.metadata.timestamp < oldestTime) {
        oldestTime = entry.metadata.timestamp;
        oldestKey = key;
      }
    }

    if (oldestKey) {
      this.delete(oldestKey);
      this.stats.evictions++;
    }
  }

  private calculateSize(data: any): number {
    try {
      const jsonString = JSON.stringify(data);
      // Blob is available in Node 18+ and Browsers
      return new Blob([jsonString]).size;
    } catch {
      return 0;
    }
  }

  private updateHitRate(): void {
    const total = this.stats.hits + this.stats.misses;
    this.stats.hitRate = total > 0 ? this.stats.hits / total : 0;
  }
}

// Browser LocalStorage Cache (Persists content across sessions/refreshes)
export class BrowserCache {
  private prefix = "nexushub_";
  private maxSize = 5 * 1024 * 1024; // 5MB standard LocalStorage limit
  private currentSize = 0;

  constructor(private projectId: string) {
    if (typeof window !== "undefined") {
      this.calculateCurrentSize();
    }
  }

  set<T = any>(key: string, data: T, ttl: number = 5 * 60 * 1000): void {
    if (typeof window === "undefined") return;

    const storageKey = this.getStorageKey(key);
    const entry = {
      data,
      metadata: {
        timestamp: Date.now(),
        expiresAt: Date.now() + ttl,
        size: this.calculateStorageSize(data),
      },
    };

    const serialized = JSON.stringify(entry);
    const newSize = new Blob([serialized]).size;

    // Check if we have enough space, evict oldest items if necessary
    if (this.currentSize + newSize > this.maxSize) {
      this.evictOldest();
    }

    try {
      localStorage.setItem(storageKey, serialized);
      this.currentSize += newSize;
    } catch (error) {
      console.warn("[BrowserCache] Failed to save to localStorage:", error);
      this.evictOldest();
      // Retry once after eviction
      try {
        localStorage.setItem(storageKey, serialized);
      } catch (e) {
        // Fallback: If still failing, just don't cache
      }
    }
  }

  get<T = any>(key: string): T | null {
    if (typeof window === "undefined") return null;

    const storageKey = this.getStorageKey(key);
    const item = localStorage.getItem(storageKey);

    if (!item) return null;

    try {
      const entry = JSON.parse(item);

      // Check if expired
      if (Date.now() > entry.metadata.expiresAt) {
        this.delete(key);
        return null;
      }

      return entry.data;
    } catch {
      // If data is corrupted, remove it
      this.delete(key);
      return null;
    }
  }

  delete(key: string): void {
    if (typeof window === "undefined") return;

    const storageKey = this.getStorageKey(key);
    const item = localStorage.getItem(storageKey);

    if (item) {
      this.currentSize -= new Blob([item]).size;
    }

    localStorage.removeItem(storageKey);
  }

  clear(): void {
    if (typeof window === "undefined") return;

    const keysToRemove: string[] = [];

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith(this.prefix)) {
        keysToRemove.push(key);
      }
    }

    keysToRemove.forEach((key) => localStorage.removeItem(key));
    this.currentSize = 0;
  }

  private getStorageKey(key: string): string {
    return `${this.prefix}${this.projectId}_${key}`;
  }

  private calculateCurrentSize(): void {
    this.currentSize = 0;

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith(this.prefix)) {
        const item = localStorage.getItem(key);
        if (item) {
          this.currentSize += new Blob([item]).size;
        }
      }
    }
  }

  private calculateStorageSize(data: any): number {
    return new Blob([JSON.stringify(data)]).size;
  }

  private evictOldest(): void {
    let oldestKey: string | null = null;
    let oldestTime = Infinity;

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith(this.prefix)) {
        const item = localStorage.getItem(key);
        if (item) {
          try {
            const entry = JSON.parse(item);
            if (entry.metadata.timestamp < oldestTime) {
              oldestTime = entry.metadata.timestamp;
              oldestKey = key;
            }
          } catch {
            // Invalid JSON, remove it immediately
            localStorage.removeItem(key);
          }
        }
      }
    }

    if (oldestKey) {
      const item = localStorage.getItem(oldestKey);
      if (item) {
        this.currentSize -= new Blob([item]).size;
      }
      localStorage.removeItem(oldestKey);
    }
  }
}
