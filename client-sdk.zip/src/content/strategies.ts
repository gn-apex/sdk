/** Production resilience primitives used internally by GN-Apex. */
export interface RateLimiterConfig { maxRequests: number; timeWindow: number; }
export class RateLimiter {
  private requests:number[]=[]; constructor(private config:RateLimiterConfig){}
  async checkLimit(){ while(true){ const now=Date.now(); const cutoff=now-this.config.timeWindow; this.requests=this.requests.filter(t=>t>cutoff); if(this.requests.length<this.config.maxRequests){this.requests.push(now);return;} await new Promise(r=>setTimeout(r,Math.max(1,this.requests[0]+this.config.timeWindow-now))); } }
  getStats(){const now=Date.now();return{currentRequests:this.requests.filter(t=>t>now-this.config.timeWindow).length,limit:this.config.maxRequests};}
}
export interface BackoffConfig {maxRetries:number;baseDelay:number;maxDelay:number;jitter?:boolean;}
export class ExponentialBackoff { constructor(private config:BackoffConfig){this.config={jitter:true,...config};}
  async execute<T>(fn:()=>Promise<T>,onRetry?:(attempt:number,delay:number,error:Error)=>void){let last:any;for(let a=0;a<=this.config.maxRetries;a++){try{return await fn();}catch(e:any){last=e;if(e?.code==="ABORTED"||e?.code==="VALIDATION_ERROR"||(e?.status>=400&&e?.status<500&&e?.status!==429))throw e;if(a===this.config.maxRetries)break;let delay=Math.min(this.config.maxDelay,this.config.baseDelay*2**a);if(this.config.jitter) delay*=0.5+Math.random();onRetry?.(a+1,delay,e);await new Promise(r=>setTimeout(r,delay));}}throw last;}
}
export enum CircuitState { CLOSED, OPEN, HALF_OPEN }
export class CircuitBreaker { private state=CircuitState.CLOSED;private failures=0;private lastFailure=0;constructor(private threshold=5,private reset=30_000){}
 isOpen(){if(this.state===CircuitState.OPEN&&Date.now()-this.lastFailure>=this.reset){this.state=CircuitState.HALF_OPEN;return false;}return this.state===CircuitState.OPEN;}
 recordSuccess(){this.failures=0;this.state=CircuitState.CLOSED;} recordFailure(){this.failures++;this.lastFailure=Date.now();if(this.failures>=this.threshold)this.state=CircuitState.OPEN;} getState(){return CircuitState[this.state];}
}
/** Correct request coalescing: same key shares one promise; different keys stay distinct. */
export class RequestBatcher { private pending=new Map<string,Promise<any>>(); constructor(private windowMs=10, private maxBatchSize=50){}
 schedule<T>(key:string, request:()=>Promise<T>):Promise<T>{const existing=this.pending.get(key);if(existing)return existing;const promise=new Promise<T>((resolve,reject)=>setTimeout(()=>request().then(resolve,reject),this.windowMs));this.pending.set(key,promise);promise.finally(()=>this.pending.delete(key)).catch(()=>{});return promise;}
 clear(){this.pending.clear();}
}
