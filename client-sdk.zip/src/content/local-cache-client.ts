// packages/client-sdk/src/content/local-cache-client.ts

import type { ILocalCache } from "./cache-types";

/**
 * GnApex LocalCache (Browser Implementation)
 *
 * This is a dummy implementation used when the SDK is bundled for the browser.
 * Since the browser has no access to the Node.js File System (fs), this
 * implementation returns null for all operations.
 *
 * The real logic is located in local-cache-server.ts and is swapped
 * automatically by the bundler via the "browser" field in package.json.
 */
export class LocalCache implements ILocalCache {
  // Maintain private properties for type parity with the Server version
  private data: any = null;
  private hasLoaded = false;
  private cachePath: string;

  constructor(customPath?: string) {
    this.cachePath = customPath || ".nexus/cache.json";
    // No-op in browser: We cannot read from the local disk.
  }

  /**
   * Always returns false in the browser as local file caching
   * is a server-side only feature.
   */
  isLoaded(): boolean {
    return false;
  }

  /**
   * No-op method to maintain internal API compatibility.
   */
  private load(): void {
    // Browsers cannot load local files from the disk via Node's 'fs'.
    return;
  }

  /**
   * Returns null. Browsers should fetch pages from the Remote API
   * or the Memory/Browser cache.
   */
  async getPage(_slug: string): Promise<any> {
    return null;
  }

  /**
   * Returns null. Browsers should fetch collections from the Remote API.
   */
  async getCollection(_collectionId: string): Promise<any[] | null> {
    return null;
  }

  /**
   * Returns null.
   */
  async getGlobals(): Promise<any> {
    return null;
  }

  /**
   * Returns null.
   */
  async getAllData(): Promise<any> {
    return null;
  }

  /**
   * Dummy helper to match Node implementation.
   */
  private shouldWarnAboutMissingCache(error: any): boolean {
    // ENOENT means "Error NO ENTitity" (The file simply doesn't exist)
    const isMissing = error.code === "ENOENT";

    // SyntaxError means JSON.parse failed (The file exists but is broken)
    const isMalformed = error instanceof SyntaxError;

    // RULE 1: If we are in Production, NEVER warn.
    // We want the SDK to be silent and just use the Remote API.
    if (process.env.NODE_ENV !== "development") return false;

    // RULE 2: If the file is missing, return FALSE (Don't warn).
    // A lot of users won't use the local cache feature. We shouldn't
    // spam their console just because they haven't run 'npx apex pull' yet.

    // RULE 3: If the file exists but is broken (isMalformed), return TRUE (Warn).
    // This helps the developer realize they have a corrupted cache file.
    return !isMissing || isMalformed;
  }
}
