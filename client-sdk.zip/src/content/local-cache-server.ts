// packages/client-sdk/src/content/local-cache-server.ts

import fs from "fs";
import path from "path";
import { getEnvConfig } from "../config";
import { BinaryCompiler } from "./binary-compiler";
import { validateSlug } from "./utils";
import type { ILocalCache } from "./cache-types";

export class LocalCache implements ILocalCache {
  private baseDir: string;
  private apiKey: string = "";

  constructor(customPath?: string, apiKey?: string) {
    this.baseDir = customPath || ".nexus/local";
    const config = getEnvConfig();
    this.apiKey = apiKey || config.apiKey || "";
  }

  isLoaded(): boolean {
    return fs.existsSync(path.resolve(process.cwd(), this.baseDir));
  }

  private decompileFile(filePath: string): any {
    if (!this.apiKey) {
      if (process.env.NODE_ENV === "development") {
        console.warn(
          "⚠️  GnApex: Missing NEXUS_API_KEY. Local decryption bypassed.",
        );
      }
      return null;
    }

    try {
      const encryptedBuffer = fs.readFileSync(filePath);
      const decompiled = BinaryCompiler.decompile(encryptedBuffer, this.apiKey);
      return decompiled.data;
    } catch (error: any) {
      if (process.env.NODE_ENV === "development") {
        console.error(
          `\n🚨  GnApex Security Alert: Data Integrity Violation in file:\n` +
            `    ${filePath}\n` +
            `    Error: ${error.message}\n` +
            `    This file has been disabled until regenerated via npx apex pull.\n`,
        );
      }
      return null;
    }
  }

  /**
   * Retrieve a specific page safely from its .nx file.
   */
  async getPage(slug: string): Promise<any> {
    // 🛡️ SECURITY FIX: Prevent Path Traversal attacks (e.g. '../../secrets')
    try {
      validateSlug(slug);
    } catch {
      return null;
    }

    const filePath = path.resolve(
      process.cwd(),
      this.baseDir,
      "pages",
      `${slug}.nx`,
    );

    if (fs.existsSync(filePath)) {
      const pageData = this.decompileFile(filePath);
      if (!pageData) return null;

      let content = pageData;
      while (
        content &&
        typeof content === "object" &&
        content.data !== undefined
      ) {
        content = content.data;
      }
      return content;
    }
    return null;
  }

  /**
   * Retrieve an entire collection safely from its specific .nx file.
   */
  async getCollection(collectionId: string): Promise<any[] | null> {
    // 🛡️ SECURITY FIX: Prevent Path Traversal attacks
    try {
      validateSlug(collectionId);
    } catch {
      return null;
    }

    const filePath = path.resolve(
      process.cwd(),
      this.baseDir,
      "collections",
      `${collectionId}.nx`,
    );

    if (fs.existsSync(filePath)) {
      return this.decompileFile(filePath);
    }
    return null;
  }

  /**
   * Retrieve global settings from its .nx file.
   */
  async getGlobals(): Promise<any> {
    const filePath = path.resolve(process.cwd(), this.baseDir, "globals.nx");
    if (fs.existsSync(filePath)) {
      return this.decompileFile(filePath);
    }
    return null;
  }

  /**
   * Returns a merged JSON of the entire workspace structure.
   */
  async getAllData(): Promise<any> {
    const pages: Record<string, any> = {};
    const collections: Record<string, any[]> = {};
    let globals = {};

    try {
      const pagesDir = path.resolve(process.cwd(), this.baseDir, "pages");
      if (fs.existsSync(pagesDir)) {
        for (const file of fs.readdirSync(pagesDir)) {
          if (file.endsWith(".nx")) {
            const slug = path.basename(file, ".nx");
            pages[slug] = await this.getPage(slug);
          }
        }
      }

      const colsDir = path.resolve(process.cwd(), this.baseDir, "collections");
      if (fs.existsSync(colsDir)) {
        for (const file of fs.readdirSync(colsDir)) {
          if (file.endsWith(".nx")) {
            const id = path.basename(file, ".nx");
            collections[id] = (await this.getCollection(id)) || [];
          }
        }
      }

      globals = (await this.getGlobals()) || {};
    } catch {}

    return { pages, collections, globals };
  }
}
