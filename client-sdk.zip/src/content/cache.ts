// packages/client-sdk/src/content/cache.ts
import { MemoryCache, BrowserCache, CacheTags } from "./cache-implementations";
import type { ILocalCache } from "./cache-types";

export class LocalCacheProxy implements ILocalCache {
  private instance: ILocalCache | null = null;
  private cachePath?: string;

  constructor(cachePath?: string) {
    this.cachePath = cachePath;
  }

  private async getInstance(): Promise<ILocalCache> {
    if (this.instance) return this.instance;
    if (typeof window === "undefined") {
      const mod = await import("./local-cache-server");
      this.instance = new mod.LocalCache(this.cachePath);
    } else {
      // Logic for Client
      const mod = await import("./local-cache-client");
      this.instance = new mod.LocalCache(this.cachePath);
    }
    return this.instance!; // Use ! to tell TS this won't be null here
  }

  isLoaded() {
    return this.instance?.isLoaded() || false;
  }

  async getPage(slug: string) {
    const inst = await this.getInstance();
    return inst.getPage(slug);
  }

  async getCollection(id: string) {
    const inst = await this.getInstance();
    return inst.getCollection(id);
  }

  async getGlobals() {
    const inst = await this.getInstance();
    return inst.getGlobals();
  }

  async getAllData() {
    const inst = await this.getInstance();
    return inst.getAllData();
  }
}

export { LocalCacheProxy as LocalCache, MemoryCache, BrowserCache, CacheTags };
