// packages/client-sdk/src/content/index.ts

import {
  NexusConfig,
  ContentResponse,
  CollectionResponse,
  CollectionQuery,
  CacheEntry,
  CacheMetadata,
} from "../types";
import { CacheTags, LocalCache, MemoryCache, BrowserCache } from "./cache";
import {
  RateLimiter,
  ExponentialBackoff,
  RequestBatcher,
  CircuitBreaker,
} from "./strategies";
import {
  validateSlug,
  normalizeQuery,
  buildQueryString,
  measurePerformance,
} from "./utils";

export class ContentEngine {
  private localCache: LocalCache;
  private memoryCache: MemoryCache;
  private browserCache?: BrowserCache;

  private rateLimiter: RateLimiter;
  private backoff: ExponentialBackoff;
  private requestBatcher: RequestBatcher;
  private circuitBreaker: CircuitBreaker;

  private defaultRevalidate: number | false;
  private cacheStrategy: "memory" | "localStorage" | "none";
  private isServer: boolean;

  constructor(private config: NexusConfig) {
    this.isServer = typeof window === "undefined";

    this.localCache = new LocalCache();

    this.memoryCache = new MemoryCache({
      maxSize: 500,
      ttl: 5 * 1000, // 👈 5 seconds
    });

    if (!this.isServer) {
      this.browserCache = new BrowserCache(config.projectId);
    }

    this.rateLimiter = new RateLimiter({
      maxRequests: config.debug ? 200 : 100,
      timeWindow: 60000,
    });

    this.backoff = new ExponentialBackoff({
      maxRetries: config.retries || 3,
      baseDelay: 100,
      maxDelay: 5000,
      jitter: true,
    });

    this.requestBatcher = new RequestBatcher(20, 50);
    this.circuitBreaker = new CircuitBreaker();

    this.defaultRevalidate = config.revalidateTime ?? false;
    this.cacheStrategy = config.cacheStrategy || "memory";

    if (!this.isServer) {
      window.addEventListener("beforeunload", this.cleanup.bind(this));
    }
  }

  public updateConfig(config: NexusConfig): void {
    this.config = config;
    this.defaultRevalidate = config.revalidateTime ?? false;
    this.cacheStrategy = config.cacheStrategy || "memory";
  }

  async getPage<T = any>(
    slug: string,
    options: {
      revalidate?: number | false;
      tags?: string[];
      forceRefresh?: boolean;
      includeMetadata?: boolean;
    } = {},
  ): Promise<T> {
    const { result, duration } = measurePerformance(`getPage("${slug}")`, () =>
      this._getPage<T>(slug, options),
    );

    if (this.config.debug && duration > 100) {
      console.warn(
        `[GnApex] ⚠️ getPage("${slug}") took ${duration.toFixed(2)}ms`,
      );
    }

    return result;
  }

  private async _getPage<T = any>(
    slug: string,
    options: {
      revalidate?: number | false;
      tags?: string[];
      forceRefresh?: boolean;
      includeMetadata?: boolean;
    } = {},
  ): Promise<T> {
    validateSlug(slug);

    const {
      revalidate = this.defaultRevalidate,
      tags = [],
      forceRefresh = false,
      includeMetadata = false,
    } = options;

    const cacheKey = `page:${slug}`;

    // 1. Browser-only memory cache.
    // The server must always delegate caching to Next.js.
    if (!this.isServer && !forceRefresh && this.cacheStrategy === "memory") {
      const cached = this.memoryCache.get<T>(cacheKey);

      if (cached && this.isCacheValid(cached.metadata)) {
        return includeMetadata ? (cached as unknown as T) : cached.data;
      }
    }

    // 2. Local .nexus cache is development-only.
    if (!forceRefresh && process.env.NODE_ENV === "development") {
      try {
        const local = await this.localCache.getPage(slug);

        if (local) {
          return includeMetadata
            ? ({
                data: local,
                metadata: {
                  timestamp: Date.now(),
                  expiresAt: Infinity,
                  tags: [],
                },
              } as any)
            : local;
        }
      } catch {
        // Fall through to the API.
      }
    }

    if (this.circuitBreaker.isOpen()) {
      throw new Error("[GnApex] Circuit open. API is unavailable.");
    }

    // 3. Server-side caching is owned by Next.js.
    try {
      await this.rateLimiter.checkLimit();

      const data = await this.backoff.execute(async () => {
        return this.fetchPage<T>(
          slug,
          cacheKey,
          tags,
          revalidate,
          forceRefresh,
        );
      });

      this.circuitBreaker.recordSuccess();

      return includeMetadata ? (data as unknown as T) : data.data;
    } catch (error) {
      this.circuitBreaker.recordFailure();

      // Development-only offline fallback.
      // Production must never resurrect stale .nexus build data.
      if (process.env.NODE_ENV === "development") {
        try {
          const local = await this.localCache.getPage(slug);

          if (local) {
            return includeMetadata
              ? ({
                  data: local,
                  metadata: {
                    timestamp: Date.now(),
                    expiresAt: Infinity,
                    tags: [],
                  },
                } as any)
              : local;
          }
        } catch {
          // Ignore local cache errors.
        }
      }

      throw this.normalizeError(error, `Failed to fetch page '${slug}'`);
    }
  }

  async getCollection<T = any>(
    collectionId: string,
    query: CollectionQuery = {},
    options: {
      revalidate?: number | false;
      tags?: string[];
      forceRefresh?: boolean;
      includeMetadata?: boolean;
    } = {},
  ): Promise<CollectionResponse<T>> {
    const normalizedQuery = normalizeQuery(query);

    const {
      revalidate = this.defaultRevalidate,
      tags = [],
      forceRefresh = false,
      includeMetadata = false,
    } = options;

    const queryString = buildQueryString(normalizedQuery);
    const cacheKey = `collection:${collectionId}:${queryString}`;

    // 1. Browser-only memory cache.
    if (!this.isServer && !forceRefresh && this.cacheStrategy === "memory") {
      const cached = this.memoryCache.get<CollectionResponse<T>>(cacheKey);

      if (cached && this.isCacheValid(cached.metadata)) {
        return includeMetadata
          ? (cached as unknown as CollectionResponse<T>)
          : cached.data;
      }
    }

    // 2. Local collection cache is development-only.
    if (!forceRefresh && process.env.NODE_ENV === "development") {
      try {
        const localCollection =
          await this.localCache.getCollection(collectionId);

        if (localCollection) {
          const result = this.applyLocalQuery<T>(
            localCollection as T[],
            normalizedQuery,
          );

          return result as unknown as CollectionResponse<T>;
        }
      } catch {
        // Fall through to API.
      }
    }

    if (this.circuitBreaker.isOpen()) {
      throw new Error("[GnApex] Circuit open. API is unavailable.");
    }

    // 3. Server-side caching is owned by Next.js.
    try {
      await this.rateLimiter.checkLimit();

      const result = await this.backoff.execute(async () => {
        return this.fetchCollection<T>(
          collectionId,
          normalizedQuery,
          cacheKey,
          tags,
          revalidate,
          forceRefresh,
        );
      });

      this.circuitBreaker.recordSuccess();

      return includeMetadata
        ? (result as unknown as CollectionResponse<T>)
        : result.data;
    } catch (error) {
      this.circuitBreaker.recordFailure();

      // Development-only offline fallback.
      if (process.env.NODE_ENV === "development") {
        try {
          const localCollection =
            await this.localCache.getCollection(collectionId);

          if (localCollection) {
            return this.applyLocalQuery<T>(
              localCollection as T[],
              normalizedQuery,
            );
          }
        } catch {
          // Ignore local cache errors.
        }
      }

      throw this.normalizeError(
        error,
        `Failed to fetch collection '${collectionId}'`,
      );
    }
  }

  async getGlobals<T = any>(
    options: {
      include?: string[];
      revalidate?: number | false;
      forceRefresh?: boolean;
      tags?: string[];
    } = {},
  ): Promise<T> {
    const {
      include = [],
      revalidate = this.defaultRevalidate,
      forceRefresh = false,
    } = options;

    const cacheKey = `globals:${include.join(",")}`;

    // 1. Browser-only memory cache.
    if (!this.isServer && !forceRefresh && this.cacheStrategy === "memory") {
      const cached = this.memoryCache.get<T>(cacheKey);

      if (cached && this.isCacheValid(cached.metadata)) {
        return cached.data;
      }
    }

    // 2. Local globals cache is development-only.
    if (!forceRefresh && process.env.NODE_ENV === "development") {
      try {
        const localGlobals = await this.localCache.getGlobals();

        if (localGlobals) {
          return localGlobals;
        }
      } catch {
        // Fall through to API.
      }
    }

    try {
      await this.rateLimiter.checkLimit();

      const url =
        `${this.config.apiUrl}/content/` + `${this.config.projectId}/globals`;

      const params = include.length > 0 ? `?include=${include.join(",")}` : "";

      const fetchTags = [
        CacheTags.project(this.config.projectId),
        CacheTags.global,
        ...(options.tags || []),
      ];

      const res = await this.fetchWithTimeout(`${url}${params}`, {
        method: "GET",
        headers: this.getHeaders(),
        tags: fetchTags,
        revalidate,
        forceRefresh,
      });

      if (!res.ok) {
        throw new Error(`API Error ${res.status}: ${res.statusText}`);
      }

      const json = await res.json();
      const data = json.data || json;

      // Browser-only cache.
      if (!this.isServer) {
        this.writeCache(cacheKey, data, {
          revalidate,
          tags: fetchTags,
        });
      }

      return data;
    } catch (error) {
      // Development-only offline fallback.
      if (process.env.NODE_ENV === "development") {
        try {
          const localGlobals = await this.localCache.getGlobals();

          if (localGlobals) {
            return localGlobals;
          }
        } catch {
          // Ignore local cache errors.
        }
      }

      throw this.normalizeError(error, "Failed to fetch globals");
    }
  }

  async getItem<T = any>(
    collectionId: string,
    itemId: string,
    options: {
      revalidate?: number | false;
      tags?: string[];
      include?: string[];
      forceRefresh?: boolean;
    } = {},
  ): Promise<T> {
    const { forceRefresh = false } = options;

    const cacheKey = `item:${collectionId}:${itemId}`;

    // Browser-only memory cache.
    if (!this.isServer && !forceRefresh && this.cacheStrategy === "memory") {
      const cached = this.memoryCache.get<T>(cacheKey);

      if (cached && this.isCacheValid(cached.metadata)) {
        return cached.data;
      }
    }

    return this.requestBatcher.schedule(
      forceRefresh ? `${cacheKey}:refresh:${Date.now()}` : cacheKey,
      async () => {
        const params = new URLSearchParams();

        if (options.include?.length) {
          params.append("include", options.include.join(","));
        }

        const url =
          `${this.config.apiUrl}/content/` +
          `${this.config.projectId}/collection/` +
          `${collectionId}/${itemId}?${params}`;

        const fetchTags = [
          CacheTags.project(this.config.projectId),
          CacheTags.collection(collectionId),
          `item_${itemId}`,
          ...(options.tags || []),
        ];

        const res = await this.fetchWithTimeout(url, {
          method: "GET",
          headers: this.getHeaders(),
          tags: fetchTags,
          revalidate: options.revalidate ?? this.defaultRevalidate,
          forceRefresh,
        });

        if (!res.ok) {
          throw new Error(`API Error ${res.status}: ${res.statusText}`);
        }

        const json = await res.json();
        const data = json.data || json;

        if (!this.isServer) {
          this.writeCache(cacheKey, data, {
            revalidate: options.revalidate ?? this.defaultRevalidate,
            tags: fetchTags,
          });
        }

        return data;
      },
    );
  }

  async search<T = any>(
    query: string,
    options: {
      collections?: string[];
      fields?: string[];
      limit?: number;
      revalidate?: number | false;
      forceRefresh?: boolean;
    } = {},
  ): Promise<{ results: T[]; total: number }> {
    const params = new URLSearchParams({
      q: query,
      limit: (options.limit || 20).toString(),
    });

    if (options.collections?.length) {
      params.append("collections", options.collections.join(","));
    }

    if (options.fields?.length) {
      params.append("fields", options.fields.join(","));
    }

    const url =
      `${this.config.apiUrl}/content/` +
      `${this.config.projectId}/search?${params}`;

    const fetchTags = [
      CacheTags.project(this.config.projectId),
      ...(options.collections || []).map((collection) =>
        CacheTags.collection(collection),
      ),
    ];

    const res = await this.fetchWithTimeout(url, {
      method: "GET",
      headers: this.getHeaders(),
      tags: fetchTags,
      revalidate: options.revalidate ?? this.defaultRevalidate,
      forceRefresh: options.forceRefresh ?? false,
    });

    if (!res.ok) {
      throw new Error(`API Error ${res.status}: ${res.statusText}`);
    }

    return await res.json();
  }

  async prefetch(urls: string[]): Promise<void> {
    if (typeof window !== "undefined" && "requestIdleCallback" in window) {
      requestIdleCallback(async () => {
        await Promise.allSettled(
          urls.map((url) =>
            fetch(url, {
              priority: "low",
            } as RequestInit),
          ),
        );
      });
    }
  }

  subscribeToUpdates(callback: (data: any) => void): () => void {
    if (this.isServer || typeof EventSource === "undefined") {
      return () => {};
    }

    if (!this.config.apiKey) {
      return () => {};
    }

    let eventSource: EventSource | null = null;
    let retryCount = 0;
    let isClosed = false;

    const connect = () => {
      if (isClosed) return;

      const url =
        `${this.config.apiUrl}/content/` +
        `${this.config.projectId}/updates?key=` +
        `${this.config.apiKey ?? ""}`;

      eventSource = new EventSource(url);

      eventSource.onopen = () => {
        retryCount = 0;
      };

      eventSource.onmessage = (event) => {
        let data: any;

        try {
          data = JSON.parse(event.data);
        } catch {
          return;
        }

        if (!data || typeof data.type !== "string") {
          return;
        }

        if (data.type === "content.updated" && data.slug) {
          this.invalidateCache([CacheTags.content(data.slug)]);
        }

        if (data.type === "collection.updated" && data.collectionId) {
          this.invalidateCache([CacheTags.collection(data.collectionId)]);
        }

        if (data.type === "globals.updated") {
          this.invalidateCache([CacheTags.global]);
        }

        if (data.type === "schema.updated") {
          this.clearCache();
        }

        callback(data);
      };

      eventSource.onerror = () => {
        eventSource?.close();

        if (isClosed) return;

        const timeout = Math.min(1000 * Math.pow(2, retryCount), 30000);

        retryCount++;

        setTimeout(connect, timeout);
      };
    };

    connect();

    return () => {
      isClosed = true;
      eventSource?.close();
    };
  }

  private writeCache<T>(
    key: string,
    data: T,
    options: {
      revalidate: number | false;
      tags: string[];
    },
  ): void {
    // Browser cache should never be permanent.
    const ttlSeconds =
      options.revalidate === false ? 60 : Math.max(1, options.revalidate);

    if (this.cacheStrategy === "memory") {
      this.memoryCache.set(key, data, {
        tags: options.tags,
        ttl: ttlSeconds * 1000,
      });
    }
  }

  invalidateCache(tags: string[]): void {
    this.memoryCache.invalidateByTags(tags);

    if (this.browserCache) {
      this.browserCache.clear();
    }
  }

  clearCache(): void {
    this.memoryCache.clear();

    if (this.browserCache) {
      this.browserCache.clear();
    }
  }

  getCacheStats() {
    return {
      memory: this.memoryCache.getStats(),
      local: {
        loaded: this.localCache.isLoaded(),
      },
    };
  }

  private async fetchPage<T>(
    slug: string,
    cacheKey: string,
    tags: string[],
    revalidate: number | false,
    forceRefresh: boolean,
  ): Promise<CacheEntry<T>> {
    const url =
      `${this.config.apiUrl}/content/` +
      `${this.config.projectId}/page/${slug}`;

    const fetchTags = [
      CacheTags.project(this.config.projectId),
      CacheTags.content(slug),
      ...tags,
    ];

    const res = await this.fetchWithTimeout(url, {
      method: "GET",
      headers: this.getHeaders(),
      tags: fetchTags,
      revalidate,
      forceRefresh,
    });

    if (!res.ok) {
      if (res.status === 404) {
        throw new Error(`Page '${slug}' not found.`);
      }

      if (res.status === 408) {
        throw new Error("Request timeout");
      }

      throw new Error(`API Error ${res.status}: ${res.statusText}`);
    }

    const json: ContentResponse<T> = await res.json();
    const etag = res.headers.get("etag");

    const cacheEntry: CacheEntry<T> = {
      data: json.data,
      metadata: {
        timestamp: Date.now(),
        etag: etag || undefined,
        expiresAt:
          revalidate === false ? Infinity : Date.now() + revalidate * 1000,
        tags: fetchTags,
      },
    };

    if (!this.isServer) {
      this.writeCache(cacheKey, cacheEntry.data, {
        revalidate,
        tags: fetchTags,
      });
    }

    return cacheEntry;
  }

  private async fetchCollection<T>(
    collectionId: string,
    query: CollectionQuery,
    cacheKey: string,
    tags: string[],
    revalidate: number | false,
    forceRefresh: boolean,
  ): Promise<CacheEntry<CollectionResponse<T>>> {
    const params = buildQueryString(query);

    const url =
      `${this.config.apiUrl}/content/` +
      `${this.config.projectId}/collection/` +
      `${collectionId}?${params}`;

    const fetchTags = [
      CacheTags.project(this.config.projectId),
      CacheTags.collection(collectionId),
      ...tags,
    ];

    const res = await this.fetchWithTimeout(url, {
      method: "GET",
      headers: this.getHeaders(),
      tags: fetchTags,
      revalidate,
      forceRefresh,
    });

    if (!res.ok) {
      if (res.status === 408) {
        throw new Error("Request timeout");
      }

      throw new Error(`API Error ${res.status}: ${res.statusText}`);
    }

    const json: CollectionResponse<T> = await res.json();

    const etag = res.headers.get("etag");

    const cacheEntry: CacheEntry<CollectionResponse<T>> = {
      data: json,
      metadata: {
        timestamp: Date.now(),
        etag: etag || undefined,
        expiresAt:
          revalidate === false ? Infinity : Date.now() + revalidate * 1000,
        tags: fetchTags,
      },
    };

    if (!this.isServer) {
      this.writeCache(cacheKey, cacheEntry.data, {
        revalidate,
        tags: fetchTags,
      });
    }

    return cacheEntry;
  }

  private applyLocalQuery<T>(
    items: T[],
    query: CollectionQuery,
  ): CollectionResponse<T> {
    let filtered = [...items];

    if (query.search) {
      const searchLower = query.search.toLowerCase();

      filtered = filtered.filter((item) =>
        JSON.stringify(item).toLowerCase().includes(searchLower),
      );
    }

    if (query.filter) {
      filtered = filtered.filter((item) => {
        return Object.entries(query.filter!).every(([key, value]) => {
          const itemValue = (item as any)[key];

          if (itemValue === undefined) {
            return false;
          }

          if (Array.isArray(value)) {
            return value.includes(itemValue);
          }

          return itemValue === value;
        });
      });
    }

    if (query.sort) {
      filtered.sort((a, b) => {
        const aVal = (a as any)[query.sort!];
        const bVal = (b as any)[query.sort!];

        const order = query.order === "asc" ? 1 : -1;

        if (aVal < bVal) {
          return -1 * order;
        }

        if (aVal > bVal) {
          return 1 * order;
        }

        return 0;
      });
    }

    const page = query.page || 1;
    const limit = query.limit || 10;

    const start = (page - 1) * limit;
    const end = start + limit;
    const total = filtered.length;

    return {
      items: filtered.slice(start, end),
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasNext: end < total,
      hasPrev: start > 0,
    };
  }

  private async fetchWithTimeout(
    url: string,
    options: RequestInit & {
      timeout?: number;
      tags?: string[];
      revalidate?: number | false;
      forceRefresh?: boolean;
    } = {},
  ): Promise<Response> {
    const {
      timeout = this.config.timeout || 10000,
      tags = [],
      revalidate,
      forceRefresh = false,
      ...fetchOptions
    } = options;

    const controller = new AbortController();

    const id = setTimeout(() => controller.abort(), timeout);

    // Server-side cache authority:
    //
    // force-cache + revalidate:false = cache indefinitely.
    // Content updates should invalidate these entries using
    // revalidateTag() / revalidatePath().
    //
    // forceRefresh explicitly bypasses the Next.js Data Cache.
    const nextConfig = this.isServer
      ? ({
          cache: forceRefresh || revalidate === 0 ? "no-store" : "force-cache",

          ...(forceRefresh
            ? {}
            : {
                next: {
                  tags,
                  revalidate: revalidate === false ? false : revalidate,
                },
              }),
        } as any)
      : {};

    try {
      const response = await fetch(url, {
        ...fetchOptions,
        ...nextConfig,
        signal: controller.signal,
      });

      clearTimeout(id);

      return response;
    } catch (error) {
      clearTimeout(id);
      throw error;
    }
  }

  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      "Content-Type": "application/json",

      "X-GN-Apex-Client":
        `gnapex-sdk/` + `${this.config.sdkVersion ?? "1.1.6"}`,

      "X-GN-Apex-Request-ID":
        typeof crypto !== "undefined" && crypto.randomUUID
          ? crypto.randomUUID()
          : `nx_${Date.now()}_` + `${Math.random().toString(36).slice(2)}`,

      "X-GN-Apex-Project": this.config.projectId,
    };

    if (this.config.apiKey) {
      headers["Authorization"] = `Bearer ${this.config.apiKey}`;
    }

    return headers;
  }

  private isCacheValid(metadata: CacheMetadata): boolean {
    return Date.now() < metadata.expiresAt;
  }

  private normalizeError(error: any, context: string): Error {
    if (error instanceof Error) {
      const msg = error.message.toLowerCase();

      if (
        error.name === "AbortError" ||
        error.message.includes("408") ||
        msg.includes("timeout") ||
        msg.includes("aborted")
      ) {
        return new Error(`${context}: Request timeout`);
      }

      return error;
    }

    const str = String(error).toLowerCase();

    if (
      str.includes("408") ||
      str.includes("timeout") ||
      str.includes("aborted")
    ) {
      return new Error(`${context}: Request timeout`);
    }

    return new Error(`${context}: ${String(error)}`);
  }

  public cleanup(): void {
    if (!this.isServer) {
      window.removeEventListener("beforeunload", this.cleanup.bind(this));
    }
  }
}
