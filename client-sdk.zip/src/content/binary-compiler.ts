// packages/client-sdk/src/content/binary-compiler.ts

import * as crypto from "crypto";

export interface NxMetadata {
  version: string;
  compiledAt: string;
  projectId: string;
  schemaChecksum?: string;
}

export class BinaryCompiler {
  private static readonly MAGIC_HEADER = "NEXS"; // 4-byte ASCII magic identifier
  private static readonly ALGORITHM = "aes-256-cbc";

  /**
   * Generates a secure, deterministic cryptographic key from the project's API key.
   */
  private static deriveKeys(apiKey: string): {
    encryptionKey: Buffer;
    hmacKey: Buffer;
  } {
    // Hash the API key to generate a highly secure 32-byte key for AES-256
    const hash = crypto.createHash("sha256").update(apiKey).digest();

    // Split the hash or derive separate keys to maintain strict separation of concerns
    const encryptionKey = hash;
    const hmacKey = crypto
      .createHmac("sha256", apiKey)
      .update("nexus-integrity-key")
      .digest();

    return { encryptionKey, hmacKey };
  }

  /**
   * Compiles JSON content data into a secure, signed, and encrypted .nx binary buffer.
   */
  public static compile(
    data: any,
    apiKey: string,
    projectId: string,
    metadataOverrides: Partial<NxMetadata> = {},
  ): Buffer {
    const { encryptionKey, hmacKey } = this.deriveKeys(apiKey);

    // 1. Prepare Metadata block
    const metadata: NxMetadata = {
      version: "2.0.0",
      compiledAt: new Date().toISOString(),
      projectId,
      ...metadataOverrides,
    };
    const metadataStr = JSON.stringify(metadata);
    const metadataBuffer = Buffer.from(metadataStr, "utf-8");

    // 2. Encrypt Content Payload (AES-256-CBC)
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(this.ALGORITHM, encryptionKey, iv);

    const plainTextPayload = JSON.stringify(data);
    let encryptedPayload = cipher.update(plainTextPayload, "utf8");
    encryptedPayload = Buffer.concat([encryptedPayload, cipher.final()]);

    // Construct Payload block (IV + Encrypted Content)
    const payloadBuffer = Buffer.concat([iv, encryptedPayload]);

    // 3. Assemble Binary Layout
    const headerBuffer = Buffer.from(this.MAGIC_HEADER, "ascii");

    const metaLengthBuffer = Buffer.alloc(4);
    metaLengthBuffer.writeUInt32BE(metadataBuffer.length, 0);

    const payloadLengthBuffer = Buffer.alloc(4);
    payloadLengthBuffer.writeUInt32BE(payloadBuffer.length, 0);

    const prefixBlock = Buffer.concat([
      headerBuffer,
      metaLengthBuffer,
      metadataBuffer,
      payloadLengthBuffer,
      payloadBuffer,
    ]);

    // 4. Cryptographic Integrity: Generate HMAC SHA-256 signature of the entire block
    const hmac = crypto.createHmac("sha256", hmacKey);
    hmac.update(prefixBlock);
    const signature = hmac.digest(); // Exactly 32 bytes

    // Final compiled bundle
    return Buffer.concat([prefixBlock, signature]);
  }

  /**
   * Verifies, decrypts, and decompiles a .nx binary buffer back into clean, type-safe JSON.
   * Throws structured errors on integrity verification failures or file corruption.
   */
  public static decompile(
    buffer: Buffer,
    apiKey: string,
  ): { data: any; metadata: NxMetadata } {
    if (buffer.length < 44) {
      throw new Error(
        "Corrupted File: Binary payload is too short to be a valid Nexus node.",
      );
    }

    const { encryptionKey, hmacKey } = this.deriveKeys(apiKey);

    // 1. Verify Integrity (Extract and compare HMAC Signature)
    const prefixBlockLength = buffer.length - 32;
    const prefixBlock = buffer.subarray(0, prefixBlockLength);
    const expectedSignature = buffer.subarray(prefixBlockLength);

    const hmac = crypto.createHmac("sha256", hmacKey);
    hmac.update(prefixBlock);
    const actualSignature = hmac.digest();

    // Constant-time comparison to prevent timing attacks on your local environment
    if (!crypto.timingSafeEqual(expectedSignature, actualSignature)) {
      throw new Error(
        "DATA_INTEGRITY_VIOLATION: Cryptographic signature mismatch. " +
          "This local node has been modified externally or tampered with.",
      );
    }

    // 2. Verify Magic Header
    const magicHeader = prefixBlock.subarray(0, 4).toString("ascii");
    if (magicHeader !== this.MAGIC_HEADER) {
      throw new Error(
        "Invalid Format: File lacks the correct Nexus binary magic header.",
      );
    }

    // 3. Extract Metadata Block
    const metaLength = prefixBlock.readUInt32BE(4);
    const metaStart = 8;
    const metaEnd = metaStart + metaLength;
    const metadataStr = prefixBlock
      .subarray(metaStart, metaEnd)
      .toString("utf-8");
    const metadata: NxMetadata = JSON.parse(metadataStr);

    // 4. Extract & Decrypt Content Payload
    const payloadLength = prefixBlock.readUInt32BE(metaEnd);
    const payloadStart = metaEnd + 4;
    const payloadEnd = payloadStart + payloadLength;
    const payloadBuffer = prefixBlock.subarray(payloadStart, payloadEnd);

    // Extract IV (first 16 bytes) and Ciphertext
    const iv = payloadBuffer.subarray(0, 16);
    const cipherText = payloadBuffer.subarray(16);

    const decipher = crypto.createDecipheriv(this.ALGORITHM, encryptionKey, iv);
    let decrypted = decipher.update(cipherText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);

    const data = JSON.parse(decrypted.toString("utf8"));

    return { data, metadata };
  }
}
