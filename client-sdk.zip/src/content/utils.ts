// packages/client-sdk/src/content/utils.ts
/**
 * Utility functions for the Content Engine
 */

import { CollectionQuery } from '../types';

export function validateSlug(slug: string): void {
  if (!slug || typeof slug !== 'string') {
    throw new Error('Slug must be a non-empty string');
  }
  
  if (!/^[a-z0-9-_]+$/.test(slug)) {
    throw new Error('Slug can only contain lowercase letters, numbers, hyphens, and underscores');
  }
}

export function normalizeQuery(query: CollectionQuery): CollectionQuery {
  const normalized = { ...query };
  
  // Ensure defaults
  normalized.page = Math.max(1, normalized.page || 1);
  normalized.limit = Math.min(100, Math.max(1, normalized.limit || 10));
  normalized.order = normalized.order || 'desc';
  
  // Validate page and limit
  if (normalized.page < 1) {
    throw new Error('Page must be greater than 0');
  }
  
  if (normalized.limit < 1 || normalized.limit > 100) {
    throw new Error('Limit must be between 1 and 100');
  }
  
  return normalized;
}

export function buildQueryString(query: CollectionQuery): string {
  const params = new URLSearchParams();
  
  // Add standard parameters
  if (query.page) params.append('page', query.page.toString());
  if (query.limit) params.append('limit', query.limit.toString());
  if (query.sort) params.append('sort', query.sort);
  if (query.order) params.append('order', query.order);
  if (query.search) params.append('search', query.search);
  
  // Add includes
  if (query.include?.length) {
    params.append('include', query.include.join(','));
  }
  
  // Add fields
  if (query.fields?.length) {
    params.append('fields', query.fields.join(','));
  }
  
  // Add filters (as JSON)
  if (query.filter) {
    params.append('filter', JSON.stringify(query.filter));
  }
  
  return params.toString();
}

export function createCacheKey(...parts: string[]): string {
  return parts
    .map(part => 
      part
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '_')
        .replace(/_+/g, '_')
    )
    .join(':');
}

export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

export function deepMerge(target: any, source: any): any {
  const output = { ...target };
  
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target)) {
          output[key] = source[key];
        } else {
          output[key] = deepMerge(target[key], source[key]);
        }
      } else {
        output[key] = source[key];
      }
    });
  }
  
  return output;
}

function isObject(item: any): boolean {
  return item && typeof item === 'object' && !Array.isArray(item);
}

export function formatError(error: any): {
  message: string;
  code?: string;
  stack?: string;
} {
  if (error instanceof Error) {
    return {
      message: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    };
  }
  
  if (typeof error === 'object' && error !== null) {
    return {
      message: error.message || 'Unknown error',
      code: error.code,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    };
  }
  
  return {
    message: String(error)
  };
}

export function isBrowser(): boolean {
  return typeof window !== 'undefined' && typeof window.document !== 'undefined';
}

export function isServer(): boolean {
  return !isBrowser();
}

export function measurePerformance<T>(
  name: string,
  fn: () => T
): { result: T; duration: number } {
  const start = performance.now();
  const result = fn();
  const end = performance.now();
  
  if (process.env.NODE_ENV === 'development') {
    console.log(`⏱️ ${name}: ${(end - start).toFixed(2)}ms`);
  }
  
  return { result, duration: end - start };
}

export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function generateId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}