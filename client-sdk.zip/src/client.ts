// packages/client-sdk/src/client.ts

import { getFullConfig, validateConfig, SDK_VERSION } from "./config";
import { NexusConfig } from "./types";
import { ContentEngine } from "./content";
import { AnalyticsEngine } from "./analytics";
import { NexusHttpClient } from "./http";
import { NexusEventBus } from "./events";
import { FeatureFlags, RemoteConfig } from "./flags";
import { getDiagnostics } from "./diagnostics";

/**
 * GN-Apex client: intentionally zero-config for GN-Apex generated sites.
 * Platform configuration is discovered automatically; explicit overrides are
 * an escape hatch for SDK consumers, not a requirement for site developers.
 * Cache revalidation is FALSE by default on purpose: GN-Apex/Cloudflare owns
 * invalidation and purge, so immutable content can stay cached indefinitely.
 */
export class NexusClient {
  private config: NexusConfig;
  public content: ContentEngine;
  public analytics?: AnalyticsEngine;
  public readonly events: NexusEventBus;
  public readonly http: NexusHttpClient;
  public readonly flags: FeatureFlags;
  public readonly remoteConfig: RemoteConfig;

  constructor(config: Partial<NexusConfig> = {}) {
    const full = getFullConfig(config) as NexusConfig;

    this.config = {
      debug: false,
      cacheStrategy: "memory",
      revalidateTime: false,
      timeout: 10_000,
      retries: 3,
      sdkVersion: SDK_VERSION,
      cacheInvalidation: "platform",
      environment:
        typeof process !== "undefined" &&
        process.env?.NODE_ENV === "development"
          ? "development"
          : "production",
      autoTracking: true,
      publicKeyOnly: true,
      // 🚀 Default: fingerprinting: true (Active by default for high-precision analytics)
      privacy: { analytics: true, fingerprinting: true, redact: true },
      ...full,
      ...config,
    } as NexusConfig;

    const errors = validateConfig(this.config);
    if (errors.length && this.config.debug) {
      console.warn("[GN-Apex] Configuration warnings:", errors);
    }

    this.events = new NexusEventBus();
    this.http = new NexusHttpClient(this.config, this.events);
    this.flags = new FeatureFlags();
    this.remoteConfig = new RemoteConfig();
    this.content = new ContentEngine(this.config);

    if (
      typeof window !== "undefined" &&
      this.config.autoTracking !== false &&
      this.config.privacy?.analytics !== false
    ) {
      this.analytics = new AnalyticsEngine(this.config);
      this.analytics.start();
    }
  }

  /**
   * Helper alias for cleaner page content fetching.
   */
  public getPage<T = any>(slug: string, options?: any) {
    return this.content.getPage<T>(slug, options);
  }

  /**
   * Returns a readonly snapshot of the active configuration.
   */
  public getConfig(): Readonly<NexusConfig> {
    return Object.freeze({
      ...this.config,
      privacy: { ...this.config.privacy },
    });
  }

  /**
   * Updates runtime configuration dynamically without breaking active listeners.
   */
  public updateConfig(updates: Partial<NexusConfig>) {
    this.config = {
      ...this.config,
      ...updates,
      privacy: { ...this.config.privacy, ...updates.privacy },
    };

    this.http.updateConfig(this.config);
    this.content.updateConfig?.(this.config);

    if (
      typeof window !== "undefined" &&
      this.config.autoTracking !== false &&
      this.config.privacy?.analytics !== false &&
      !this.analytics
    ) {
      this.analytics = new AnalyticsEngine(this.config);
      this.analytics.start();
    }

    if (this.config.privacy?.analytics === false) {
      this.analytics?.stop();
    }
  }

  /**
   * Returns deep system diagnostics including HTTP and cache performance.
   */
  public diagnostics() {
    return {
      ...getDiagnostics(SDK_VERSION, this.config.environment ?? "production"),
      cache: this.content.getCacheStats(),
      http: this.http.getStats(),
      analyticsQueue: this.analytics ? undefined : 0,
    };
  }

  /**
   * Gracefully terminates background tasks and cleans up listeners.
   */
  public destroy() {
    this.analytics?.stop(true);
    this.content.cleanup?.();
    this.events.clear();
  }
}

// ⚡ GLOBAL SINGLETON
export const nexus = new NexusClient();

// Factory for cases where multiple isolated clients are needed
export const createNexusClient = (config: Partial<NexusConfig> = {}) =>
  new NexusClient(config);
