// packages/client-sdk/src/auth/context.tsx

"use client";

import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";
import { NexusConfig } from "../types";
import {
  AuthContextType,
  LoginCredentials,
  RegisterCredentials,
  SiteUser,
  AuthError,
} from "./types";
import { nexus } from "../client"; // Singleton access to Analytics

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({
  children,
  config,
}: {
  children: React.ReactNode;
  config: NexusConfig;
}) => {
  const [user, setUser] = useState<SiteUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<AuthError | null>(null);

  // The Auth Microservice Endpoint (NestJS)
  // Usually https://api.nexushub.com/v1/auth/project/{projectId}
  const AUTH_BASE = `${config.apiUrl}/auth/project/${config.projectId}`;

  // 1. Session Rehydration (On Load)
  const checkSession = useCallback(async () => {
    try {
      const res = await fetch(`${AUTH_BASE}/me`, {
        headers: getHeaders(config),
      });

      if (res.ok) {
        const data = await res.json();
        setUser(data.user);

        // 🧠 ANALYTICS HOOK:
        // Even on page refresh, we remind the analytics engine who is active
        if (nexus.analytics) {
          nexus.analytics.identify(data.user.id, {
            email: data.user.email,
            role: data.user.role,
            ...data.user.metadata,
          });
        }
      } else {
        setUser(null);
      }
    } catch (err) {
      // Network error or offline - keep user null but don't error hard
      console.debug("[GnApex Auth] Session check failed:", err);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, [AUTH_BASE, config]);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  // 2. Login Logic
  const login = async (creds: LoginCredentials) => {
    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch(`${AUTH_BASE}/login`, {
        method: "POST",
        headers: getHeaders(config),
        body: JSON.stringify(creds),
      });

      if (!res.ok) throw await parseError(res);

      const data = await res.json();
      setUser(data.user);

      // 🧠 IDENTITY STITCHING:
      // This is what makes the user show up in your CMS Dashboard
      if (nexus.analytics) {
        await nexus.analytics.identify(data.user.id, {
          email: data.user.email,
          role: data.user.role,
          login_method: "email",
          ...data.user.metadata,
        });
      }
    } catch (err: any) {
      setError(err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Register Logic
  const register = async (creds: RegisterCredentials) => {
    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch(`${AUTH_BASE}/register`, {
        method: "POST",
        headers: getHeaders(config),
        body: JSON.stringify(creds),
      });

      if (!res.ok) throw await parseError(res);

      const data = await res.json();
      setUser(data.user);

      // 🧠 IDENTITY STITCHING:
      // Track 'Sign Up' event automatically
      if (nexus.analytics) {
        nexus.analytics.track("signup", { method: "email" });
        nexus.analytics.identify(data.user.id, {
          email: data.user.email,
          role: data.user.role,
          ...data.user.metadata,
        });
      }
    } catch (err: any) {
      setError(err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // 4. Logout Logic
  const logout = async () => {
    setIsLoading(true);
    try {
      await fetch(`${AUTH_BASE}/logout`, {
        method: "POST",
        headers: getHeaders(config),
      });
    } catch (e) {
      console.warn("Logout network error", e);
    } finally {
      setUser(null);
      setIsLoading(false);
      // Reset Analytics context if needed, or just track the logout
      if (nexus.analytics) {
        nexus.analytics.track("logout");
      }
      // Note: We typically don't clear the analytics Session ID on logout,
      // because the same human is still on the same device.
    }
  };

  // 5. Profile Update
  const updateProfile = async (updates: Partial<SiteUser>) => {
    try {
      const res = await fetch(`${AUTH_BASE}/profile`, {
        method: "PATCH",
        headers: getHeaders(config),
        body: JSON.stringify(updates),
      });

      if (!res.ok) throw await parseError(res);

      const data = await res.json();
      setUser(data.user);

      // Update Analytics traits
      if (nexus.analytics) {
        nexus.analytics.identify(data.user.id, updates);
      }
    } catch (err: any) {
      setError(err);
      throw err;
    }
  };

  const requestPasswordReset = async (email: string) => {
    const res = await fetch(`${AUTH_BASE}/password/reset-request`, {
      method: "POST",
      headers: getHeaders(config),
      body: JSON.stringify({ email }),
    });
    if (!res.ok) throw await parseError(res);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        error,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        updateProfile,
        requestPasswordReset,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// --- HELPERS ---

export const useNexusAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useNexusAuth must be used within a NexusProvider");
  }
  return context;
};

function getHeaders(config: NexusConfig): HeadersInit {
  return {
    "Content-Type": "application/json",
    "x-nexus-project": config.projectId,
    Authorization: `Bearer ${config.apiKey}`, // 👈 CRITICAL: Send the nx_pk_ key

    // Note: We do NOT send the Master API Key here.
    // This is client-side. The backend uses Cookies or public tokens.
  };
}

async function parseError(res: Response): Promise<AuthError> {
  try {
    const json = await res.json();
    return {
      status: res.status,
      code: json.code || "UNKNOWN_ERROR",
      message: json.message || "An error occurred during authentication",
    };
  } catch {
    return {
      status: res.status,
      code: "NETWORK_ERROR",
      message: res.statusText,
    };
  }
}
