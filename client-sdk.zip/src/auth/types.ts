// packages/client-sdk/src/auth/types.ts

export interface SiteUser {
  id: string;
  email: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  avatarUrl?: string;
  role: string; // e.g. 'user', 'subscriber', 'admin'
  organizationId?: string; 
  organizationTraits?: Record<string, any>; // e.g. { "plan": "enterprise", "name": "Acme Corp" }
  metadata?: Record<string, any>; // Flexible JSON for custom app data
  createdAt: string;
}

export interface AuthState {
  user: SiteUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: AuthError | null;
}

export interface AuthError {
  code: string;
  message: string;
  status: number;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  metadata?: Record<string, any>;
}

export interface AuthContextType extends AuthState {
  login: (creds: LoginCredentials) => Promise<void>;
  register: (creds: RegisterCredentials) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<SiteUser>) => Promise<void>;
  requestPasswordReset: (email: string) => Promise<void>;
}