export type NexusErrorCode =
  | "CONFIGURATION_ERROR" | "NETWORK_ERROR" | "TIMEOUT" | "ABORTED"
  | "HTTP_ERROR" | "RATE_LIMITED" | "CIRCUIT_OPEN" | "NOT_FOUND"
  | "VALIDATION_ERROR" | "STORAGE_ERROR" | "UNKNOWN";

export class NexusError extends Error {
  readonly name = "NexusError";
  constructor(
    message: string,
    public readonly code: NexusErrorCode = "UNKNOWN",
    public readonly status?: number,
    public readonly requestId?: string,
    public readonly details?: unknown,
    public readonly retryable = false,
    public readonly cause?: unknown,
  ) { super(message); Object.setPrototypeOf(this, new.target.prototype); }
}

export const isNexusError = (e: unknown): e is NexusError => e instanceof NexusError;
