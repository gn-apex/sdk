// packages/client-sdk/src/__tests__/basic.test.ts
import { DEFAULT_API_URL } from "../config";

describe("Basic SDK Tests", () => {
  test("config has default API URL", () => {
    expect(DEFAULT_API_URL).toBe("https://api.gnapex.com");
  });

  test("jest is working", () => {
    expect(true).toBe(true);
  });
});
