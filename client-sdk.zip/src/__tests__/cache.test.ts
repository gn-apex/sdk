// packages/client-sdk/src/__tests__/cache.test.ts
import {
  MemoryCache,
  LocalCache,
  BrowserCache,
  CacheTags,
} from "../content/cache";

describe("MemoryCache", () => {
  let cache: MemoryCache;

  beforeEach(() => {
    cache = new MemoryCache();
  });

  describe("set and get", () => {
    test("stores and retrieves data", () => {
      const testData = { id: 1, name: "Test" };

      cache.set("test-key", testData);
      const result = cache.get("test-key");

      expect(result?.data).toEqual(testData);
    });

    test("returns null for non-existent key", () => {
      const result = cache.get("nonexistent");
      expect(result).toBeNull();
    });

    test("expires data after TTL", () => {
      const testData = { id: 1 };

      cache.set("test-key", testData, { ttl: -1000 }); // Already expired

      const result = cache.get("test-key");
      expect(result).toBeNull();
    });

    test("updates LRU timestamp on get", () => {
      const data1 = { id: 1 };
      const data2 = { id: 2 };

      cache.set("key1", data1);
      cache.set("key2", data2);

      // Access key1 to update its timestamp
      cache.get("key1");

      // Force eviction by setting max size to 1
      const smallCache = new MemoryCache({ maxSize: 1 });
      smallCache.set("key1", data1);
      smallCache.set("key2", data2); // Should evict key1 (least recently used)

      expect(smallCache.get("key1")).toBeNull();
      expect(smallCache.get("key2")).not.toBeNull();
    });
  });

  describe("invalidateByTags", () => {
    test("removes entries with matching tags", () => {
      const data1 = { id: 1 };
      const data2 = { id: 2 };

      cache.set("key1", data1, { tags: ["tag1", "tag2"] });
      cache.set("key2", data2, { tags: ["tag2", "tag3"] });

      cache.invalidateByTags(["tag1"]);

      expect(cache.get("key1")).toBeNull();
      expect(cache.get("key2")).not.toBeNull();
    });

    test("removes entries with any of the tags", () => {
      const data1 = { id: 1 };
      const data2 = { id: 2 };
      const data3 = { id: 3 };

      cache.set("key1", data1, { tags: ["tag1"] });
      cache.set("key2", data2, { tags: ["tag2"] });
      cache.set("key3", data3, { tags: ["tag3"] });

      cache.invalidateByTags(["tag1", "tag2"]);

      expect(cache.get("key1")).toBeNull();
      expect(cache.get("key2")).toBeNull();
      expect(cache.get("key3")).not.toBeNull();
    });
  });

  describe("eviction", () => {
    test("evicts LRU when max size reached", () => {
      const smallCache = new MemoryCache({ maxSize: 2 });

      smallCache.set("key1", { id: 1 });
      smallCache.set("key2", { id: 2 });
      smallCache.set("key3", { id: 3 }); // Should evict key1

      expect(smallCache.get("key1")).toBeNull();
      expect(smallCache.get("key2")).not.toBeNull();
      expect(smallCache.get("key3")).not.toBeNull();
    });
  });

  describe("stats", () => {
    test("tracks hits and misses", () => {
      cache.set("key1", { id: 1 });

      cache.get("key1"); // Hit
      cache.get("nonexistent"); // Miss
      cache.get("nonexistent2"); // Miss

      const stats = cache.getStats();

      expect(stats.hits).toBe(1);
      expect(stats.misses).toBe(2);
      expect(stats.hitRate).toBeCloseTo(0.333, 3);
    });
  });
});

describe("CacheTags", () => {
  test("generates project tag", () => {
    const tag = CacheTags.project("project-123");
    expect(tag).toBe("nexus_project_project-123");
  });

  test("generates content tag", () => {
    const tag = CacheTags.content("home-page");
    expect(tag).toBe("content_home-page");
  });

  test("generates collection tag", () => {
    const tag = CacheTags.collection("blog_posts");
    expect(tag).toBe("collection_blog_posts");
  });
});

describe("LocalCache", () => {
  let cache: LocalCache;

  beforeEach(() => {
    cache = new LocalCache();
  });

  test("isLoaded returns false by default", () => {
    expect(cache.isLoaded()).toBe(false);
  });

  test("getPage returns null for non-existent page", async () => {
    await expect(cache.getPage("nonexistent")).resolves.toBeNull();
  });

  test("getCollection returns null for non-existent collection", async () => {
    await expect(cache.getCollection("nonexistent")).resolves.toBeNull();
  });

  test("getGlobals returns null when no globals", async () => {
    await expect(cache.getGlobals()).resolves.toBeNull();
  });
});

// Note: BrowserCache tests would require mocking localStorage
