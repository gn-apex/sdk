// packages/client-sdk/src/__tests__/client.test.ts
import { NexusClient, createNexusClient, nexus } from "../client";
import { createMockConfig, mockFetchResponse } from "./utils";

describe("NexusClient", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("constructor", () => {
    test("creates client with provided config", () => {
      const config = createMockConfig();
      const client = new NexusClient(config);

      expect(client.content).toBeDefined();
    });

    test("merges env config with provided config", () => {
      process.env.NEXT_PUBLIC_NEXUS_ID = "env-project-id";
      const config = { apiKey: "manual-key" };
      const client = new NexusClient(config);

      // Note: This depends on your implementation
      expect(client.getConfig().projectId).toBe("env-project-id");
      expect(client.getConfig().apiKey).toBe("manual-key");
    });

    test("sets default values for optional fields", () => {
      const config = { projectId: "test-id", apiUrl: "https://test.url" };
      const client = new NexusClient(config);

      const fullConfig = client.getConfig();
      expect(fullConfig.debug).toBe(false);
      expect(fullConfig.cacheStrategy).toBe("memory");
      expect(fullConfig.revalidateTime).toBe(false); // platform-controlled cache-forever default, see README "Cache model"
      expect(fullConfig.timeout).toBe(10000);
      expect(fullConfig.retries).toBe(3);
    });
  });

  describe("getPage", () => {
    test("proxies to content engine", async () => {
      const client = new NexusClient(createMockConfig());
      const mockPage = { title: "Test Page", content: "Test content" };

      // Mock the content engine's getPage method
      client.content.getPage = jest.fn().mockResolvedValue(mockPage);

      const result = await client.getPage("home");

      expect(client.content.getPage).toHaveBeenCalledWith("home", undefined);
      expect(result).toEqual(mockPage);
    });

    test("passes options to content engine", async () => {
      const client = new NexusClient(createMockConfig());
      const options = { revalidate: 120, forceRefresh: true };

      client.content.getPage = jest.fn().mockResolvedValue({});

      await client.getPage("home", options);

      expect(client.content.getPage).toHaveBeenCalledWith("home", options);
    });
  });

  describe("global instance", () => {
    test("nexus is instantiated", () => {
      expect(nexus).toBeInstanceOf(NexusClient);
    });

    test("createNexusClient factory works", () => {
      const config = createMockConfig();
      const client = createNexusClient(config);

      expect(client).toBeInstanceOf(NexusClient);
      expect(client.getConfig().projectId).toBe(config.projectId);
    });
  });

  describe("getConfig", () => {
    test("returns readonly config copy", () => {
      const config = createMockConfig();
      const client = new NexusClient(config);

      const returnedConfig = client.getConfig();

      // Should be a copy, not reference
      expect(returnedConfig).toEqual(expect.objectContaining(config));
      expect(returnedConfig).not.toBe(client["config"]);
    });
  });
});
