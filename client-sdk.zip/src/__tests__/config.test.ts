// packages/client-sdk/src/__tests__/config.test.ts
import { 
  DEFAULT_API_URL, 
  getEnvConfig, 
  mergeConfigs, 
  validateConfig,
  hasRequiredConfig 
} from '../config';

describe('Config', () => {
  const originalEnv = process.env;

  beforeEach(() => {
    // Create a fresh copy of process.env for each test
    process.env = { ...originalEnv };
  });

  afterAll(() => {
    // Restore original process.env
    process.env = originalEnv;
  });

  describe('getEnvConfig', () => {
    test('returns default apiUrl when no env vars', () => {
      // Temporarily remove NEXUS env vars
      delete process.env.NEXT_PUBLIC_NEXUS_ID;
      delete process.env.NEXUS_PROJECT_ID;
      delete process.env.NEXT_PUBLIC_NEXUS_KEY;
      delete process.env.NEXUS_API_KEY;
      delete process.env.NEXT_PUBLIC_NEXUS_API_URL;
      delete process.env.NEXUS_API_URL;

      const config = getEnvConfig();
      expect(config.apiUrl).toBe(DEFAULT_API_URL);
      expect(config.projectId).toBeUndefined();
      expect(config.apiKey).toBeUndefined();
    });

    test('reads NEXT_PUBLIC_NEXUS_ID from env', () => {
      process.env.NEXT_PUBLIC_NEXUS_ID = 'public-project-id';
      const config = getEnvConfig();
      expect(config.projectId).toBe('public-project-id');
    });

    test('reads NEXUS_PROJECT_ID from env', () => {
      process.env.NEXUS_PROJECT_ID = 'project-id';
      const config = getEnvConfig();
      expect(config.projectId).toBe('project-id');
    });

    test('prefers NEXT_PUBLIC_NEXUS_ID over NEXUS_PROJECT_ID', () => {
      process.env.NEXT_PUBLIC_NEXUS_ID = 'public-id';
      process.env.NEXUS_PROJECT_ID = 'private-id';
      const config = getEnvConfig();
      expect(config.projectId).toBe('public-id');
    });

    test('reads API key from env', () => {
      process.env.NEXT_PUBLIC_NEXUS_KEY = 'public-key';
      process.env.NEXUS_API_KEY = 'private-key';
      const config = getEnvConfig();
      expect(config.apiKey).toBe('public-key');
    });

    test('reads custom API URL from env', () => {
      process.env.NEXT_PUBLIC_NEXUS_API_URL = 'https://custom.api.url';
      const config = getEnvConfig();
      expect(config.apiUrl).toBe('https://custom.api.url');
    });
  });

  describe('mergeConfigs', () => {
    test('merges configs correctly', () => {
      const base = { apiUrl: 'https://base.url', projectId: 'base-id' };
      const override = { projectId: 'override-id', apiKey: 'new-key' };
      const result = mergeConfigs(base, override);
      
      expect(result.apiUrl).toBe('https://base.url');
      expect(result.projectId).toBe('override-id');
      expect(result.apiKey).toBe('new-key');
    });

    test('uses default API URL when none provided', () => {
      const base = { projectId: 'test-id' };
      const result = mergeConfigs(base, {});
      expect(result.apiUrl).toBe(DEFAULT_API_URL);
    });
  });

  describe('validateConfig', () => {
    test('returns empty array for valid config', () => {
      const config = { projectId: 'test-id', apiUrl: 'https://api.url' };
      const errors = validateConfig(config);
      expect(errors).toHaveLength(0);
    });

    test('detects missing projectId', () => {
      const config = { apiUrl: 'https://api.url' };
      const errors = validateConfig(config);
      expect(errors).toContain('Missing projectId');
    });

    test('detects missing apiUrl', () => {
      const config = { projectId: 'test-id' };
      const errors = validateConfig(config);
      expect(errors).toContain('Missing apiUrl');
    });

    test('detects invalid apiUrl format', () => {
      const config = { projectId: 'test-id', apiUrl: 'invalid-url' };
      const errors = validateConfig(config);
      expect(errors).toContain('apiUrl must be a valid URL starting with http:// or https://');
    });
  });

  describe('hasRequiredConfig', () => {
    test('returns true for complete config', () => {
      const config = { projectId: 'test-id', apiUrl: 'https://api.url' };
      expect(hasRequiredConfig(config)).toBe(true);
    });

    test('returns false for incomplete config', () => {
      const config = { projectId: 'test-id' };
      expect(hasRequiredConfig(config)).toBe(false);
    });
  });
});