/**
 * @jest-environment-options {"url": "https://test.com/page"}
 *
 * packages/client-sdk/src/__tests__/analytics.test.ts
 *
 * window.location cannot be reassigned or redefined in this jsdom version
 * (its own property descriptor is { configurable: false }, so
 * Object.defineProperty always throws "Cannot redefine property: location"
 * no matter what descriptor you pass it). Setting the jsdom environment's
 * URL up front, once per file, is the supported way to control
 * window.location.{href,pathname,search,hash} for these tests.
 *
 * NOTE: this docblock must be the very first thing in the file (Jest only
 * scans for @jest-environment-options in the leading comment) — a `//`
 * comment above it, as this file originally had, silently prevents it
 * from being picked up and the environment falls back to localhost.
 */
import { AnalyticsEngine } from "../analytics";
import { eventStorage } from "../analytics/storage";
import { createMockConfig } from "./utils";

describe("AnalyticsEngine", () => {
  let analytics: AnalyticsEngine;
  let mockConfig: ReturnType<typeof createMockConfig>;

  beforeEach(() => {
    mockConfig = createMockConfig();
    analytics = new AnalyticsEngine(mockConfig);

    // Mock localStorage
    Object.defineProperty(window, "localStorage", {
      value: {
        getItem: jest.fn(() => null),
        setItem: jest.fn(),
        removeItem: jest.fn(),
        clear: jest.fn(),
      },
      writable: true,
    });

    // Mock fetch
    global.fetch = jest.fn().mockResolvedValue({ ok: true });

    // window.location is set for the whole file via the
    // @jest-environment-options docblock at the top of this file.

    Object.defineProperty(document, "referrer", {
      value: "https://referrer.com",
      writable: true,
    });

    Object.defineProperty(document, "title", {
      value: "Test Page",
      writable: true,
    });
  });

  afterEach(() => {
    analytics.stop();
    jest.clearAllMocks();
  });

  describe("start", () => {
    test("initializes analytics tracking", () => {
      const pageViewSpy = jest.spyOn(analytics, "pageView");

      analytics.start();

      expect(pageViewSpy).toHaveBeenCalled();
    });

    test("sets up click tracking", async () => {
      // NOTE: pageView()/track()/click tracking route through
      // Tracker.send(), which enqueues into eventStorage (offline
      // IndexedDB-backed queue) and only actually calls fetch on the
      // 5s flush interval, a queued-count>=10 threshold, or for
      // purchase/identify events — see tracker.ts send()/startFlushing().
      // A single click does not trigger an immediate network call, so
      // the observable contract here is "the event was enqueued", not
      // "fetch was called".
      const enqueueSpy = jest.spyOn(eventStorage, "enqueue");

      analytics.start();

      const link = document.createElement("a");
      link.href = "https://test.com";
      link.innerText = "Test Link";
      document.body.appendChild(link);

      link.click();

      // Yield to the event loop for the async send() chain to run
      await new Promise((resolve) => setTimeout(resolve, 50));

      expect(enqueueSpy).toHaveBeenCalledWith(
        expect.objectContaining({ eventType: "click" }),
      );
    });
  });

  describe("pageView", () => {
    test("tracks page view with correct data", async () => {
      // See note above: pageView() enqueues rather than fetching
      // immediately under the current batched-flush architecture.
      const enqueueSpy = jest.spyOn(eventStorage, "enqueue");

      analytics.pageView();

      await new Promise((resolve) => setTimeout(resolve, 50));

      expect(enqueueSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          eventType: "page_view",
          url: "https://test.com/page",
        }),
      );
    });
  });

  describe("identify", () => {
    test("links user to session", async () => {
      const mockUserId = "user-123";
      const mockTraits = { name: "John Doe", email: "john@example.com" };

      const result = await analytics.identify(mockUserId, mockTraits);

      expect(result).toBe(true);
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining("/api/identify"),
        expect.objectContaining({
          method: "POST",
          headers: expect.objectContaining({
            "Content-Type": "application/json",
          }),
          body: expect.any(String),
        }),
      );
    });

    test("handles identify errors", async () => {
      (global.fetch as jest.Mock).mockRejectedValue(new Error("Network error"));

      const result = await analytics.identify("user-123", {});

      expect(result).toBe(false);
    });
  });

  describe("track", () => {
    test("tracks custom events", async () => {
      // See note in "sets up click tracking": track() enqueues rather
      // than fetching immediately under the current batched-flush
      // architecture.
      const enqueueSpy = jest.spyOn(eventStorage, "enqueue");
      const eventName = "button_clicked";
      const properties = { button_id: "submit-btn", section: "form" };

      analytics.track(eventName, properties);

      await new Promise((resolve) => setTimeout(resolve, 50));

      expect(enqueueSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          eventType: "custom_event",
          eventName: "button_clicked",
        }),
      );
    });
  });

  describe("session management", () => {
    test("generates session ID", () => {
      const sessionId = analytics.getSessionId();

      expect(sessionId).toBeTruthy();
    });

    test("session ID persists in localStorage", () => {
      const setItemSpy = jest.spyOn(window.localStorage, "setItem");

      analytics.start();

      expect(setItemSpy).toHaveBeenCalledWith("nexus_sid", expect.any(String));
    });
  });
});
