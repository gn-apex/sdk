// packages/client-sdk/src/__tests__/content.test.ts
import { describe, beforeEach, test, expect, jest } from "@jest/globals";
import { ContentEngine } from "../content";
import { createMockConfig, mockFetchResponse, mockFetchError } from "./utils";

describe("ContentEngine", () => {
  let contentEngine: ContentEngine;
  let mockConfig: ReturnType<typeof createMockConfig>;

  beforeEach(() => {
    mockConfig = createMockConfig();
    contentEngine = new ContentEngine(mockConfig);
    jest.clearAllMocks();
  });

  describe("getPage", () => {
    test("fetches page from API", async () => {
      const mockPage = {
        id: "page-1",
        type: "page",
        data: { title: "Home", content: "Welcome" },
        meta: { version: 1, updatedAt: "2024-01-01", cacheStatus: "miss" },
      };

      mockFetchResponse(mockPage);

      const result = await contentEngine.getPage("home");

      expect(fetch).toHaveBeenCalledWith(
        `${mockConfig.apiUrl}/content/${mockConfig.projectId}/page/home`,
        expect.objectContaining({
          method: "GET",
          headers: expect.objectContaining({
            Authorization: `Bearer ${mockConfig.apiKey}`,
            "Content-Type": "application/json",
          }),
        }),
      );

      expect(result).toEqual(mockPage.data);
    });

    test("handles API errors", async () => {
      mockFetchError(404, "Page not found");

      await expect(contentEngine.getPage("nonexistent")).rejects.toThrow(
        /Page 'nonexistent' not found/,
      );
    });

    test("uses cache when available", async () => {
      const mockPage = { title: "Cached Page" };

      // Mock memory cache to return data
      (contentEngine as any).memoryCache.get = jest.fn().mockReturnValue({
        data: mockPage,
        metadata: { expiresAt: Date.now() + 60000 }, // Valid for 1 minute
      });

      const result = await contentEngine.getPage("cached-page");

      expect(result).toEqual(mockPage);
      expect(fetch).not.toHaveBeenCalled(); // Should use cache
    });

    test("falls back to stale cache on API failure", async () => {
      const staleData = { title: "Stale Page" };

      // Set stale cache
      (contentEngine as any).memoryCache.get = jest.fn().mockReturnValue({
        data: staleData,
        metadata: { expiresAt: Date.now() + 60000 },
      });

      mockFetchError(500, "Internal Server Error");

      const result = await contentEngine.getPage("problematic-page");

      expect(result).toEqual(staleData);
    });
  });

  describe("getCollection", () => {
    test("fetches collection with pagination", async () => {
      const mockResponse = {
        items: [{ id: "1", title: "Post 1" }],
        total: 10,
        page: 1,
        limit: 10,
        totalPages: 1,
        hasNext: false,
        hasPrev: false,
      };

      mockFetchResponse(mockResponse);

      const query = {
        page: 1,
        limit: 10,
        sort: "created_at",
        order: "desc" as const,
      };
      const result = await contentEngine.getCollection("blog_posts", query);

      expect(fetch).toHaveBeenCalledWith(
        expect.stringContaining(`page=1&limit=10&sort=created_at&order=desc`),
        expect.any(Object),
      );

      expect(result.items).toEqual(mockResponse.items);
      expect(result.total).toBe(10);
    });

    test("handles collection query with filters", async () => {
      const mockResponse = {
        items: [],
        total: 0,
        page: 1,
        limit: 10,
        totalPages: 0,
        hasNext: false,
        hasPrev: false,
      };

      mockFetchResponse(mockResponse);

      const query = {
        filter: { status: "published", category: "tech" },
        search: "typescript",
      };

      await contentEngine.getCollection("posts", query);

      const callUrl = (fetch as any).mock.calls[0][0];
      expect(callUrl).toContain("search=typescript");
    });

    test("caches collection responses", async () => {
      const mockResponse = {
        items: [{ id: "1", title: "Cached Post" }],
        total: 1,
        page: 1,
        limit: 10,
        totalPages: 1,
        hasNext: false,
        hasPrev: false,
      };

      mockFetchResponse(mockResponse);

      // First call - should fetch from API
      await contentEngine.getCollection("cached_posts", { page: 1, limit: 10 });

      expect(fetch).toHaveBeenCalledTimes(1);

      // Reset fetch mock
      (fetch as any).mockClear();

      // Second call - should use cache
      await contentEngine.getCollection("cached_posts", { page: 1, limit: 10 });

      expect(fetch).not.toHaveBeenCalled();
    });
  });

  describe("getGlobals", () => {
    test("fetches global settings", async () => {
      const mockGlobals = {
        siteName: "Test Site",
        navigation: [{ label: "Home", href: "/" }],
        footer: { copyright: "© 2024" },
      };

      mockFetchResponse({ data: mockGlobals });

      const result = await contentEngine.getGlobals();

      expect(fetch).toHaveBeenCalledWith(
        `${mockConfig.apiUrl}/content/${mockConfig.projectId}/globals`,
        expect.any(Object),
      );

      expect(result).toEqual(mockGlobals);
    });

    test("includes query parameters", async () => {
      mockFetchResponse({ data: {} });

      await contentEngine.getGlobals({ include: ["navigation", "footer"] });

      const callUrl = (fetch as any).mock.calls[0][0];
      expect(callUrl).toContain("include=navigation,footer");
    });
  });

  describe("cache management", () => {
    test("invalidateCache removes entries by tags", () => {
      const invalidateSpy = jest.spyOn(
        (contentEngine as any).memoryCache,
        "invalidateByTags",
      );

      const tags = ["content_home", "collection_posts"];
      contentEngine.invalidateCache(tags);

      expect(invalidateSpy).toHaveBeenCalledWith(tags);
    });

    test("clearCache clears all caches", () => {
      const clearSpy = jest.spyOn((contentEngine as any).memoryCache, "clear");

      contentEngine.clearCache();

      expect(clearSpy).toHaveBeenCalled();
    });

    test("getCacheStats returns statistics", () => {
      const stats = contentEngine.getCacheStats();

      expect(stats).toHaveProperty("memory");
      expect(stats).toHaveProperty("local");
      expect(stats.memory).toHaveProperty("size");
      expect(stats.memory).toHaveProperty("hits");
      expect(stats.memory).toHaveProperty("misses");
    });
  });

  describe("error handling", () => {
    test("retries failed requests", async () => {
      mockFetchError(500, "Internal Error");

      const retryConfig = { ...mockConfig, retries: 2 };
      const retryEngine = new ContentEngine(retryConfig);

      await expect(retryEngine.getPage("retry-test")).rejects.toThrow();

      // Initial request + 2 retries = 3 calls total
      expect(fetch).toHaveBeenCalledTimes(3);
    });

    test("times out slow requests", async () => {
      (fetch as any).mockImplementation(
        (_url: string, options?: { signal?: AbortSignal }) =>
          new Promise((_, reject) => {
            if (options?.signal) {
              options.signal.addEventListener("abort", () => {
                const err = new Error("The operation was aborted.");
                err.name = "AbortError";
                reject(err);
              });
            }
          }),
      );

      const timeoutConfig = { ...mockConfig, timeout: 50 };
      const timeoutEngine = new ContentEngine(timeoutConfig);

      await expect(timeoutEngine.getPage("slow-page")).rejects.toThrow(
        /Request timeout/,
      );
    });
  });
});
