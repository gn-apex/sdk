// packages/client-sdk/src/__tests__/utils.ts
export const mockFetchResponse = (data: any, options: any = {}) => {
  (global.fetch as jest.Mock).mockResolvedValue({
    ok: options.ok !== false,
    status: options.status || 200,
    statusText: options.statusText || 'OK',
    headers: {
      get: (header: string) => options.headers?.[header] || null,
      ...options.headers
    },
    json: () => Promise.resolve(data),
    text: () => Promise.resolve(JSON.stringify(data)),
    ...options
  });
};

export const mockFetchError = (status: number, message: string) => {
  (global.fetch as jest.Mock).mockResolvedValue({
    ok: false,
    status,
    statusText: message,
    json: () => Promise.reject(new Error(message)),
    text: () => Promise.reject(new Error(message))
  });
};

export const createMockConfig = (overrides = {}) => ({
  apiUrl: 'https://api.nexushub.com/v1',
  apiKey: 'test-api-key',
  projectId: 'test-project-id',
  debug: false,
  cacheStrategy: 'memory' as const,
  revalidateTime: 60,
  timeout: 10000,
  retries: 3,
  ...overrides
});

export const mockLocalStorage = () => {
  let store: Record<string, string> = {};
  
  return {
    getItem: jest.fn((key: string) => store[key] || null),
    setItem: jest.fn((key: string, value: string) => {
      store[key] = value;
    }),
    removeItem: jest.fn((key: string) => {
      delete store[key];
    }),
    clear: jest.fn(() => {
      store = {};
    }),
    key: jest.fn((index: number) => Object.keys(store)[index] || null),
    get length() {
      return Object.keys(store).length;
    }
  };
};

export const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to create a mock Response object
export const createMockResponse = (data: any, options: ResponseInit = {}) => {
  return {
    ok: options.status ? options.status >= 200 && options.status < 300 : true,
    status: options.status || 200,
    statusText: options.statusText || 'OK',
    headers: new Map(Object.entries(options.headers || {})),
    json: () => Promise.resolve(data),
    text: () => Promise.resolve(JSON.stringify(data)),
    ...options
  };
};