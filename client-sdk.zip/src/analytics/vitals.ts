// packages/client-sdk/src/analytics/vitals.ts
import { onCLS, onLCP, onTTFB, onINP, onFCP, type Metric } from "web-vitals";
import { Tracker } from "./tracker";

export interface PerformanceMetrics {
  ttfb?: number;
  lcp?: number;
  cls?: number;
  inp?: number;
  fcp?: number;
  navigation_timing?: NavigationTimingData;
  resources?: ResourceTimingEntry[]; // Resource waterfall
  memory_usage?: MemoryData; // Chromium JS heap snapshot
}

interface NavigationTimingData {
  dns_lookup: number;
  tcp_connect: number;
  request_time: number;
  dom_load: number;
  domain_lookup_start: number;
  domain_lookup_end: number;
  connect_start: number;
  connect_end: number;
  secure_connection_start?: number;
}

interface ResourceTimingEntry {
  name: string;
  initiatorType: string;
  duration: number;
  transferSize?: number;
  encodedBodySize?: number;
  decodedBodySize?: number;
  startTime: number;
  responseEnd: number;
}

interface MemoryData {
  used_js_heap_size: number;
  total_js_heap_size: number;
  js_heap_size_limit: number;
}

type WebVitalKey = "ttfb" | "lcp" | "cls" | "inp" | "fcp";

const METRIC_KEY_MAP: Record<
  Metric["name"],
  WebVitalKey & keyof PerformanceMetrics
> = {
  CLS: "cls",
  LCP: "lcp",
  INP: "inp",
  TTFB: "ttfb",
  FCP: "fcp",
};

class VitalsCollector {
  private metrics: PerformanceMetrics = {};
  private hasUpdates = false;

  constructor() {
    if (typeof window !== "undefined") {
      this.init();
    }
  }

  private init() {
    const recordMetric = (metric: Metric) => {
      const key = METRIC_KEY_MAP[metric.name];
      (this.metrics as any)[key] = metric.value;
      this.hasUpdates = true;
    };

    onCLS(recordMetric);
    onLCP(recordMetric);
    onTTFB(recordMetric);
    onINP(recordMetric);
    onFCP(recordMetric);

    // 1. Navigation Timing (Expanded to match Rust structs)
    const navEntry = performance.getEntriesByType("navigation")[0] as
      | PerformanceNavigationTiming
      | undefined;

    if (navEntry) {
      this.metrics.navigation_timing = {
        dns_lookup: navEntry.domainLookupEnd - navEntry.domainLookupStart,
        tcp_connect: navEntry.connectEnd - navEntry.connectStart,
        request_time: navEntry.responseEnd - navEntry.requestStart,
        dom_load: navEntry.domComplete - navEntry.domInteractive,
        domain_lookup_start: navEntry.domainLookupStart,
        domain_lookup_end: navEntry.domainLookupEnd,
        connect_start: navEntry.connectStart,
        connect_end: navEntry.connectEnd,
        secure_connection_start:
          navEntry.secureConnectionStart > 0
            ? navEntry.secureConnectionStart
            : undefined,
      };
      this.hasUpdates = true;
    }

    // 2. Resource Waterfall (Capped to top 5 slowest to prevent 413 Payload Too Large)
    const resourceEntries = performance.getEntriesByType(
      "resource",
    ) as PerformanceResourceTiming[];

    if (resourceEntries.length > 0) {
      this.metrics.resources = resourceEntries
        .filter(
          (r) =>
            !r.name.includes("/api/collect") &&
            !r.name.includes("/analytics") &&
            !r.name.includes("sentry.gnapex.com"),
        )
        .sort((a, b) => b.duration - a.duration)
        .slice(0, 5)
        .map((r) => ({
          name: r.name.length > 120 ? r.name.substring(0, 120) + "..." : r.name,
          initiatorType: r.initiatorType,
          duration: Math.round(r.duration),
          transferSize: r.transferSize > 0 ? r.transferSize : undefined,
          encodedBodySize:
            r.encodedBodySize > 0 ? r.encodedBodySize : undefined,
          decodedBodySize:
            r.decodedBodySize > 0 ? r.decodedBodySize : undefined,
          startTime: Math.round(r.startTime),
          responseEnd: Math.round(r.responseEnd),
        }));
      this.hasUpdates = true;
    }

    // 3. Chromium JS Heap Memory Snapshot
    const mem = (performance as any).memory;
    if (mem) {
      this.metrics.memory_usage = {
        used_js_heap_size: mem.usedJSHeapSize,
        total_js_heap_size: mem.totalJSHeapSize,
        js_heap_size_limit: mem.jsHeapSizeLimit,
      };
      this.hasUpdates = true;
    }
  }

  public getMetricsSnapshot(): PerformanceMetrics | null {
    if (!this.hasUpdates) return null;
    this.hasUpdates = false;
    const snapshot = { ...this.metrics };
    // Clear resources after snapshot so the next page navigation starts fresh
    this.metrics.resources = undefined;
    return snapshot;
  }
}

export const vitalsCollector = new VitalsCollector();

export const initVitals = (_tracker: Tracker) => {
  if (process.env.NODE_ENV === "development") {
    console.log("[GN-Apex] Web Vitals monitoring active");
  }
};
