// packages/client-sdk/src/analytics/tracker.ts
import { NexusConfig } from "../types";
import { SDK_VERSION } from "../config";
import { getDeviceEntropy, getVisitorId } from "./fingerprint";
import { vitalsCollector, PerformanceMetrics } from "./vitals";
import { eventStorage } from "./storage";
import { CircuitBreaker } from "../content/strategies";

interface AnalyticsPayload {
  projectId: string;
  sessionId: string;
  visitorId: string;
  anonymousId?: string;
  messageId: string;
  sentAt: string;
  version: string;
  url: string;
  referrer?: string;
  userAgent?: string;
  screenWidth?: number;
  screenHeight?: number;
  language?: string;
  timezone?: string;
  eventType: string;
  eventName?: string;
  eventData?: any;
  ecommerce?: EcommercePayload;
  performance?: PerformanceMetrics;
  context?: any;
  clientTimestamp: string;
}

export interface EcommercePayload {
  orderId?: string;
  total?: number;
  revenue?: number;
  currency?: string;
  products?: Array<{
    productId: string;
    sku?: string;
    name: string;
    price: number;
    quantity: number;
  }>;
}

// --- DEFENSIVE STORAGE HELPERS ---
const safeGetItem = (key: string): string | null => {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
};

const safeSetItem = (key: string, value: string): void => {
  try {
    localStorage.setItem(key, value);
  } catch {
    // In-memory or silent fallback
  }
};

const safeRemoveItem = (key: string): void => {
  try {
    localStorage.removeItem(key);
  } catch {
    // Silent fallback
  }
};

// --- RFC4122 COMPLIANT CRYPTO FALLBACK ---
const generateUUID = (): string => {
  if (
    typeof crypto !== "undefined" &&
    typeof crypto.randomUUID === "function"
  ) {
    return crypto.randomUUID();
  }
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

export class Tracker {
  private config: NexusConfig;
  private sessionId: string = "";
  private visitorId: string = "";
  private anonymousId: string = "";
  private sessionStart: number;
  private isFlushing = false;
  private flushInterval?: ReturnType<typeof setInterval>;
  private endpoint: string;
  private circuitBreaker: CircuitBreaker;
  private flushPromise: Promise<void> | null = null;
  // 🛡️ Batch size set to 10 to keep payloads strictly under Actix 32KB limit
  private readonly batchSize = 10;

  constructor(config: NexusConfig) {
    this.config = config;
    this.endpoint = `${this.config.analyticsUrl}/api/collect`;
    this.circuitBreaker = new CircuitBreaker();
    this.sessionStart = Date.now();

    if (typeof window !== "undefined") {
      this.initSession();
      this.startFlushing();
    }
  }

  private async initSession() {
    this.visitorId = await getVisitorId(
      this.config.privacy?.fingerprinting ?? true,
    );

    let anonId = safeGetItem("nexus_anon_id");
    if (!anonId) {
      anonId = `anon_${generateUUID().replace(/-/g, "")}`;
      safeSetItem("nexus_anon_id", anonId);
    }
    this.anonymousId = anonId;

    let sid = safeGetItem("nexus_sid");
    const lastActivity = safeGetItem("nexus_last_active");
    const now = Date.now();
    const SESSION_TIMEOUT = 30 * 60 * 1000;

    const isExpired =
      !sid ||
      !lastActivity ||
      now - parseInt(lastActivity, 10) > SESSION_TIMEOUT;

    if (isExpired) {
      const uuid = generateUUID().replace(/-/g, "").substring(0, 16);
      sid = `sess_${uuid}_${now}`;
      safeSetItem("nexus_sid", sid);
      this.sessionStart = now;
    }

    safeSetItem("nexus_last_active", now.toString());
    this.sessionId = sid!;
  }

  public async send(
    eventType: string,
    data: any = {},
    eventName?: string,
    ecommerce?: EcommercePayload,
  ) {
    if (typeof window === "undefined") return;

    safeSetItem("nexus_last_active", Date.now().toString());

    const entropy = await getDeviceEntropy(
      this.config.privacy?.fingerprinting ?? true,
    );

    // 🛡️ Only attach heavy performance waterfall metrics to page_view events
    const isPageView = eventType === "page_view" || eventType === "performance";
    const perfMetrics = isPageView
      ? vitalsCollector.getMetricsSnapshot()
      : undefined;
    const utmParams = isPageView
      ? extractUtmParams(window.location.href)
      : undefined;

    const payload: AnalyticsPayload = {
      projectId: this.config.projectId,
      sessionId: this.sessionId,
      visitorId: this.visitorId,
      anonymousId: this.anonymousId,
      messageId: generateUUID(),
      sentAt: new Date().toISOString(),
      version: SDK_VERSION,

      url: window.location.href,
      referrer: isPageView ? document.referrer : undefined,
      userAgent: isPageView ? window.navigator.userAgent : undefined,
      screenWidth: window.screen.width,
      screenHeight: window.screen.height,
      language: window.navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,

      eventType,
      eventName,
      eventData: data,
      ecommerce: ecommerce ?? undefined,

      performance: perfMetrics || undefined,
      context: {
        device: {
          hardwareConcurrency: entropy.hardware_concurrency,
          deviceMemory: entropy.device_memory,
          pixelRatio: entropy.pixel_ratio,
          platform: entropy.platform,
          ...(this.config.privacy?.fingerprinting
            ? { canvasFingerprint: entropy.canvas_hash }
            : {}),
        },
        visitorIdLocal: this.visitorId,
        utm: utmParams,
      },

      clientTimestamp: new Date().toISOString(),
    };

    await eventStorage.enqueue(payload);

    const count = await eventStorage.count();
    if (count >= 10 || eventType === "purchase" || eventType === "identify") {
      this.flushQueue();
    }
  }

  private startFlushing() {
    this.flushInterval = setInterval(() => this.flushQueue(), 5000);

    window.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") this.flushQueue(true);
    });
  }

  private async flushQueue(useBeacon = false) {
    if (this.flushPromise) return this.flushPromise;
    this.flushPromise = (async () => {
      if (this.circuitBreaker.isOpen()) return;
      try {
        const storedEvents = await eventStorage.peek(this.batchSize);
        if (!storedEvents.length) return;
        const payloads = storedEvents.map((e) => e.payload);
        const headers = {
          "Content-Type": "application/json",
          Authorization: this.config.apiKey
            ? `Bearer ${this.config.apiKey}`
            : "",
          "X-Nexus-Client": `analytics/${SDK_VERSION}`,
          "X-Nexus-Project": this.config.projectId,
        };

        let response: Response | undefined;
        try {
          response = await fetch(
            `${this.config.analyticsUrl}/api/collect/batch`,
            {
              method: "POST",
              headers,
              body: JSON.stringify({ events: payloads }),
              keepalive: useBeacon,
            },
          );
        } catch {
          response = undefined;
        }

        // 🛡️ FIX 413: If server rejects payload size, immediately evict oversized events from IndexedDB
        if (response && response.status === 413) {
          await eventStorage.remove(storedEvents.map((e) => e.id!));
          return;
        }

        if (!response || response.status === 404 || response.status === 405) {
          const results = await Promise.allSettled(
            payloads.map((event) =>
              fetch(this.endpoint, {
                method: "POST",
                headers,
                body: JSON.stringify(event),
                keepalive: useBeacon,
              }),
            ),
          );
          const successIds = results.flatMap((r, i) =>
            r.status === "fulfilled" && (r.value.ok || r.value.status === 413)
              ? [storedEvents[i].id!]
              : [],
          );
          if (successIds.length) await eventStorage.remove(successIds);
          if (successIds.length === storedEvents.length) {
            this.circuitBreaker.recordSuccess();
          } else {
            this.circuitBreaker.recordFailure();
          }
        } else if (response.ok) {
          await eventStorage.remove(storedEvents.map((e) => e.id!));
          this.circuitBreaker.recordSuccess();
        } else {
          this.circuitBreaker.recordFailure();
        }
      } catch (err) {
        this.circuitBreaker.recordFailure();
        if (this.config.debug) {
          console.warn("[GN-Apex] Analytics flush deferred:", err);
        }
      } finally {
        this.flushPromise = null;
      }
    })();
    return this.flushPromise;
  }

  public getSession(): string {
    return this.sessionId;
  }

  public getVisitorId(): string {
    return this.visitorId;
  }

  public getAnonymousId(): string {
    return this.anonymousId;
  }

  public getSessionDuration(): number {
    return Date.now() - this.sessionStart;
  }

  public clearIdentity() {
    safeRemoveItem("nexus_anon_id");
    this.anonymousId = "";
  }

  public stop() {
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
    }
    this.flushQueue(true);
  }
}

function extractUtmParams(url: string): Record<string, string> {
  try {
    const params = new URL(url).searchParams;
    const utmKeys = [
      "utm_source",
      "utm_medium",
      "utm_campaign",
      "utm_term",
      "utm_content",
    ];
    const result: Record<string, string> = {};
    utmKeys.forEach((key) => {
      const val = params.get(key);
      if (val) result[key] = val;
    });
    return result;
  } catch {
    return {};
  }
}
