// packages/client-sdk/src/analytics/fingerprint.ts
/**
 * GnApex Hardware Fingerprinting & Entropy Collection
 * Captures immutable device signals to feed the Rust Security Engine.
 */

export interface DeviceEntropy {
  screen_resolution: string;
  color_depth: number;
  pixel_ratio: number;
  hardware_concurrency?: number;
  device_memory?: number;
  timezone_offset: number;
  platform: string;
  language: string;
  touch_support: boolean;
  canvas_hash?: string;
}

let cachedEntropy: DeviceEntropy | null = null;

/**
 * Collects lightweight hardware entropy.
 * Canvas drawing is executed by default (allowFingerprinting = true).
 */
export const getDeviceEntropy = async (
  allowFingerprinting = true,
): Promise<DeviceEntropy> => {
  if (cachedEntropy) return cachedEntropy;

  if (typeof window === "undefined") return {} as DeviceEntropy;

  const nav = window.navigator as any;

  cachedEntropy = {
    screen_resolution: `${window.screen.width}x${window.screen.height}`,
    color_depth: window.screen.colorDepth,
    pixel_ratio: window.devicePixelRatio || 1,
    hardware_concurrency: nav.hardwareConcurrency,
    device_memory: nav.deviceMemory, // Chrome/Edge only
    timezone_offset: new Date().getTimezoneOffset(),
    platform: nav.platform,
    language: nav.language,
    touch_support: "ontouchstart" in window || nav.maxTouchPoints > 0,
    canvas_hash: allowFingerprinting ? await generateCanvasHash() : undefined,
  };

  return cachedEntropy;
};

/**
 * Generates a non-invasive Canvas Fingerprint.
 * Different GPUs and font renderers produce subtly different pixel outputs,
 * creating a stable device signal without persistent cookies.
 */
const generateCanvasHash = async (): Promise<string> => {
  try {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return "";

    canvas.width = 200;
    canvas.height = 50;

    ctx.textBaseline = "top";
    ctx.font = '16px "Arial"';
    ctx.fillStyle = "#f60";
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = "#069";
    ctx.fillText("GnApex Rocks! <canvas> 1.0", 2, 15);
    ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
    ctx.fillText("GnApex Rocks! <canvas> 1.0", 4, 17);

    const dataUrl = canvas.toDataURL();
    let hash = 0;
    for (let i = 0; i < dataUrl.length; i++) {
      const char = dataUrl.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash; // Force 32-bit int
    }
    return hash.toString(16);
  } catch {
    return "";
  }
};

/**
 * Generates or retrieves a persistent Visitor ID (cookie-less).
 */
export const getVisitorId = async (
  allowFingerprinting = true,
): Promise<string> => {
  if (typeof window === "undefined") return "server_visitor";

  const STORAGE_KEY = "nexus_vid";
  let vid = localStorage.getItem(STORAGE_KEY);

  if (!vid) {
    const entropy = await getDeviceEntropy(allowFingerprinting);
    const random = Math.random().toString(36).substring(2, 15);
    const timestamp = Date.now().toString(36);

    const fingerprint = [
      entropy.screen_resolution,
      entropy.hardware_concurrency,
      entropy.timezone_offset,
      entropy.platform,
      entropy.canvas_hash || "standard_entropy",
    ].join("|");

    let hash = 0;
    for (let i = 0; i < fingerprint.length; i++) {
      hash = (hash << 5) - hash + fingerprint.charCodeAt(i);
      hash |= 0;
    }

    vid = `vis_${hash.toString(16)}_${timestamp}_${random}`;
    localStorage.setItem(STORAGE_KEY, vid);
  }

  return vid;
};
