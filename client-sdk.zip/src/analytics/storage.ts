// packages/client-sdk/src/analytics/storage.ts
/**
 * GnApex Persistent Storage (IndexedDB Wrapper)
 * Ensures events survive browser crashes and offline scenarios.
 */

const DB_NAME = "GnApex_Analytics";
const STORE_NAME = "events_queue";
const DB_VERSION = 2;

// FIX: Enforce a hard cap on the queue size so extended offline periods
// (hours or days) don't cause the IndexedDB to grow without bound.
// When the cap is reached, the oldest event is evicted to make room for
// the incoming one — preserving the most recent user activity.
const MAX_QUEUE_SIZE = 500;

export interface StoredEvent {
  id?: number; // Auto-incremented by IndexedDB
  payload: any;
  timestamp: number;
  retryCount: number;
}

export class EventStorage {
  private db: IDBDatabase | null = null;
  private isReady: Promise<void>;

  constructor() {
    this.isReady = this.init();
  }

  private init(): Promise<void> {
    if (typeof window === "undefined" || !window.indexedDB) {
      return Promise.resolve(); // SSR-safe
    }

    return new Promise((resolve) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => {
        console.warn(
          "[GnApex] Failed to open IndexedDB. Falling back to memory.",
        );
        resolve(); // Resolve so callers can fall back gracefully
      };

      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        // Clear the old store if upgrading from v1
        if (db.objectStoreNames.contains(STORE_NAME)) {
          db.deleteObjectStore(STORE_NAME);
        }
        db.createObjectStore(STORE_NAME, {
          keyPath: "id",
          autoIncrement: true,
        });
      };
    });
  }

  /**
   * Add an event to the persistent queue.
   * Evicts the oldest entry if the queue is already at MAX_QUEUE_SIZE.
   */
  public async enqueue(payload: any): Promise<void> {
    await this.isReady;
    if (!this.db) return;

    // FIX: Cap the queue. Previously the queue could grow indefinitely
    // during long offline periods, potentially filling the user's disk quota.
    const currentCount = await this.count();
    if (currentCount >= MAX_QUEUE_SIZE) {
      // Evict the oldest event to make room for the newest
      const oldest = await this.peek(1);
      if (oldest.length > 0 && oldest[0].id !== undefined) {
        await this.remove([oldest[0].id]);
      }
    }

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_NAME], "readwrite");
      const store = transaction.objectStore(STORE_NAME);
      const request = store.add({
        payload,
        timestamp: Date.now(),
        retryCount: 0,
      });

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Get a batch of the oldest events without removing them.
   */
  public async peek(limit: number = 20): Promise<StoredEvent[]> {
    await this.isReady;
    if (!this.db) return [];

    return new Promise((resolve) => {
      const transaction = this.db!.transaction([STORE_NAME], "readonly");
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll(null, limit);

      request.onsuccess = () => resolve(request.result as StoredEvent[]);
      request.onerror = () => resolve([]);
    });
  }

  /**
   * Remove events by ID after a successful upload.
   */
  public async remove(ids: number[]): Promise<void> {
    await this.isReady;
    if (!this.db || ids.length === 0) return;

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([STORE_NAME], "readwrite");
      const store = transaction.objectStore(STORE_NAME);

      // FIX: Removed dead variables `processed` and `errors` that were
      // declared but never incremented or read. More importantly, the
      // original code never set up req.onsuccess or req.onerror on each
      // delete request — silent failures were impossible to detect.
      //
      // The correct pattern: queue all deletes in the same transaction and
      // rely on transaction.oncomplete / transaction.onerror for the outcome.
      // IndexedDB guarantees that all queued operations complete atomically
      // within a single transaction, so this is both correct and efficient.
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () =>
        reject(new Error("Delete transaction aborted"));

      ids.forEach((id) => {
        store.delete(id);
      });
    });
  }

  /**
   * Count pending events in the queue.
   */
  public async count(): Promise<number> {
    await this.isReady;
    if (!this.db) return 0;

    return new Promise((resolve) => {
      const transaction = this.db!.transaction([STORE_NAME], "readonly");
      const store = transaction.objectStore(STORE_NAME);
      const request = store.count();

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(0);
    });
  }
}

export const eventStorage = new EventStorage();
