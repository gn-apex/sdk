// packages/client-sdk/src/analytics/index.ts
import { NexusConfig } from "../types";
import { Tracker, EcommercePayload } from "./tracker";
import { initVitals } from "./vitals";

const safeRemoveItem = (key: string): void => {
  try {
    localStorage.removeItem(key);
  } catch {}
};

export class AnalyticsEngine {
  private tracker: Tracker;
  private cleanupFns: Array<() => void> = [];
  private isInitialized = false;

  private maxScrollDepth = 0;
  private scrollThresholdsFired = new Set<number>();
  private scrollTimer?: ReturnType<typeof setTimeout>;

  constructor(config: NexusConfig) {
    this.tracker = new Tracker(config);
  }

  public start() {
    if (this.isInitialized || typeof window === "undefined") return;
    this.isInitialized = true;

    this.pageView();
    initVitals(this.tracker);
    this.setupClickTracking();
    this.setupFormTracking();
    this.setupRouteTracking();
    this.setupShareTracking();
    this.setupScrollTracking();
    this.setupOutboundTracking();
    this.setupVideoTracking();
    this.setupErrorTracking();

    if (process.env.NODE_ENV === "development") {
      console.log("[GnApex] 🚀 Analytics Engine Started");
    }
  }

  private lastPath: string =
    typeof window !== "undefined" ? window.location.pathname : "";

  public pageView(customReferrer?: string) {
    if (typeof window === "undefined") return;

    const currentPath = window.location.pathname;

    this.maxScrollDepth = 0;
    this.scrollThresholdsFired.clear();

    this.tracker.send("page_view", {
      path: currentPath,
      search: window.location.search,
      title: document.title,
      timezone_offset: new Date().getTimezoneOffset(),
      referrer:
        customReferrer ||
        (this.lastPath !== currentPath ? this.lastPath : document.referrer),
    });

    this.lastPath = currentPath;
  }

  private setupShareTracking() {
    if (typeof window === "undefined") return;

    const copyHandler = () => {
      this.tracker.send("social_share", {
        method: "clipboard_copy",
        url: window.location.href,
      });
    };

    window.addEventListener("copy", copyHandler, { passive: true });
    this.cleanupFns.push(() => window.removeEventListener("copy", copyHandler));

    if (typeof navigator !== "undefined" && navigator.share) {
      const originalShare = navigator.share.bind(navigator);

      navigator.share = (data?: ShareData) => {
        this.tracker.send("social_share", {
          method: "native_share_menu",
          url: data?.url || window.location.href,
          title: data?.title,
        });
        return originalShare(data);
      };

      this.cleanupFns.push(() => {
        navigator.share = originalShare;
      });
    }
  }

  private setupScrollTracking() {
    if (typeof window === "undefined") return;

    const THRESHOLDS = [25, 50, 75, 100];

    const scrollHandler = () => {
      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      const docHeight =
        document.documentElement.scrollHeight -
        document.documentElement.clientHeight;

      if (docHeight <= 0) return;

      const pct = Math.round((scrollTop / docHeight) * 100);
      if (pct > this.maxScrollDepth) {
        this.maxScrollDepth = pct;
      }

      clearTimeout(this.scrollTimer);
      this.scrollTimer = setTimeout(() => {
        for (const threshold of THRESHOLDS) {
          if (
            this.maxScrollDepth >= threshold &&
            !this.scrollThresholdsFired.has(threshold)
          ) {
            this.scrollThresholdsFired.add(threshold);
            this.tracker.send("scroll", {
              depth: threshold / 100,
              depth_percent: threshold,
              path: window.location.pathname,
            });
          }
        }
      }, 300);
    };

    window.addEventListener("scroll", scrollHandler, { passive: true });
    this.cleanupFns.push(() => {
      window.removeEventListener("scroll", scrollHandler);
      clearTimeout(this.scrollTimer);
    });
  }

  private clickBuffer: Array<{ x: number; y: number; t: number }> = [];

  private setupClickTracking() {
    if (typeof window === "undefined") return;

    const clickHandler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;

      const link = target.closest("a");
      if (link) {
        this.tracker.send("click", {
          element_type: "link",
          href: link.href,
          text: link.innerText?.substring(0, 50),
          id: link.id,
          classes: link.className,
          dataset: { ...link.dataset },
          coordinates: { x: e.clientX, y: e.clientY },
        });
      }

      const button = target.closest("button");
      if (button) {
        this.tracker.send("click", {
          element_type: "button",
          text: button.innerText?.substring(0, 50),
          id: button.id,
          classes: button.className,
          coordinates: { x: e.clientX, y: e.clientY },
        });
      }

      const now = Date.now();
      const ZONE = 400;
      const WINDOW_MS = 1000;
      const RAGE_THRESHOLD = 3;

      this.clickBuffer.push({ x: e.clientX, y: e.clientY, t: now });
      this.clickBuffer = this.clickBuffer.filter((c) => now - c.t < WINDOW_MS);

      const zone = {
        x: Math.floor(e.clientX / ZONE),
        y: Math.floor(e.clientY / ZONE),
      };
      const zoneClicks = this.clickBuffer.filter(
        (c) =>
          Math.floor(c.x / ZONE) === zone.x &&
          Math.floor(c.y / ZONE) === zone.y,
      );

      if (zoneClicks.length >= RAGE_THRESHOLD) {
        this.tracker.send(
          "click",
          {
            element_type: target.tagName.toLowerCase(),
            event_name: "rage_click",
            coordinates: { x: e.clientX, y: e.clientY },
            click_count: zoneClicks.length,
            path: window.location.pathname,
          },
          "rage_click",
        );
        this.clickBuffer = [];
      }

      const isInteractive = target.closest(
        "a, button, input, select, textarea, [onclick], [role='button']",
      );

      if (!isInteractive) {
        const pathBefore = window.location.pathname;
        setTimeout(() => {
          const pathAfter = window.location.pathname;
          if (pathBefore === pathAfter) {
            this.tracker.send(
              "click",
              {
                element_type: target.tagName.toLowerCase(),
                event_name: "dead_click",
                selector: getSelector(target),
                coordinates: { x: e.clientX, y: e.clientY },
                path: window.location.pathname,
              },
              "dead_click",
            );
          }
        }, 300);
      }
    };

    window.addEventListener("click", clickHandler, { passive: true });
    this.cleanupFns.push(() =>
      window.removeEventListener("click", clickHandler),
    );
  }

  private setupFormTracking() {
    if (typeof document === "undefined") return;

    const submitHandler = (e: Event) => {
      const form = e.target as HTMLFormElement;
      if (form) {
        this.tracker.send("form_submit", {
          form_id: form.id || form.name || "unknown_form",
          action: form.action,
          method: form.method,
          field_count: form.elements.length,
        });
      }
    };

    document.addEventListener("submit", submitHandler, { passive: true });
    this.cleanupFns.push(() =>
      document.removeEventListener("submit", submitHandler),
    );
  }

  private setupOutboundTracking() {
    if (typeof window === "undefined") return;

    const outboundHandler = (e: MouseEvent) => {
      const link = (e.target as HTMLElement).closest("a");
      if (!link || !link.href) return;

      try {
        const linkHost = new URL(link.href).hostname;
        if (linkHost && linkHost !== window.location.hostname) {
          this.tracker.send(
            "click",
            {
              event_name: "outbound_click",
              href: link.href,
              text: link.innerText?.substring(0, 50),
              destination_host: linkHost,
              coordinates: { x: e.clientX, y: e.clientY },
            },
            "outbound_click",
          );
        }
      } catch {}
    };

    window.addEventListener("click", outboundHandler, { passive: true });
    this.cleanupFns.push(() =>
      window.removeEventListener("click", outboundHandler),
    );
  }

  private setupVideoTracking() {
    if (typeof document === "undefined") return;
    const attach = (video: HTMLVideoElement) => {
      const v = video as HTMLVideoElement & { __gnexusTracked?: boolean; __gnexusMilestones?: Set<number> };
      if (v.__gnexusTracked) return;
      v.__gnexusTracked = true; v.__gnexusMilestones = new Set();
      const src = () => video.currentSrc || video.src || "unknown";
      const emit = (name:string, data:any={}) => this.tracker.send("media", { media_type:"video", event_name:name, src:src(), ...data }, name);
      video.addEventListener("loadedmetadata", () => emit("video_loaded", { duration_seconds: Number.isFinite(video.duration) ? Math.round(video.duration) : undefined }));
      video.addEventListener("play", () => emit("video_play", { position_seconds: Math.round(video.currentTime) }));
      video.addEventListener("pause", () => emit("video_pause", { position_seconds: Math.round(video.currentTime) }));
      video.addEventListener("seeking", () => emit("video_seek", { position_seconds: Math.round(video.currentTime) }));
      video.addEventListener("ended", () => emit("video_complete", { duration_seconds: Math.round(video.duration) }));
      video.addEventListener("error", () => emit("video_error"));
      video.addEventListener("timeupdate", () => {
        if (!Number.isFinite(video.duration) || video.duration <= 0) return;
        for (const milestone of [25,50,75,90,100]) {
          if (video.currentTime/video.duration*100 >= milestone && !v.__gnexusMilestones!.has(milestone)) { v.__gnexusMilestones!.add(milestone); emit(`video_${milestone}_percent`, { progress: milestone/100 }); }
        }
      });
    };
    document.querySelectorAll("video").forEach(v=>attach(v as HTMLVideoElement));
    const observer = new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{ if(n instanceof HTMLVideoElement) attach(n); if(n instanceof Element) n.querySelectorAll("video").forEach(v=>attach(v as HTMLVideoElement)); })));
    if (document.body) observer.observe(document.body,{childList:true,subtree:true});
    this.cleanupFns.push(()=>observer.disconnect());
  }

  private setupErrorTracking() {
    if (typeof window === "undefined") return;

    const errorHandler = (e: ErrorEvent) => {
      this.tracker.send("error", {
        message: e.message,
        filename: e.filename,
        lineno: e.lineno,
        colno: e.colno,
        stack: e.error?.stack,
        url: window.location.href,
        type: "uncaught_error",
      });
    };

    const rejectionHandler = (e: PromiseRejectionEvent) => {
      const reason =
        e.reason instanceof Error ? e.reason.message : String(e.reason);
      const stack = e.reason instanceof Error ? e.reason.stack : undefined;
      this.tracker.send("error", {
        message: reason,
        stack,
        url: window.location.href,
        type: "unhandled_rejection",
      });
    };

    window.addEventListener("error", errorHandler);
    window.addEventListener("unhandledrejection", rejectionHandler);
    this.cleanupFns.push(() => {
      window.removeEventListener("error", errorHandler);
      window.removeEventListener("unhandledrejection", rejectionHandler);
    });
  }

  private setupRouteTracking() {
    if (typeof window === "undefined" || typeof window.history === "undefined")
      return;

    const originalPushState = history.pushState.bind(history);
    const originalReplaceState = history.replaceState.bind(history);

    history.pushState = (...args) => {
      const prevPath = window.location.pathname;
      originalPushState(...args);
      if (!this.isInitializedByReactProvider()) {
        this.pageView(prevPath);
      }
    };

    history.replaceState = (...args) => {
      originalReplaceState(...args);
    };

    const popStateHandler = () => {
      if (!this.isInitializedByReactProvider()) {
        this.pageView();
      }
    };
    window.addEventListener("popstate", popStateHandler);

    this.cleanupFns.push(() => {
      history.pushState = originalPushState;
      history.replaceState = originalReplaceState;
      window.removeEventListener("popstate", popStateHandler);
    });
  }

  private isInitializedByReactProvider(): boolean {
    return !!document.getElementById("__nexus_react_active");
  }

  public async identify(
    userId: string,
    traits: Record<string, any> = {},
  ): Promise<boolean> {
    return this.sendIdentityRequest("identify", { user_id: userId, traits });
  }

  public async group(
    groupId: string,
    traits: Record<string, any> = {},
  ): Promise<boolean> {
    return this.sendIdentityRequest("group", { group_id: groupId, traits });
  }

  public async alias(newId: string): Promise<boolean> {
    return this.sendIdentityRequest("alias", {
      previous_id: this.tracker.getSession(),
      user_id: newId,
    });
  }

  public reset(performGdprScrub = false) {
    const config = (this.tracker as any).config as NexusConfig;

    this.tracker.stop();
    localStorage.removeItem("nexus_sid");
    localStorage.removeItem("nexus_vid");
    safeRemoveItem("nexus_anon_id");
    this.tracker.clearIdentity();

    if (performGdprScrub) {
      const endpoint = `${config.analyticsUrl}/api/privacy/scrub`;
      const userId = this.tracker.getVisitorId();

      fetch(endpoint, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({
          project_id: config.projectId,
          user_id: userId,
        }),
      }).catch((err) => console.error("[GnApex] Privacy scrub failed:", err));
    }

    window.location.reload();
  }

  public track(eventName: string, properties: Record<string, any> = {}) {
    this.tracker.send(
      "custom_event",
      { event_name: eventName, ...properties },
      eventName,
    );
  }

  public trackPurchase(orderData: {
    orderId: string;
    total: number;
    revenue?: number;
    currency?: string;
    products: Array<{
      id: string;
      name: string;
      price: number;
      quantity: number;
      sku?: string;
    }>;
  }) {
    const ecommerce: EcommercePayload = {
      orderId: orderData.orderId,
      total: orderData.total,
      revenue: orderData.revenue ?? orderData.total,
      currency: orderData.currency || "USD",
      products: orderData.products.map((p) => ({
        productId: p.id,
        sku: p.sku,
        name: p.name,
        price: p.price,
        quantity: p.quantity,
      })),
    };

    this.tracker.send(
      "purchase",
      { order_id: orderData.orderId },
      "purchase",
      ecommerce,
    );
  }

  public trackError(error: Error, context?: Record<string, any>) {
    this.tracker.send("error", {
      message: error.message,
      stack: error.stack,
      context,
      url: typeof window !== "undefined" ? window.location.href : "",
      type: "manual",
    });
  }

  private async sendIdentityRequest(
    type: "identify" | "group" | "alias",
    data: any,
  ): Promise<boolean> {
    try {
      const config = (this.tracker as any).config as NexusConfig;
      const endpoint = `${config.analyticsUrl}/api/${type}`;

      const payload = {
        projectId: config.projectId,
        sessionId: this.tracker.getSession(),
        visitorId: this.tracker.getVisitorId(),
        anonymousId: this.tracker.getAnonymousId(),
        timestamp: new Date().toISOString(),
        ...data,
      };

      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify(payload),
      });

      return response.ok;
    } catch (error) {
      console.error(`[GnApex] ${type} failed:`, error);
      return false;
    }
  }

  public getSessionId() {
    return this.tracker.getSession();
  }

  public stop(isFinalShutdown = false) {
    this.cleanupFns.forEach((fn) => fn());
    this.cleanupFns = [];

    if (isFinalShutdown) {
      this.tracker.send("session_end", {
        session_id: this.tracker.getSession(),
        duration: this.tracker.getSessionDuration(),
        max_scroll_depth: this.maxScrollDepth / 100,
      });
    }

    this.tracker.stop();
    this.isInitialized = false;
  }
}

// 🛡️ TYPE SAFE PARENT ELEMENT RESOLVER (Safe against strict compiler options)
function getSelector(el: Element | null, depth = 0): string {
  if (!el || depth > 2) return "";
  const tag = el.tagName.toLowerCase();
  const id = el.id ? `#${el.id}` : "";
  const cls =
    el.className && typeof el.className === "string"
      ? `.${el.className.trim().split(/\s+/).slice(0, 2).join(".")}`
      : "";
  const self = `${tag}${id}${cls}`;
  const parent =
    el.parentElement && depth < 2
      ? `${getSelector(el.parentElement, depth + 1)} > `
      : "";
  return `${parent}${self}`;
}
