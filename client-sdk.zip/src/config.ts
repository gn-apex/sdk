// packages/client-sdk/src/config.ts

export interface MinimalNexusConfig {
  apiUrl?: string;
  analyticsUrl?: string;
  apiKey?: string;
  projectId?: string;
}

export const DEFAULT_API_URL = "https://api.gnapex.com"; // Primary API Gateway
export const DEFAULT_ANALYTICS_URL = "https://sentry.gnapex.com"; // Rust Analytics Sentry
export const SDK_VERSION = "1.1.0";

export const LOCAL_NEST_URL = "https://api.gnapex.com";
export const LOCAL_RUST_URL = "https://sentry.gnapex.com";

/**
 * Automatically discovers runtime configuration across:
 * 1. Window Global (__GNAPEX__ or __NEXUS__)
 * 2. HTML Meta Tags (<meta name="gnapex-project"> / <meta name="nexus-project">)
 * 3. Next.js Public Environment Variables (NEXT_PUBLIC_GNAPEX_* / NEXT_PUBLIC_NEXUS_*)
 * 4. Node.js Standard Process Variables (GNAPEX_* / NEXUS_*)
 */
export const getEnvConfig = (): MinimalNexusConfig => {
  // 🛡️ Next.js Browser Safety: Explicit property checks for static build string replacement
  const NEXT_PUBLIC_ID =
    typeof process !== "undefined"
      ? (process.env.NEXT_PUBLIC_GNAPEX_ID ?? process.env.NEXT_PUBLIC_NEXUS_ID)
      : undefined;

  const NEXT_PUBLIC_KEY =
    typeof process !== "undefined"
      ? (process.env.NEXT_PUBLIC_GNAPEX_KEY ??
        process.env.NEXT_PUBLIC_NEXUS_KEY)
      : undefined;

  const NEXT_PUBLIC_URL =
    typeof process !== "undefined"
      ? (process.env.NEXT_PUBLIC_GNAPEX_API_URL ??
        process.env.NEXT_PUBLIC_NEXUS_API_URL)
      : undefined;

  const NEXT_PUBLIC_ANALYTICS_URL =
    typeof process !== "undefined"
      ? (process.env.NEXT_PUBLIC_GNAPEX_ANALYTICS_URL ??
        process.env.NEXT_PUBLIC_NEXUS_ANALYTICS_URL)
      : undefined;

  // Fallbacks for CLI / Node.js runtime environments
  const NODE_ID =
    typeof process !== "undefined"
      ? (process.env.GNAPEX_PROJECT_ID ?? process.env.NEXUS_PROJECT_ID)
      : undefined;

  const NODE_KEY =
    typeof process !== "undefined"
      ? (process.env.GNAPEX_API_KEY ?? process.env.NEXUS_API_KEY)
      : undefined;

  const NODE_URL =
    typeof process !== "undefined"
      ? (process.env.GNAPEX_API_URL ?? process.env.NEXUS_API_URL)
      : undefined;

  const NODE_ANALYTICS_URL =
    typeof process !== "undefined"
      ? (process.env.GNAPEX_ANALYTICS_URL ?? process.env.NEXUS_ANALYTICS_URL)
      : undefined;

  const NODE_ENV =
    typeof process !== "undefined" ? process.env.NODE_ENV : "production";

  const isDev =
    NODE_ENV === "development" ||
    (typeof window !== "undefined" && window.location.hostname === "localhost");

  // In-browser runtime injections (e.g. Injected by GN-Apex Edge Proxy)
  const runtime =
    typeof window !== "undefined"
      ? ((window as any).__GNAPEX__ ?? (window as any).__NEXUS__)
      : undefined;

  const meta =
    typeof document !== "undefined"
      ? (name: string) =>
          document
            .querySelector(`meta[name="${name}"]`)
            ?.getAttribute("content") ?? undefined
      : (_name: string) => undefined;

  const projectId =
    runtime?.projectId ??
    meta("gnapex-project") ??
    meta("nexus-project") ??
    NEXT_PUBLIC_ID ??
    NODE_ID;

  const apiKey =
    runtime?.apiKey ??
    meta("gnapex-key") ??
    meta("nexus-key") ??
    NEXT_PUBLIC_KEY ??
    NODE_KEY;

  const apiUrl =
    runtime?.apiUrl ??
    meta("gnapex-api") ??
    meta("nexus-api") ??
    NEXT_PUBLIC_URL ??
    NODE_URL ??
    (isDev ? LOCAL_NEST_URL : DEFAULT_API_URL);

  const analyticsUrl =
    runtime?.analyticsUrl ??
    meta("gnapex-analytics") ??
    meta("nexus-analytics") ??
    NEXT_PUBLIC_ANALYTICS_URL ??
    NODE_ANALYTICS_URL ??
    (apiUrl.includes("localhost") ? LOCAL_RUST_URL : DEFAULT_ANALYTICS_URL);

  return {
    projectId,
    apiKey,
    apiUrl,
    analyticsUrl,
  };
};

/**
 * Merges discovered configuration with manual constructor overrides
 */
export const mergeConfigs = (
  base: MinimalNexusConfig,
  override: Partial<MinimalNexusConfig>,
): MinimalNexusConfig => {
  const mergedApiUrl = override.apiUrl || base.apiUrl || DEFAULT_API_URL;
  const mergedAnalyticsUrl =
    override.analyticsUrl ||
    base.analyticsUrl ||
    (mergedApiUrl.includes("localhost")
      ? LOCAL_RUST_URL
      : DEFAULT_ANALYTICS_URL);

  return {
    ...base,
    ...override,
    apiUrl: mergedApiUrl,
    analyticsUrl: mergedAnalyticsUrl,
    projectId: override.projectId || base.projectId,
    apiKey: override.apiKey || base.apiKey,
  };
};

/**
 * Returns complete resolved configuration snapshot
 */
export const getFullConfig = (
  partialConfig?: Partial<MinimalNexusConfig>,
): MinimalNexusConfig => {
  const envConfig = getEnvConfig();
  return mergeConfigs(envConfig, partialConfig || {});
};

/**
 * Validates configuration integrity
 */
export const validateConfig = (config: MinimalNexusConfig): string[] => {
  const errors: string[] = [];
  if (!config.projectId) errors.push("Missing projectId");
  if (!config.apiUrl) errors.push("Missing apiUrl");
  else if (!/^https?:\/\//.test(config.apiUrl)) {
    errors.push("apiUrl must be a valid URL starting with http:// or https://");
  }
  return errors;
};

/**
 * Helper to check if required keys exist
 */
export const hasRequiredConfig = (config: MinimalNexusConfig): boolean =>
  validateConfig(config).length === 0;
