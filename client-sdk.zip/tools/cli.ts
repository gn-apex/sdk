// GN-Apex CLI — Production Edition v 1.1.0 d some fixes
// Silicon Valley-grade developer toolbelt for the GN-Apex platform

import { Command } from "commander";
import chalk from "chalk";
import ora from "ora";
import fs from "fs-extra";
import path from "path";
import dotenv from "dotenv";
import figletModule from "figlet";
import TableModule from "cli-table3";
import gradientString from "gradient-string";
import inquirerModule from "inquirer";
import fetch from "node-fetch";
import { execSync } from "child_process";
import semverModule from "semver";
import crypto from "crypto";
import http from "http";
import { BinaryCompiler } from "../src/content/binary-compiler";
import { LocalCache } from "../src/content/local-cache-server";
import os from "os";

const gradient = (gradientString as any).default || gradientString;
const inquirer = (inquirerModule as any).default || inquirerModule;
const figlet = (figletModule as any).default || figletModule;
const Table = (TableModule as any).default || TableModule;
const semver = (semverModule as any).default || semverModule;

// ─── Constants ────────────────────────────────────────────────────────────────

const GNAPEX_VERSION = "1.3.0";
const GNAPEX_DIR = ".nexus";
const LOCK_FILE = path.join(GNAPEX_DIR, ".nexus-lock");
const CONFIG_FILE = path.join(GNAPEX_DIR, "nexus.config.nx");
const SCHEMA_FILE = path.join(GNAPEX_DIR, "schema.nx");
const ORIGIN_FILE = path.join(GNAPEX_DIR, "origin.nx");
const LOCAL_DATA_DIR = path.join(GNAPEX_DIR, "local");
const DEFAULT_API_URL = "https://api.gnapex.com";

const BRAND = chalk.bold.hex("#00D4FF");
const DIM = chalk.hex("#666666");
const SUCCESS = chalk.hex("#00FF88");
const WARN = chalk.hex("#FFB800");
const ERR = chalk.hex("#FF4444");

// Commands that can run BEFORE initialization
const PRE_INIT_COMMANDS = new Set([
  "init",
  "help",
  "--help",
  "-h",
  "--version",
  "-V",
]);

// ─── Ultimate White-Label Scrubber ────────────────────────────────────────────
// Intercepts raw error logs from underlying dependencies and scrubs 3rd party names
function scrubOutput(text: string): string {
  if (!text) return "";
  return text
    .replace(/cloudflare/gi, "GN-Apex Edge")
    .replace(/wrangler/gi, "apex-cli")
    .replace(/opennext/gi, "apex-adapter");
}

// ─── Brand Banner ─────────────────────────────────────────────────────────────

function printBanner(subtitle = "") {
  let raw = "";
  try {
    raw = figlet.textSync("GN-APEX", {
      horizontalLayout: "default",
      verticalLayout: "default",
    });
  } catch {
    raw = `
  ____ _   _       _    ____  _______  __
 / ___| \\ | |     / \\  |  _ \\| ____\\ \\/ /
| |  _|  \\| |___ / _ \\ | |_) |  _|  \\  / 
| |_| | |\\  |___/ ___ \\|  __/| |___ /  \\ 
 \\____|_| \\_|  /_/   \\_\\_|   |_____/_/\\_\\
`;
  }

  const colored = gradient(["#00D4FF", "#7B2FFF", "#FF00AA"])(raw);
  console.log("\n" + colored);
  console.log(DIM("  ─────────────────────────────────────────────────────"));
  if (subtitle) console.log("  " + chalk.bold.white(subtitle));
  console.log(
    DIM(`  GN-Apex CLI v${GNAPEX_VERSION} · Production Deployment Console`),
  );
  console.log(DIM("  ─────────────────────────────────────────────────────\n"));
}

// ─── Lock File Management ─────────────────────────────────────────────────────

async function assertInitialized() {
  const cwd = process.cwd();
  const lockPath = path.join(cwd, LOCK_FILE);
  if (!(await fs.pathExists(lockPath))) {
    console.log("\n" + ERR("✖  Project not initialized."));
    console.log(
      DIM("   This project has not been set up with the GN-Apex SDK."),
    );
    console.log(DIM("   Run the following command to get started:\n"));
    console.log("   " + BRAND("npx apex init") + "\n");
    process.exit(1);
  }
}

async function writeLock(config: any) {
  await fs.ensureDir(path.join(process.cwd(), GNAPEX_DIR));
  await fs.writeJson(
    path.join(process.cwd(), LOCK_FILE),
    {
      nexusVersion: GNAPEX_VERSION,
      initializedAt: new Date().toISOString(),
      projectId: config.projectId,
      workspace: config.workspace,
      features: config.features,
      checksum: crypto
        .createHash("md5")
        .update(JSON.stringify(config))
        .digest("hex"),
    },
    { spaces: 2 },
  );
}

async function readLock() {
  try {
    return await fs.readJson(path.join(process.cwd(), LOCK_FILE));
  } catch {
    return null;
  }
}

async function writeSchema(schema: any, apiKey: string, projectId: string) {
  const schemaPath = path.resolve(process.cwd(), SCHEMA_FILE);
  const buffer = BinaryCompiler.compile(schema, apiKey, projectId);
  await fs.ensureDir(path.dirname(schemaPath));
  await fs.writeFile(schemaPath, buffer);
}

async function readSchema(apiKey: string) {
  try {
    const schemaPath = path.resolve(process.cwd(), SCHEMA_FILE);
    if (!(await fs.pathExists(schemaPath))) return null;
    const buffer = await fs.readFile(schemaPath);
    const decompiled = BinaryCompiler.decompile(buffer, apiKey);
    return decompiled.data;
  } catch {
    return null;
  }
}

// ─── Env Loading ──────────────────────────────────────────────────────────────

function loadEnv() {
  dotenv.config({ path: path.resolve(process.cwd(), ".env.local") });
  dotenv.config({ path: path.resolve(process.cwd(), ".env") });
}

function getCredentials(opts: any = {}) {
  loadEnv();
  const apiKey =
    opts.apiKey ||
    process.env.GNAPEX_API_KEY ||
    process.env.NEXUS_API_KEY ||
    process.env.NEXT_PUBLIC_GNAPEX_KEY ||
    process.env.NEXT_PUBLIC_NEXUS_KEY;
  const projectId =
    opts.projectId ||
    process.env.GNAPEX_PROJECT_ID ||
    process.env.NEXUS_PROJECT_ID ||
    process.env.NEXT_PUBLIC_GNAPEX_ID ||
    process.env.NEXT_PUBLIC_NEXUS_ID;
  const apiUrl =
    opts.apiUrl ||
    process.env.GNAPEX_API_URL ||
    process.env.NEXUS_API_URL ||
    process.env.NEXT_PUBLIC_GNAPEX_API_URL ||
    process.env.NEXT_PUBLIC_NEXUS_API_URL ||
    DEFAULT_API_URL;
  return { apiKey, projectId, apiUrl };
}

function requireCredentials(opts: any = {}) {
  const creds = getCredentials(opts);
  if (!creds.apiKey || !creds.projectId) {
    console.error("\n" + ERR("✖  Missing credentials"));
    console.log(
      DIM(
        "   GNAPEX_API_KEY and GNAPEX_PROJECT_ID must be set in .env or .env.local\n",
      ),
    );
    process.exit(1);
  }
  return creds;
}

async function writeConfig(config: any, apiKey: string) {
  const configPath = path.join(process.cwd(), CONFIG_FILE);
  const buffer = BinaryCompiler.compile(config, apiKey, config.projectId);
  await fs.ensureDir(path.dirname(configPath));
  await fs.writeFile(configPath, buffer);
}

async function readConfig() {
  try {
    const { apiKey } = getCredentials();
    const configPath = path.join(process.cwd(), CONFIG_FILE);
    if (!(await fs.pathExists(configPath))) return null;
    if (!apiKey) return null;

    const buffer = await fs.readFile(configPath);
    const decompiled = BinaryCompiler.decompile(buffer, apiKey);
    return decompiled.data;
  } catch {
    return null;
  }
}

// ─── HTTP Helpers ─────────────────────────────────────────────────────────────

async function nexusFetch(
  url: string,
  apiKey: string,
  { method = "GET", body, timeout = 30000, retries = 3 }: any = {},
): Promise<any> {
  for (let i = 0; i < retries; i++) {
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), timeout);
    try {
      const res = await fetch(url, {
        method,
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          "X-GN-Apex-CLI": `apex-cli/${GNAPEX_VERSION}`,
          "User-Agent": `GN-Apex-CLI/${GNAPEX_VERSION} Node/${process.version}`,
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: ctrl.signal as any,
      });
      clearTimeout(tid);
      if (!res.ok) {
        const text = await res.text().catch(() => res.statusText);
        throw Object.assign(new Error(`HTTP ${res.status}: ${text}`), {
          status: res.status,
        });
      }
      return await res.json();
    } catch (err: any) {
      clearTimeout(tid);
      const retryable = [
        "EPIPE",
        "ECONNRESET",
        "ENOTFOUND",
        "AbortError",
      ].includes(err.code || err.name);
      if (retryable && i < retries - 1) {
        await sleep(Math.pow(2, i) * 600);
        continue;
      }
      throw err;
    }
  }
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

// ─── Project Detection ────────────────────────────────────────────────────────

function detectFramework() {
  const cwd = process.cwd();
  const pkg = tryReadJson(path.join(cwd, "package.json")) || {};
  const deps = { ...pkg.dependencies, ...pkg.devDependencies };
  if (deps["next"]) {
    const semverCoerce = semver.coerce(deps["next"]);
    const isAppRouter = semver.gte(
      semver.coerce(deps["next"])?.version || "14.0.0",
      "13.0.0",
    );
    return {
      name: "Next.js",
      id: "nextjs",
      router: isAppRouter ? "app" : "pages",
    };
  }
  if (deps["remix"]) return { name: "Remix", id: "remix" };
  if (deps["nuxt"]) return { name: "Nuxt", id: "nuxt" };
  if (deps["gatsby"]) return { name: "Gatsby", id: "gatsby" };
  if (deps["@sveltejs/kit"]) return { name: "SvelteKit", id: "sveltekit" };
  if (deps["astro"]) return { name: "Astro", id: "astro" };
  if (deps["react"]) return { name: "React (CRA/Vite)", id: "react" };
  if (deps["vue"]) return { name: "Vue 3", id: "vue" };
  return { name: "Unknown / Vanilla", id: "vanilla" };
}

function detectPackageManager() {
  const cwd = process.cwd();
  if (fs.existsSync(path.join(cwd, "pnpm-lock.yaml"))) return "pnpm";
  if (fs.existsSync(path.join(cwd, "yarn.lock"))) return "yarn";
  if (fs.existsSync(path.join(cwd, "bun.lockb"))) return "bun";
  return "npm";
}

function detectGit() {
  try {
    execSync("git rev-parse --is-inside-work-tree", { stdio: "pipe" });
    const remote = execSync("git remote get-url origin", { stdio: "pipe" })
      .toString()
      .trim();
    const branch = execSync("git branch --show-current", { stdio: "pipe" })
      .toString()
      .trim();
    return { hasGit: true, remote, branch };
  } catch {
    return { hasGit: false, remote: "", branch: "" };
  }
}

function detectEnvFiles() {
  const cwd = process.cwd();
  const files = [".env", ".env.local", ".env.development", ".env.production"];
  return files.filter((f) => fs.existsSync(path.join(cwd, f)));
}

function tryReadJson(p: string) {
  try {
    return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch {
    return null;
  }
}

// ─── Schema Introspection ──────────────────────────────────────────────────────

function buildEmptyFromSchema(fieldDefs: any[]): Record<string, any> {
  const obj: Record<string, any> = {};
  for (const field of fieldDefs || []) {
    obj[field.name] = getEmptyValue(field);
  }
  return obj;
}

function getEmptyValue(field: any): any {
  if (field.defaultValue !== undefined && field.defaultValue !== null) {
    return field.defaultValue;
  }
  switch (field.type) {
    case "TEXT_SHORT":
    case "TEXT_LONG":
    case "RICH_TEXT":
    case "SLUG":
    case "URL":
    case "EMAIL":
    case "PHONE":
    case "PASSWORD":
    case "COLOR":
    case "TIME":
    case "LOTTIE":
    case "ICON":
    case "GRADIENT":
      return "";
    case "NUMBER":
    case "CURRENCY":
    case "PERCENT":
    case "RATING":
    case "SCORE":
      return 0;
    case "BOOLEAN":
      return false;
    case "DATE":
    case "DATE_TIME":
      return null;
    case "IMAGE":
    case "VIDEO":
    case "AUDIO":
    case "FILE":
    case "DOCUMENT":
      return null;
    case "GALLERY":
      return [];
    case "OBJECT":
      return buildEmptyFromSchema(field.fields);
    case "ARRAY":
    case "LIST":
    case "MULTI_SELECT":
    case "TAG_SELECT":
    case "REFERENCE_LIST":
    case "MEDIA_LIST":
      return [];
    case "SELECT":
      return field.options?.[0] ?? "";
    case "REFERENCE":
      return "";
    case "LOCATION":
    case "COORDINATES":
      return { lat: 0, lng: 0, address: "" };
    case "ADDRESS":
      return { street: "", city: "", state: "", postalCode: "", country: "" };
    case "SECTION":
      return field.fields ? [buildEmptyFromSchema(field.fields)] : [];
    default:
      return null;
  }
}

function mapFieldTypeToTs(type: string): string {
  switch (type) {
    case "TEXT_SHORT":
    case "TEXT_LONG":
    case "RICH_TEXT":
    case "SLUG":
    case "URL":
    case "EMAIL":
    case "PHONE":
    case "IMAGE":
    case "VIDEO":
    case "AUDIO":
    case "FILE":
    case "DOCUMENT":
    case "CODE":
      return "string";
    case "NUMBER":
    case "CURRENCY":
    case "PERCENT":
    case "RATING":
    case "SCORE":
      return "number";
    case "BOOLEAN":
      return "boolean";
    case "DATE":
    case "DATE_TIME":
      return "string | null";
    case "GALLERY":
    case "LIST":
    case "MULTI_SELECT":
    case "TAG_SELECT":
    case "REFERENCE_LIST":
      return "string[]";
    case "OBJECT":
    case "SECTION":
      return "Record<string, unknown>";
    case "ARRAY":
      return "unknown[]";
    case "SELECT":
      return "string | null";
    case "JSON":
      return "Record<string, unknown>";
    case "REFERENCE":
      return "string | null";
    case "COLOR":
      return "string";
    case "LOCATION":
    case "COORDINATES":
      return "{ lat: number; lng: number }";
    case "ADDRESS":
      return "{ street?: string; city?: string; country?: string; [key: string]: unknown }";
    default:
      return "any";
  }
}

function toPascalCase(str: string): string {
  return str
    .replace(/[-_\s]+(.)/g, (_, c) => c.toUpperCase())
    .replace(/^(.)/, (c) => c.toUpperCase())
    .replace(/s$/, "");
}

// ─── Env File Writer ──────────────────────────────────────────────────────────

async function ensureEnvEntry(envPath: string, key: string, value: string) {
  let content = "";
  if (await fs.pathExists(envPath)) {
    content = await fs.readFile(envPath, "utf8");
  }
  const lines = content.split("\n");
  const exists = lines.some((l) => l.startsWith(key + "="));
  if (!exists) {
    const newLine = `${key}=${value}`;
    content = content.trimEnd() + "\n" + newLine + "\n";
    await fs.writeFile(envPath, content);
    return true; // written
  }
  return false; // already present
}

// ─── Local Data Store ─────────────────────────────────────────────────────────

async function getLocalData(apiKey?: string) {
  const localDir = path.join(process.cwd(), LOCAL_DATA_DIR);
  const result: {
    pages: Record<string, any>;
    collections: Record<string, any>;
    globals: any;
  } = { pages: {}, collections: {}, globals: {} };

  if (!(await fs.pathExists(localDir))) return result;

  const pagesDir = path.join(localDir, "pages");
  if (await fs.pathExists(pagesDir)) {
    for (const f of await fs.readdir(pagesDir)) {
      if (f.endsWith(".nx")) {
        const slug = path.basename(f, ".nx");
        const filePath = path.join(pagesDir, f);
        try {
          if (apiKey) {
            const buffer = await fs.readFile(filePath);
            const decompiled = BinaryCompiler.decompile(buffer, apiKey);
            result.pages[slug] = decompiled.data;
          } else {
            result.pages[slug] = {};
          }
        } catch {
          result.pages[slug] = {};
        }
      }
    }
  }

  const colDir = path.join(localDir, "collections");
  if (await fs.pathExists(colDir)) {
    for (const f of await fs.readdir(colDir)) {
      if (f.endsWith(".nx")) {
        const id = path.basename(f, ".nx");
        const filePath = path.join(colDir, f);
        try {
          if (apiKey) {
            const buffer = await fs.readFile(filePath);
            const decompiled = BinaryCompiler.decompile(buffer, apiKey);
            result.collections[id] = decompiled.data;
          } else {
            result.collections[id] = [];
          }
        } catch {
          result.collections[id] = [];
        }
      }
    }
  }

  const globFile = path.join(localDir, "globals.nx");
  if (await fs.pathExists(globFile)) {
    try {
      if (apiKey) {
        const buffer = await fs.readFile(globFile);
        const decompiled = BinaryCompiler.decompile(buffer, apiKey);
        result.globals = decompiled.data;
      } else {
        result.globals = {};
      }
    } catch {
      result.globals = {};
    }
  }
  return result;
}

async function writeLocalData(
  type: string,
  id: string | null,
  data: any,
  apiKey: string,
  projectId: string,
) {
  const localDir = path.join(process.cwd(), LOCAL_DATA_DIR);

  const compiledBuffer = BinaryCompiler.compile(data, apiKey, projectId);

  if (type === "page" && id) {
    await fs.ensureDir(path.join(localDir, "pages"));
    await fs.writeFile(
      path.join(localDir, "pages", `${id}.nx`),
      compiledBuffer,
    );
  } else if (type === "collection" && id) {
    await fs.ensureDir(path.join(localDir, "collections"));
    await fs.writeFile(
      path.join(localDir, "collections", `${id}.nx`),
      compiledBuffer,
    );
  } else if (type === "globals") {
    await fs.ensureDir(localDir);
    await fs.writeFile(path.join(localDir, "globals.nx"), compiledBuffer);
  }
}

// ─── Schema Validator ─────────────────────────────────────────────────────────

function validateLocalAgainstSchema(localData: any, schema: any) {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!schema) return { errors, warnings };

  const allNodes = [...(schema.pages || []), ...(schema.collections || [])];

  for (const node of allNodes) {
    const isCollection = node.type === "COLLECTION";
    const key = node.apiKey;
    const source = isCollection
      ? localData.collections?.[key]
      : localData.pages?.[key];

    if (!source) continue;

    const items = isCollection
      ? Array.isArray(source)
        ? source
        : [source]
      : [source];

    for (const [idx, item] of items.entries()) {
      const label = isCollection ? `${key}[${idx}]` : key;
      const dataBlock = item.data !== undefined ? item.data : item;

      for (const field of node.fields || []) {
        const val = dataBlock[field.name];
        if (field.validation?.required) {
          if (val === undefined || val === null || val === "") {
            errors.push(`${label}.${field.name}: required field is missing`);
            continue;
          }
        }
        if (val !== undefined && val !== null) {
          validateFieldRecursive(
            field,
            val,
            `${label}.${field.name}`,
            errors,
            warnings,
          );
        }
      }
    }
  }

  return { errors, warnings };
}

function validateFieldRecursive(
  field: any,
  val: any,
  pathLabel: string,
  errors: string[],
  warnings: string[],
) {
  const basicError = checkFieldType(field, val);
  if (basicError) {
    warnings.push(`${pathLabel}: ${basicError}`);
    return;
  }

  if (field.type === "OBJECT") {
    if (typeof val === "object" && val !== null) {
      for (const subField of field.fields || []) {
        const subVal = val[subField.name];
        if (
          subField.validation?.required &&
          (subVal === undefined || subVal === null || subVal === "")
        ) {
          errors.push(
            `${pathLabel}.${subField.name}: required sub-field is missing`,
          );
        } else if (subVal !== undefined && subVal !== null) {
          validateFieldRecursive(
            subField,
            subVal,
            `${pathLabel}.${subField.name}`,
            errors,
            warnings,
          );
        }
      }
    }
  }

  if (["LIST", "ARRAY", "SECTION"].includes(field.type)) {
    if (Array.isArray(val)) {
      const itemTemplate = field.fields?.[0];
      if (itemTemplate) {
        val.forEach((item, idx) => {
          validateFieldRecursive(
            itemTemplate,
            item,
            `${pathLabel}[${idx}]`,
            errors,
            warnings,
          );
        });
      }
    }
  }
}

function checkFieldType(field: any, val: any): string | null {
  switch (field.type) {
    case "TEXT_SHORT":
    case "TEXT_LONG":
    case "RICH_TEXT":
    case "SLUG":
    case "PASSWORD":
    case "COLOR":
    case "TIME":
    case "LOTTIE":
    case "ICON":
    case "GRADIENT":
      if (typeof val !== "string") return `expected string, got ${typeof val}`;
      if (
        field.validation?.minLength &&
        val.length < field.validation.minLength
      )
        return `too short (min ${field.validation.minLength})`;
      if (
        field.validation?.maxLength &&
        val.length > field.validation.maxLength
      )
        return `too long (max ${field.validation.maxLength})`;
      break;

    case "EMAIL":
      if (typeof val !== "string") return `expected string, got ${typeof val}`;
      if (
        field.validation?.minLength &&
        val.length < field.validation.minLength
      )
        return `too short (min ${field.validation.minLength})`;
      if (
        field.validation?.maxLength &&
        val.length > field.validation.maxLength
      )
        return `too long (max ${field.validation.maxLength})`;
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val))
        return `invalid email format`;
      break;

    case "URL":
      if (typeof val !== "string") return `expected string, got ${typeof val}`;
      if (
        field.validation?.minLength &&
        val.length < field.validation.minLength
      )
        return `too short (min ${field.validation.minLength})`;
      if (
        field.validation?.maxLength &&
        val.length > field.validation.maxLength
      )
        return `too long (max ${field.validation.maxLength})`;
      try {
        new URL(val);
      } catch {
        return `invalid URL`;
      }
      break;
  }
  return null;
}

// ─── Type Generation ──────────────────────────────────────────────────────────

function compileFieldToTs(field: any, indent: string = "  "): string {
  switch (field.type) {
    case "TEXT_SHORT":
    case "TEXT_LONG":
    case "RICH_TEXT":
    case "EMAIL":
    case "URL":
    case "PHONE":
    case "SLUG":
    case "COLOR":
    case "SELECT":
    case "PASSWORD":
      return "string";
    case "NUMBER":
    case "PERCENT":
    case "RATING":
    case "SCORE":
    case "CURRENCY":
      return "number";
    case "BOOLEAN":
      return "boolean";
    case "DATE":
    case "DATE_TIME":
    case "TIME":
      return "string | null";
    case "IMAGE":
    case "VIDEO":
    case "AUDIO":
    case "FILE":
    case "DOCUMENT":
      return "{ url: string; alt?: string; mimeType?: string; size?: number }";
    case "GALLERY":
      return "Array<{ url: string; alt?: string }>";
    case "JSON":
    case "CODE":
      return "Record<string, unknown>";
    case "OBJECT":
    case "SECTION":
      if (field.fields && field.fields.length > 0) {
        const innerFields = field.fields
          .filter((f: any) => !f.isHidden)
          .map(
            (f: any) =>
              `${indent}  ${f.name}${f.validation?.required ? "" : "?"}: ${compileFieldToTs(f, indent + "  ")};`,
          )
          .join("\n");
        return `{\n${innerFields}\n${indent}}`;
      }
      return "Record<string, unknown>";
    case "ARRAY":
    case "LIST":
      if (field.fields && field.fields.length > 0) {
        const itemField = field.fields[0];
        if (itemField.type === "OBJECT" && itemField.fields) {
          const innerFields = itemField.fields
            .filter((f: any) => !f.isHidden)
            .map(
              (f: any) =>
                `${indent}  ${f.name}${f.validation?.required ? "" : "?"}: ${compileFieldToTs(f, indent + "  ")};`,
            )
            .join("\n");
          return `Array<{\n${innerFields}\n${indent}}>`;
        }
        return `Array<${compileFieldToTs(itemField, indent)}>`;
      }
      return "unknown[]";
    case "REFERENCE":
      return "string | { id: string; _type?: string }";
    case "REFERENCE_LIST":
      return "string[] | Array<{ id: string }>";
    case "KEY_VALUE":
      return "Record<string, string>";
    case "LOCATION":
    case "COORDINATES":
      return "{ lat: number; lng: number; address?: string }";
    case "ADDRESS":
      return "{ street?: string; city?: string; state?: string; postalCode?: string; country?: string; [key: string]: unknown }";
    default:
      return "unknown";
  }
}

function generateTypesFromSchema(schema: any) {
  let out = `/**\n * GN-Apex Auto-Generated TypeScript Definitions\n * Generated: ${new Date().toISOString()}\n * Schema Version: ${schema.schemaVersion || "1.0"}\n * DO NOT EDIT — regenerate with: npx apex types\n */\n\n`;

  out += `// ─── Base ──────────────────────────────────────────────────────────\n\n`;
  out += `export interface NexusBase {\n  id: string;\n  createdAt: string;\n  updatedAt: string;\n}\n\n`;

  out += `// ─── Config ────────────────────────────────────────────────────────\n\n`;
  out += `export interface NexusProjectConfig {\n  siteName?: string;\n  tagline?: string;\n  branding?: Record<string, unknown>;\n  seo?: Record<string, unknown>;\n  metadata?: Record<string, unknown>;\n}\n\n`;

  const genInterface = (node: any) => {
    const name = toPascalCase(node.apiKey || node.name);
    let block = `export interface ${name} extends NexusBase {\n`;
    for (const f of node.fields || []) {
      const tsType = compileFieldToTs(f);
      const optional = f.validation?.required ? "" : "?";
      const desc = f.description ? `  /** ${f.description} */\n` : "";
      block += `${desc}  ${f.name}${optional}: ${tsType};\n`;
    }
    block += `}\n`;
    return { name, block };
  };

  const pageInterfaces: Array<{ name: string; apiKey: string }> = [];
  const colInterfaces: Array<{ name: string; apiKey: string }> = [];

  out += `// ─── Pages ─────────────────────────────────────────────────────────\n\n`;
  for (const node of schema.pages || []) {
    const { name, block } = genInterface(node);
    out += block + "\n";
    pageInterfaces.push({ name, apiKey: node.apiKey });
  }

  out += `// ─── Collections ───────────────────────────────────────────────────\n\n`;
  for (const node of schema.collections || []) {
    const { name, block } = genInterface(node);
    out += block + "\n";
    colInterfaces.push({ name, apiKey: node.apiKey });
  }

  out += `// ─── Registry ──────────────────────────────────────────────────────\n\n`;
  out += `export interface NexusPages {\n`;
  for (const p of pageInterfaces) out += `  '${p.apiKey}': ${p.name};\n`;
  out += `}\n\n`;

  out += `export interface NexusCollections {\n`;
  for (const c of colInterfaces) out += `  '${c.apiKey}': ${c.name};\n`;
  out += `}\n\n`;

  out += `export type NexusPage<K extends keyof NexusPages> = NexusPages[K];\n`;
  out += `export type NexusCollection<K extends keyof NexusCollections> = NexusCollections[K];\n\n`;

  out += `// ─── SDK Augmentation ──────────────────────────────────────────────\n\n`;
  out += `declare module '@gnapex/sdk' {\n`;
  out += `  interface ContentEngine {\n`;
  for (const p of pageInterfaces) {
    out += `    getPage(slug: '${p.apiKey}', options?: Record<string, unknown>): Promise<${p.name}>;\n`;
  }
  for (const c of colInterfaces) {
    out += `    getCollection(id: '${c.apiKey}', query?: Record<string, unknown>): Promise<{ items: ${c.name}[]; total: number; }>;\n`;
  }
  out += `  }\n}\n`;

  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// COMMANDS
// ─────────────────────────────────────────────────────────────────────────────

// ─── GIT-LIKE DIFFING & CONFLICT LAYER ────────────────────────────────────────

interface DiffResult {
  added: Array<{ path: string; value: any }>;
  removed: Array<{ path: string; value: any }>;
  modified: Array<{ path: string; oldVal: any; newVal: any }>;
}

function computeDiff(origin: any, local: any, currentPath = ""): DiffResult {
  const diff: DiffResult = { added: [], removed: [], modified: [] };

  if (origin === undefined && local !== undefined) {
    diff.added.push({ path: currentPath, value: local });
    return diff;
  }
  if (origin !== undefined && local === undefined) {
    diff.removed.push({ path: currentPath, value: origin });
    return diff;
  }

  if (
    typeof origin !== "object" ||
    origin === null ||
    typeof local !== "object" ||
    local === null
  ) {
    if (origin !== local) {
      diff.modified.push({ path: currentPath, oldVal: origin, newVal: local });
    }
    return diff;
  }

  if (Array.isArray(origin) && Array.isArray(local)) {
    const maxLen = Math.max(origin.length, local.length);
    for (let i = 0; i < maxLen; i++) {
      const originItem = origin[i];
      const localItem = local[i];
      const arrayPath = `${currentPath}[${i}]`;

      const subDiff = computeDiff(originItem, localItem, arrayPath);
      diff.added.push(...subDiff.added);
      diff.removed.push(...subDiff.removed);
      diff.modified.push(...subDiff.modified);
    }
    return diff;
  }

  const allKeys = new Set([...Object.keys(origin), ...Object.keys(local)]);
  for (const key of allKeys) {
    const nextPath = currentPath ? `${currentPath}.${key}` : key;
    const subDiff = computeDiff(origin[key], local[key], nextPath);
    diff.added.push(...subDiff.added);
    diff.removed.push(...subDiff.removed);
    diff.modified.push(...subDiff.modified);
  }

  return diff;
}

function formatDiffValue(val: any): string {
  if (typeof val === "object" && val !== null) {
    return JSON.stringify(val);
  }
  return String(val);
}

async function cmdDiff() {
  await assertInitialized();
  printBanner("Content Diff");

  const { apiKey } = requireCredentials();

  const originPath = path.resolve(process.cwd(), ORIGIN_FILE);
  if (!(await fs.pathExists(originPath))) {
    console.log(
      ERR("  No upstream tracking file found. Run npx apex pull first.\n"),
    );
    process.exit(1);
  }

  const spinner = ora(
    "Computing local changes against origin/upstream...",
  ).start();

  try {
    const buffer = await fs.readFile(originPath);
    const { data: origin } = BinaryCompiler.decompile(buffer, apiKey);

    const localCache = new LocalCache();
    const local = await localCache.getAllData();
    spinner.stop();

    const diff = computeDiff(origin.data, local);

    if (
      diff.added.length === 0 &&
      diff.removed.length === 0 &&
      diff.modified.length === 0
    ) {
      console.log(
        SUCCESS(
          "  ✔  Your local branch is completely up-to-date with upstream. No pending changes.\n",
        ),
      );
      return;
    }

    console.log(chalk.bold("  Pending Changeset:\n"));

    for (const item of diff.added) {
      console.log(
        chalk.green(`     + [Added]    ${item.path}: `) +
          chalk.dim(formatDiffValue(item.value)),
      );
    }

    for (const item of diff.removed) {
      console.log(
        ERR(`     - [Removed]  ${item.path}: `) +
          chalk.dim(formatDiffValue(item.value)),
      );
    }

    for (const item of diff.modified) {
      console.log(
        WARN(`     ~ [Modified] ${item.path}: `) +
          ERR(`-${formatDiffValue(item.oldVal)} `) +
          chalk.green(`+${formatDiffValue(item.newVal)}`),
      );
    }

    const changeCount =
      diff.added.length + diff.removed.length + diff.modified.length;
    console.log(
      DIM(
        `\n  Total changes: ${changeCount} (use 'npx apex push' to publish changesets)\n`,
      ),
    );
  } catch (err: any) {
    spinner.isSpinning && spinner.stop();
    console.error(ERR(`  Diff calculation interrupted: ${err.message}`));
    process.exit(1);
  }
}

// ─── EPHEMERAL STUDIO SERVER ──────────────────────────────────────────────────

function parseJsonBody(req: http.IncomingMessage): Promise<any> {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk.toString();
    });
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        reject(new Error("Invalid JSON body payload"));
      }
    });
  });
}

function openBrowser(url: string) {
  const start =
    process.platform === "darwin"
      ? "open"
      : process.platform === "win32"
        ? "start"
        : "xdg-open";
  try {
    execSync(`${start} ${url}`, { stdio: "ignore" });
  } catch {
    // Fail silently
  }
}

async function cmdStudio(opts: any) {
  await assertInitialized();
  printBanner("Sovereign Local Studio");

  const port = parseInt(opts.port || "4646", 10);
  const { apiKey, projectId, apiUrl } = requireCredentials(opts);
  const localCache = new LocalCache(undefined, apiKey);

  const mimeTypes: Record<string, string> = {
    ".html": "text/html",
    ".js": "application/javascript",
    ".css": "text/css",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
  };

  const server = http.createServer(async (req, res) => {
    const method = req.method || "GET";
    const url = req.url || "/";
    const cleanUrl = url.split("?")[0].split("#")[0];

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET, POST, PATCH, PUT, OPTIONS",
    );
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Content-Type, Authorization",
    );

    if (method === "OPTIONS") {
      res.writeHead(200);
      res.end();
      return;
    }

    try {
      if (cleanUrl === "/api/context" && method === "GET") {
        let projectName = "Local Sandbox";
        try {
          const schema = await readSchema(apiKey);
          projectName = schema?.config?.siteName || "Local Sandbox";
        } catch {}

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ projectId, projectName }));
        return;
      }

      if (
        url.startsWith("/api/content/schema/") &&
        !url.endsWith("/draft") &&
        method === "GET"
      ) {
        const schema = await readSchema(apiKey);
        if (!schema) {
          res.writeHead(404, { "Content-Type": "application/json" });
          res.end(
            JSON.stringify({
              error: "schema.nx binary not found. Please run npx apex pull.",
            }),
          );
          return;
        }

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(
          JSON.stringify({
            live: schema,
            draft: schema,
            meta: {
              lastSaved: new Date().toISOString(),
              lastPublished: new Date().toISOString(),
            },
          }),
        );
        return;
      }

      if (
        cleanUrl.startsWith("/api/content/schema/") &&
        cleanUrl.endsWith("/draft") &&
        method === "PATCH"
      ) {
        const body = await parseJsonBody(req);
        await writeSchema(body.schema, apiKey, projectId);

        const localDir = path.join(process.cwd(), LOCAL_DATA_DIR);

        for (const page of body.schema.pages || []) {
          const pagePath = path.join(localDir, "pages", `${page.apiKey}.nx`);
          if (!(await fs.pathExists(pagePath))) {
            const emptyData = buildEmptyFromSchema(page.fields);
            await writeLocalData(
              "page",
              page.apiKey,
              emptyData,
              apiKey,
              projectId,
            );
          }
        }

        for (const col of body.schema.collections || []) {
          const colPath = path.join(
            localDir,
            "collections",
            `${col.apiKey}.nx`,
          );
          if (!(await fs.pathExists(colPath))) {
            const emptyData = [buildEmptyFromSchema(col.fields)];
            await writeLocalData(
              "collection",
              col.apiKey,
              emptyData,
              apiKey,
              projectId,
            );
          }
        }

        const activePageKeys = new Set(
          (body.schema.pages || []).map((p: any) => p.apiKey),
        );
        const pagesDir = path.join(localDir, "pages");
        if (await fs.pathExists(pagesDir)) {
          const files = await fs.readdir(pagesDir);
          for (const file of files) {
            if (file.endsWith(".nx")) {
              const slug = path.basename(file, ".nx");
              if (!activePageKeys.has(slug)) {
                await fs.remove(path.join(pagesDir, file));
                console.log(
                  `🧹 Local Sync: Purged deleted Page binary (${file})`,
                );
              }
            }
          }
        }

        const activeColKeys = new Set(
          (body.schema.collections || []).map((c: any) => c.apiKey),
        );
        const colsDir = path.join(localDir, "collections");
        if (await fs.pathExists(colsDir)) {
          const files = await fs.readdir(colsDir);
          for (const file of files) {
            if (file.endsWith(".nx")) {
              const id = path.basename(file, ".nx");
              if (!activeColKeys.has(id)) {
                await fs.remove(path.join(colsDir, file));
                console.log(
                  `🧹 Local Sync: Purged deleted Collection binary (${file})`,
                );
              }
            }
          }
        }

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(
          JSON.stringify({
            success: true,
            message:
              "Local schema synchronized. Missing files created, deleted files pruned.",
          }),
        );
        return;
      }

      if (
        cleanUrl.startsWith("/api/content/") &&
        cleanUrl.endsWith("/data") &&
        method === "GET"
      ) {
        const fullData = await localCache.getAllData();
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(
          JSON.stringify({
            data: {
              ...fullData.pages,
              ...fullData.collections,
              globals: fullData.globals,
            },
          }),
        );
        return;
      }

      if (
        cleanUrl.startsWith("/api/content/") &&
        cleanUrl.endsWith("/data") &&
        method === "PUT"
      ) {
        const body = await parseJsonBody(req);
        const incomingData = body.data || {};
        const schema = await readSchema(apiKey);
        if (!schema) throw new Error("Missing schema.nx file");

        let compiledPagesCount = 0;
        let compiledCollectionsCount = 0;

        for (const page of schema.pages || []) {
          const key = page.apiKey;
          if (incomingData[key]) {
            let cleanData = incomingData[key];
            while (
              cleanData &&
              typeof cleanData === "object" &&
              cleanData.data !== undefined
            ) {
              cleanData = cleanData.data;
            }

            const compiledBuffer = BinaryCompiler.compile(
              cleanData,
              apiKey,
              projectId,
            );
            await fs.ensureDir(
              path.resolve(process.cwd(), LOCAL_DATA_DIR, "pages"),
            );
            await fs.writeFile(
              path.resolve(process.cwd(), LOCAL_DATA_DIR, "pages", `${key}.nx`),
              compiledBuffer,
            );
            compiledPagesCount++;
          }
        }

        for (const col of schema.collections || []) {
          const key = col.apiKey;
          if (incomingData[key]) {
            const compiledBuffer = BinaryCompiler.compile(
              incomingData[key],
              apiKey,
              projectId,
            );
            await fs.ensureDir(
              path.resolve(process.cwd(), LOCAL_DATA_DIR, "collections"),
            );
            await fs.writeFile(
              path.resolve(
                process.cwd(),
                LOCAL_DATA_DIR,
                "collections",
                `${key}.nx`,
              ),
              compiledBuffer,
            );
            compiledCollectionsCount++;
          }
        }

        if (compiledPagesCount > 0 || compiledCollectionsCount > 0) {
          console.log(
            SUCCESS(
              `  ✔  Staged and compiled local binary changes (${compiledPagesCount} pages, ${compiledCollectionsCount} collections).`,
            ),
          );
        }

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(
          JSON.stringify({
            success: true,
            message: "Saved and compiled all local data.",
          }),
        );
        return;
      }

      if (cleanUrl.startsWith("/api/projects/") && method === "GET") {
        const targetProjectId = cleanUrl.split("/").pop();
        if (!targetProjectId) throw new Error("Missing project ID");

        try {
          const remoteProject = await nexusFetch(
            `${apiUrl}/projects/${targetProjectId}`,
            apiKey,
            { timeout: 10000 },
          );
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(remoteProject));
        } catch {
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(
            JSON.stringify({
              subdomain: "localhost:3000",
              liveUrl: "http://localhost:3000",
            }),
          );
        }
        return;
      }

      if (!cleanUrl.startsWith("/api/")) {
        const studioBasePath = path.join(__dirname, "studio");
        let filePath = path.join(
          studioBasePath,
          cleanUrl === "/" || cleanUrl === "/studio" ? "index.html" : cleanUrl,
        );

        if (!fs.existsSync(filePath) && !cleanUrl.startsWith("/assets/")) {
          filePath = path.join(studioBasePath, "index.html");
        }

        if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
          const ext = path.extname(filePath);
          const contentType = mimeTypes[ext] || "application/octet-stream";
          res.writeHead(200, { "Content-Type": contentType });
          const stream = fs.createReadStream(filePath);
          stream.pipe(res);
          return;
        }
      }

      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: `Route ${method} ${url} not found` }));
    } catch (error: any) {
      console.error(`[GN-Apex CLI] Handshake Error:`, error.message);
      res.writeHead(error.status || 500, {
        "Content-Type": "application/json",
      });
      res.end(JSON.stringify({ error: error.message }));
    }
  });

  const spinner = ora(
    `Launching local studio API on http://localhost:${port}...`,
  ).start();

  try {
    server.listen(port, () => {
      spinner.succeed(
        SUCCESS(`GN-Apex Local Studio: http://localhost:${port}`),
      );
      console.log(DIM(`   - Project ID: ${projectId}`));
      console.log(
        DIM("   - Press Ctrl+C to gracefully terminate the session.\n"),
      );
      openBrowser(`http://localhost:${port}`);
    });
  } catch (err: any) {
    spinner.fail(ERR(`Failed to launch server: ${err.message}`));
    process.exit(1);
  }
}

// ── INIT (ENTERPRISE INITIALIZATION WIZARD) ──────────────────────────────────
async function cmdInit() {
  printBanner("Project Initialization Wizard");

  const cwd = process.cwd();
  loadEnv();

  const existingLock = await readLock();
  if (existingLock) {
    console.log(WARN("⚠  This project is already initialized with GN-Apex.\n"));
    const { proceed } = await inquirer.prompt([
      {
        type: "confirm",
        name: "proceed",
        message:
          "Re-initialize? This will update your configuration but keep existing data.",
        default: false,
      },
    ]);
    if (!proceed) {
      console.log(DIM("\n  Aborted.\n"));
      process.exit(0);
    }
  }

  const spinner = ora("Scanning project environment...").start();
  await sleep(400);
  const framework = detectFramework();
  const pm = detectPackageManager();
  const git = detectGit();
  const envFiles = detectEnvFiles();
  const pkg = tryReadJson(path.join(cwd, "package.json")) || {};
  spinner.succeed(SUCCESS("Environment scanned"));

  const table = new Table({
    style: { head: [], border: [] },
    chars: {
      top: "─",
      "top-mid": "┬",
      "top-left": "┌",
      "top-right": "┐",
      bottom: "─",
      "bottom-mid": "┴",
      "bottom-left": "└",
      "bottom-right": "┘",
      left: "│",
      "left-mid": "├",
      mid: "─",
      "mid-mid": "┼",
      right: "│",
      "right-mid": "┤",
      middle: "│",
    },
  });
  table.push(
    [DIM("  Framework"), chalk.white(framework.name)],
    [DIM("  Package Mgr"), chalk.white(pm)],
    [
      DIM("  Git Repo"),
      git.hasGit ? chalk.white(git.remote || "local") : DIM("none"),
    ],
    [
      DIM("  Env Files"),
      envFiles.length ? chalk.white(envFiles.join(", ")) : DIM("none found"),
    ],
    [DIM("  Node"), chalk.white(process.version)],
  );
  console.log("\n" + table.toString() + "\n");

  console.log(chalk.bold.white("  ① Credentials & Project\n"));

  let projectId =
    process.env.GNAPEX_PROJECT_ID || process.env.NEXT_PUBLIC_GNAPEX_ID || "";
  let apiKey =
    process.env.GNAPEX_API_KEY || process.env.NEXT_PUBLIC_GNAPEX_KEY || "";
  let apiUrl = process.env.GNAPEX_API_URL || DEFAULT_API_URL;

  if (!projectId) {
    const ans = await inquirer.prompt([
      {
        type: "input",
        name: "projectId",
        message: "GN-Apex Project ID:",
        validate: (v: string) =>
          v.trim().length > 4 || "Enter a valid project ID",
      },
    ]);
    projectId = ans.projectId.trim();
  } else {
    console.log(DIM(`  Project ID found in env: ${chalk.white(projectId)}`));
  }

  if (!apiKey) {
    const ans = await inquirer.prompt([
      {
        type: "password",
        name: "apiKey",
        message: "GN-Apex API Key:",
        validate: (v: string) =>
          v.trim().length > 10 || "Enter a valid API key",
      },
    ]);
    apiKey = ans.apiKey.trim();
  } else {
    console.log(
      DIM(`  API Key found in env: ${chalk.white("****" + apiKey.slice(-4))}`),
    );
  }

  const { customUrl } = await inquirer.prompt([
    {
      type: "confirm",
      name: "customUrl",
      message: "Use a custom API URL? (No = use default cloud endpoint)",
      default: false,
    },
  ]);
  if (customUrl) {
    const ans = await inquirer.prompt([
      {
        type: "input",
        name: "apiUrl",
        message: "API URL:",
        default: DEFAULT_API_URL,
        validate: (v: string) => {
          try {
            new URL(v);
            return true;
          } catch {
            return "Invalid URL";
          }
        },
      },
    ]);
    apiUrl = ans.apiUrl.trim();
  }

  const verifySpinner = ora(
    "Verifying credentials with GN-Apex API...",
  ).start();
  let projectData = null;
  let schemaData = null;
  try {
    projectData = await nexusFetch(`${apiUrl}/projects/${projectId}`, apiKey, {
      timeout: 15000,
    });
    verifySpinner.succeed(
      SUCCESS(
        `Connected: ${chalk.white(projectData?.data?.name || projectData?.name || projectId)}`,
      ),
    );
  } catch (err: any) {
    verifySpinner.warn(
      WARN(`Could not verify (${err.message}). Continuing offline.`),
    );
  }

  if (projectData) {
    const schemaSpinner = ora("Fetching project schema...").start();
    try {
      schemaData = await nexusFetch(
        `${apiUrl}/content/schema/${projectId}`,
        apiKey,
      );
      if (schemaData?.draft) schemaData = schemaData.draft;
      schemaSpinner.succeed(
        SUCCESS(
          `Schema loaded: ${schemaData?.pages?.length || 0} pages, ${schemaData?.collections?.length || 0} collections`,
        ),
      );
    } catch {
      schemaSpinner.warn(
        WARN("Schema not available. Will use empty scaffold."),
      );
    }
  }

  console.log("\n" + chalk.bold.white("  ② Workspace & Features\n"));

  const workspace =
    projectData?.data?.workspaceMode || projectData?.workspaceMode || "GENERAL";
  console.log(
    `   ${SUCCESS("✦")}  Workspace Mode: ${chalk.white(workspace)} ${DIM("(auto-synchronized from project)")}`,
  );

  console.log("\n" + chalk.bold.white("  ③ Environment Setup\n"));

  const envTarget = ".env.local";
  const envPath = path.join(cwd, envTarget);

  const { writeEnv } = await inquirer.prompt([
    {
      type: "confirm",
      name: "writeEnv",
      message: `Write credentials to ${chalk.cyan(envTarget)}?`,
      default: !envFiles.includes(envTarget),
    },
  ]);

  if (writeEnv) {
    const envSpinner = ora(`Writing ${envTarget}...`).start();
    let written = 0;
    if (await ensureEnvEntry(envPath, "GNAPEX_PROJECT_ID", projectId))
      written++;
    if (await ensureEnvEntry(envPath, "GNAPEX_API_KEY", apiKey)) written++;
    if (await ensureEnvEntry(envPath, "GNAPEX_API_URL", apiUrl)) written++;
    if (framework.id === "nextjs") {
      if (await ensureEnvEntry(envPath, "NEXT_PUBLIC_GNAPEX_ID", projectId))
        written++;
      if (await ensureEnvEntry(envPath, "NEXT_PUBLIC_GNAPEX_KEY", apiKey))
        written++;
      if (await ensureEnvEntry(envPath, "NEXT_PUBLIC_GNAPEX_API_URL", apiUrl))
        written++;
    }
    envSpinner.succeed(SUCCESS(`${written} variables written to ${envTarget}`));

    const gitignorePath = path.join(cwd, ".gitignore");
    if (await fs.pathExists(gitignorePath)) {
      const gitignore = await fs.readFile(gitignorePath, "utf8");
      if (!gitignore.includes(".env.local")) {
        await fs.appendFile(gitignorePath, "\n.env.local\n");
        console.log(DIM(`  + Added .env.local to .gitignore`));
      }
    }
  }

  const gitignorePath = path.join(cwd, ".gitignore");
  if (await fs.pathExists(gitignorePath)) {
    const gi = await fs.readFile(gitignorePath, "utf8");
    const entries = [".nx/cache.json", ".nx/local/"];
    for (const e of entries) {
      if (!gi.includes(e)) {
        await fs.appendFile(gitignorePath, `\n${e}`);
      }
    }
  }

  const scaffoldSpinner = ora("Scaffolding GN-Apex workspace...").start();
  const features = [
    "local_cache",
    "schema_validate",
    "type_gen",
    "analytics",
    "deploy",
  ];

  const config = {
    version: GNAPEX_VERSION,
    projectId,
    apiUrl,
    workspace,
    features,
    cacheStrategy: "memory",
    framework: framework.id,
    createdAt: new Date().toISOString(),
  };

  await fs.ensureDir(path.join(cwd, GNAPEX_DIR));
  await writeConfig(config, apiKey);

  const emptySchema = {
    schemaVersion: "1.0",
    projectId,
    lastPublished: null,
    lastModified: new Date().toISOString(),
    config: { siteName: pkg.name || "My Project" },
    pages: [],
    collections: [],
  };
  const schemaToWrite = schemaData || emptySchema;
  await writeSchema(schemaToWrite, apiKey, projectId);

  await fs.ensureDir(path.join(cwd, LOCAL_DATA_DIR, "pages"));
  await fs.ensureDir(path.join(cwd, LOCAL_DATA_DIR, "collections"));

  let pagesCreated = 0,
    colsCreated = 0;
  for (const page of schemaToWrite.pages || []) {
    const dataPath = path.join(
      cwd,
      LOCAL_DATA_DIR,
      "pages",
      `${page.apiKey}.nx`,
    );
    if (!(await fs.pathExists(dataPath))) {
      const emptyPageData = buildEmptyFromSchema(page.fields);
      await writeLocalData(
        "page",
        page.apiKey,
        emptyPageData,
        apiKey,
        projectId,
      );
      pagesCreated++;
    }
  }
  for (const col of schemaToWrite.collections || []) {
    const dataPath = path.join(
      cwd,
      LOCAL_DATA_DIR,
      "collections",
      `${col.apiKey}.nx`,
    );
    if (!(await fs.pathExists(dataPath))) {
      const emptyColData = [buildEmptyFromSchema(col.fields)];
      await writeLocalData(
        "collection",
        col.apiKey,
        emptyColData,
        apiKey,
        projectId,
      );
      colsCreated++;
    }
  }

  const globalsPath = path.join(cwd, LOCAL_DATA_DIR, "globals.nx");
  if (!(await fs.pathExists(globalsPath))) {
    const defaultGlobals = {
      siteName: pkg.name || "My Project",
      navigation: [],
      footer: { copyright: `© ${new Date().getFullYear()}` },
    };
    await writeLocalData("globals", null, defaultGlobals, apiKey, projectId);
  }

  await fs.writeFile(
    path.join(cwd, GNAPEX_DIR, "README.md"),
    `# GN-Apex Workspace

## Directory Structure

\`\`\`
.nx/
├── nexus.config.json     — SDK configuration
├── schema.json           — Your content schema (synced from dashboard)
├── cache.json            — Remote content cache (git-ignored)
├── local/
│   ├── pages/            — Local page data (one file per page)
│   ├── collections/      — Local collection data (one file per collection)
│   └── globals.json      — Global site settings
└── README.md
\`\`\`

## Workflow

| Command              | Description                                      |
| -------------------- | ------------------------------------------------ |
| \`npx apex pull\`   | Sync remote content to local cache               |
| \`npx apex push\`   | Push local data up to GN-Apex Cloud              |
| \`npx apex status\` | Show project health & content stats              |
| \`npx apex types\`  | Generate TypeScript definitions from schema      |
| \`npx apex validate\`| Validate local data against schema              |
| \`npx apex deploy\` | Deploy to GN-Apex Global Edge                    |
| \`npx apex schema\` | Show schema summary                              |

## Local Development

When \`NODE_ENV=development\`, the SDK automatically reads from \`.nx/local/\`
instead of making network calls. Edit the JSON files directly, then run
\`npx apex push\` to upload your changes.

Empty schema values are intentional placeholders — fill them with your content.
`,
  );

  if (
    features.includes("type_gen") &&
    (schemaToWrite.pages?.length || 0) +
      (schemaToWrite.collections?.length || 0) >
      0
  ) {
    const types = generateTypesFromSchema(schemaToWrite);
    const outPath = path.resolve(cwd, "types/nexus.d.ts");
    await fs.ensureDir(path.dirname(outPath));
    await fs.writeFile(outPath, types);
    console.log(DIM("  + Generated types/nexus.d.ts"));
  }

  await writeLock(config);
  scaffoldSpinner.succeed(SUCCESS("Workspace scaffolded"));

  if (framework.id === "nextjs") {
    const srcAppDir = path.join(cwd, "src/app");
    const appDir = path.join(cwd, "app");
    let targetApiDir = "";

    if (fs.existsSync(srcAppDir)) {
      targetApiDir = path.join(srcAppDir, "api", "revalidate");
    } else if (fs.existsSync(appDir)) {
      targetApiDir = path.join(appDir, "api", "revalidate");
    }

    if (targetApiDir) {
      const routePath = path.join(targetApiDir, "route.ts");
      if (!(await fs.pathExists(routePath))) {
        const routeContent = `// app/api/revalidate/route.ts
//
// 🛰️ GN-APEX EDGE REVALIDATION GATEWAY
//
// Receives secure, signed cache-purging handshakes from the GN-Apex (GN-Apex)
// Core Control Plane on every save, instantly evicting Next.js data caches
// across global edge nodes so visitors always receive fresh, production-grade content.

import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { createHash, timingSafeEqual } from "crypto";

export async function GET(request: NextRequest) {
  const projectId = request.nextUrl.searchParams.get("projectId");
  const timestamp = request.nextUrl.searchParams.get("ts");
  const signature = request.nextUrl.searchParams.get("sig");

  const secret = process.env.REVALIDATE_WEBHOOK_SECRET || process.env.NEXT_PUBLIC_GNAPEX_KEY;

  if (!projectId || !timestamp || !signature || !secret) {
    return NextResponse.json(
      { message: "Missing Handshake Parameters" },
      { status: 400 },
    );
  }

  if (Math.abs(Date.now() - Number(timestamp)) > 5 * 60 * 1000) {
    return NextResponse.json(
      { message: "Handshake Expired" },
      { status: 401 },
    );
  }

  const expected = createHash("sha256")
    .update(\`\${secret}.\${projectId}.\${timestamp}\`)
    .digest("hex");

  const expectedBuf = Buffer.from(expected, "hex");
  const providedBuf = Buffer.from(signature, "hex");

  if (
    expectedBuf.length !== providedBuf.length ||
    !timingSafeEqual(expectedBuf, providedBuf)
  ) {
    return NextResponse.json(
      { message: "Unauthorized Handshake" },
      { status: 401 },
    );
  }

  try {
    revalidatePath("/", "layout");

    return NextResponse.json({
      revalidated: true,
      now: Date.now(),
      message: "Cache successfully initialized."
    });
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ message: errMsg }, { status: 500 });
  }
}
`;
        await fs.ensureDir(targetApiDir);
        await fs.writeFile(routePath, routeContent);
        console.log(
          DIM("  + Auto-Injected Next.js On-Demand Revalidation API Route"),
        );
      }
    }
  }

  if (framework.id === "nextjs") {
    const publicDir = path.join(cwd, "public");
    const cfProject =
      projectData?.edgeInstanceId ||
      projectData?.cloudflareProjectName ||
      projectData?.subdomain ||
      projectId ||
      "gnapex-edge";

    if (fs.existsSync(publicDir)) {
      const swPath = path.join(publicDir, "sw.js");
      if (!(await fs.pathExists(swPath))) {
        const swContent = `// public/sw.js
// 🛰️ GN-APEX UNIFIED SERVICE WORKER — OFFLINE CACHE & WEBPUSH RECEIVER

const CACHE_NAME = "${cfProject}-cache-v1";
const PRECACHE_ASSETS = ["/", "/favicon.ico"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_ASSETS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cache) => {
            if (cache !== CACHE_NAME) {
              return caches.delete(cache);
            }
          }),
        );
      })
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  if (request.method !== "GET" || !url.protocol.startsWith("http")) {
    return;
  }

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.status === 200) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => {
          return caches.match(request).then((cachedResponse) => {
            return cachedResponse || caches.match("/");
          });
        }),
    );
    return;
  }

  const isStaticAsset =
    request.destination === "style" ||
    request.destination === "script" ||
    request.destination === "font" ||
    request.destination === "image";

  if (isStaticAsset) {
    event.respondWith(
      caches.match(request).then((cachedResponse) => {
        if (cachedResponse) {
          fetch(request)
            .then((response) => {
              if (response.status === 200) {
                caches
                  .open(CACHE_NAME)
                  .then((cache) => cache.put(request, response));
              }
            })
            .catch(() => {});

          return cachedResponse;
        }

        return fetch(request).then((response) => {
          if (response.status === 200) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          }
          return response;
        });
      }),
    );
    return;
  }

  event.respondWith(fetch(request).catch(() => caches.match(request)));
});

self.addEventListener("push", (event) => {
  if (!event.data) return;

  try {
    const payload = event.data.json();
    const { title, body, icon, badge, data } = payload.notification;

    event.waitUntil(
      self.registration.showNotification(title, {
        body: body || "",
        icon: icon || "/assets/icons/icon-192x192.png",
        badge: badge || "/assets/icons/badge-72x72.png",
        data: data || {},
      })
    );
  } catch (err) {
    console.error("[Service Worker] Push parsing failed:", err);
  }
});

self.addEventListener("notificationclick", (event) => {
  const notification = event.notification;
  notification.close();

  const targetUrl = notification.data?.url || "/";

  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url === targetUrl && "focus" in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});
`;
        await fs.ensureDir(publicDir);
        await fs.writeFile(swPath, swContent);
        console.log(DIM("  + Auto-Injected PWA & WebPush Service Worker"));
      }
    }
  }

  console.log("\n" + chalk.bold.white("  ④ Provisioning Dependencies\n"));
  const depsSpinner = ora("Installing GN-Apex SDK dependencies...").start();
  const deps = ["@gnapex/sdk"];
  const installCmd = pm === "npm" ? "npm install" : `${pm} add`;
  try {
    execSync(`${installCmd} ${deps.join(" ")}`, { stdio: "pipe" });
    depsSpinner.succeed(SUCCESS("GN-Apex SDK dependencies provisioned"));
  } catch (err: any) {
    depsSpinner.warn(WARN("Dependency provisioning needs attention"));
    console.log(
      DIM(
        "  Project initialization completed, but the SDK dependency could not be installed automatically.",
      ),
    );
    if (err?.stderr)
      console.log(DIM(scrubOutput(err.stderr.toString().trim())));
  }

  console.log("\n" + chalk.bold.white("  ⑤ Integration Snippet\n"));

  if (framework.id === "nextjs") {
    console.log(DIM("  Add this to your Next.js project:\n"));
    console.log(
      chalk.bgGray.white("  // lib/nexus.ts                                "),
    );
    console.log(
      chalk.cyan(`  import { createNexusClient } from '@gnapex/sdk';
  export const nexus = createNexusClient({
    projectId: process.env.NEXT_PUBLIC_GNAPEX_ID!,
    apiKey:    process.env.NEXT_PUBLIC_GNAPEX_KEY!,
  });\n`),
    );
  } else if (framework.id === "sveltekit") {
    console.log(
      chalk.cyan(`  import { createNexusClient } from '@gnapex/sdk';
  export const nexus = createNexusClient({
    projectId: import.meta.env.VITE_NEXUS_ID,
    apiKey:    import.meta.env.VITE_NEXUS_KEY,
  });\n`),
    );
  } else {
    console.log(
      chalk.cyan(`  import { createNexusClient } from '@gnapex/sdk';
  export const nexus = createNexusClient({
    projectId: process.env.GNAPEX_PROJECT_ID,
    apiKey:    process.env.GNAPEX_API_KEY,
  });\n`),
    );
  }

  const summary = new Table({ style: { head: [], border: [] } });
  summary.push(
    [DIM("  Status"), SUCCESS("✔  Initialized")],
    [DIM("  Project"), chalk.white(projectId)],
    [DIM("  Workspace"), chalk.white(workspace)],
    [DIM("  Features"), chalk.white(features.join(", ") || "none")],
    [DIM("  Framework"), chalk.white(framework.name)],
    [
      DIM("  Pages"),
      chalk.white(
        String(
          pagesCreated + ((schemaToWrite.pages?.length || 0) - pagesCreated),
        ),
      ),
    ],
    [
      DIM("  Collections"),
      chalk.white(String(schemaToWrite.collections?.length || 0)),
    ],
  );
  console.log(summary.toString());

  console.log("\n" + chalk.bold("  Next Steps:"));
  console.log(DIM(`  1. Pull content:    ${chalk.white("npx apex pull")}`));
  console.log(DIM(`  2. Validate data:   ${chalk.white("npx apex validate")}`));
  console.log(DIM(`  3. Generate types:  ${chalk.white("npx apex types")}\n`));
}

// ── PULL ──────────────────────────────────────────────────────────────────────
async function cmdPull(opts: any) {
  printBanner("Content Sync — Pull from Remote");

  const { apiKey, projectId, apiUrl } = requireCredentials(opts);
  const spinner = ora("Connecting to GN-Apex API...").start();

  try {
    spinner.text = "Pulling schema...";
    let schema = null;
    try {
      schema = await nexusFetch(
        `${apiUrl}/content/schema/${projectId}`,
        apiKey,
      );
      if (schema?.draft) schema = schema.draft;
      await writeSchema(schema, apiKey, projectId);
      spinner.text = "Schema updated ✓";
    } catch {
      spinner.text = "Schema unavailable, using cached";
      try {
        schema = await readSchema(apiKey);
      } catch {}
    }

    spinner.text = "Pulling pages...";
    let pages = [];
    try {
      const pagesRes = await nexusFetch(
        `${apiUrl}/content/${projectId}/pages`,
        apiKey,
      );
      pages = pagesRes?.data || pagesRes || [];
    } catch (e: any) {
      spinner.warn(WARN(`  Pages: ${e.message}`));
    }

    spinner.text = "Pulling collections...";
    const collections: Record<string, any[]> = {};
    if (schema?.collections?.length) {
      for (const col of schema.collections) {
        try {
          const res = await nexusFetch(
            `${apiUrl}/content/${projectId}/collection/${col.apiKey}?limit=1000`,
            apiKey,
          );
          const items = res?.items || res?.data || res || [];
          collections[col.apiKey] = items;

          if (opts.writeLocal !== false) {
            await writeLocalData(
              "collection",
              col.apiKey,
              items,
              apiKey,
              projectId,
            );
          }
        } catch {
          if (opts.writeLocal !== false) {
            const emptyItems = [buildEmptyFromSchema(col.fields)];
            await writeLocalData(
              "collection",
              col.apiKey,
              emptyItems,
              apiKey,
              projectId,
            );
            collections[col.apiKey] = emptyItems;
          }
        }
      }
    }

    spinner.text = "Pulling globals...";
    let globals = {};
    try {
      const globRes = await nexusFetch(
        `${apiUrl}/content/${projectId}/globals`,
        apiKey,
      );
      globals = globRes?.data || globRes || {};
      await writeLocalData("globals", null, globals, apiKey, projectId);
    } catch {}

    if (Array.isArray(pages)) {
      for (const page of pages) {
        const slug = page.slug || page.id;
        if (slug) await writeLocalData("page", slug, page, apiKey, projectId);
      }
    }

    if (schema?.pages) {
      for (const sp of schema.pages) {
        const localPagePath = path.join(
          process.cwd(),
          LOCAL_DATA_DIR,
          "pages",
          `${sp.apiKey}.nx`,
        );
        if (!(await fs.pathExists(localPagePath))) {
          const emptyPageData = buildEmptyFromSchema(sp.fields);
          await writeLocalData(
            "page",
            sp.apiKey,
            emptyPageData,
            apiKey,
            projectId,
          );
          pages.push({ slug: sp.apiKey, data: emptyPageData });
        }
      }
    }

    const originPayload = {
      projectId,
      pulledAt: new Date().toISOString(),
      data: {
        pages: pages.reduce((acc: any, p: any) => {
          acc[p.slug] = p.data || p;
          return acc;
        }, {}),
        collections,
        globals,
      },
    };

    const originPath = path.resolve(process.cwd(), ORIGIN_FILE);
    const compiledOrigin = BinaryCompiler.compile(
      originPayload,
      apiKey,
      projectId,
    );
    await fs.writeFile(originPath, compiledOrigin);

    spinner.succeed(SUCCESS("Content pulled and synchronized successfully"));

    const t = new Table({ style: { head: [], border: [] } });
    t.push(
      [DIM("  Pages Pulled"), chalk.white(String(pages.length))],
      [
        DIM("  Collections Pulled"),
        chalk.white(String(schema?.collections?.length || 0)),
      ],
      [
        DIM("  Globals File"),
        chalk.white(Object.keys(globals).length ? "synchronized" : "empty"),
      ],
      [DIM("  Local Directory"), chalk.white(LOCAL_DATA_DIR)],
      [DIM("  Pulled at"), chalk.white(new Date().toLocaleString())],
    );
    console.log("\n" + t.toString() + "\n");
  } catch (err: any) {
    spinner.fail(ERR("Pull failed: " + err.message));
    if (err.status === 401) console.log(DIM("  → Check your GNAPEX_API_KEY"));
    if (err.status === 404)
      console.log(DIM("  → Check your GNAPEX_PROJECT_ID"));
    process.exit(1);
  }
}

// ─── PUSH ──────────────────────────────────────────────────────────────────────
async function cmdPush(opts: any) {
  printBanner("Content Sync — Push to Remote");

  const { apiKey, projectId, apiUrl } = requireCredentials(opts);

  const originPath = path.resolve(process.cwd(), ORIGIN_FILE);
  if (await fs.pathExists(originPath)) {
    const buffer = await fs.readFile(originPath);
    const { data: origin } = BinaryCompiler.decompile(buffer, apiKey);

    const conflictSpinner = ora("Checking remote repository state...").start();
    try {
      const remoteRes = await nexusFetch(
        `${apiUrl}/projects/${projectId}`,
        apiKey,
        { timeout: 10000 },
      );
      const project = remoteRes?.data || remoteRes;
      conflictSpinner.stop();

      const remoteUpdateTime = new Date(project.updatedAt).getTime();
      const lastPullTime = new Date(origin.pulledAt).getTime();

      if (remoteUpdateTime > lastPullTime + 3000) {
        console.log(
          ERR(
            "\n🚨  CONFLICT DETECTED: Upstream database is newer than your local sandbox.",
          ),
        );
        console.log(
          DIM(
            `    - Last Local Pull: ${new Date(lastPullTime).toLocaleString()}`,
          ),
        );
        console.log(
          DIM(
            `    - Remote Updated:  ${new Date(remoteUpdateTime).toLocaleString()}`,
          ),
        );
        console.log(
          DIM("    Push aborted to prevent overwriting coworker changes."),
        );
        console.log(
          DIM(
            "    Run 'npx apex pull' to fetch upstream, or 'npx apex push --force' to overwrite.\n",
          ),
        );

        if (!opts.force) process.exit(1);
        console.log(
          WARN(
            "⚠️  Fulfillment Gated: --force flag active. Overwriting remote...",
          ),
        );
      }
    } catch (e: any) {
      conflictSpinner.warn(
        WARN(
          `Could not complete conflict handshake (${e.message}). Proceeding.`,
        ),
      );
    }
  }

  let schema = null;
  try {
    schema = await readSchema(apiKey);
  } catch {}

  const spinner = ora("Reading local data...").start();
  const local = await getLocalData(apiKey);
  spinner.succeed(
    `Local data compiled: ${Object.keys(local.pages).length} pages, ${Object.keys(local.collections).length} collections`,
  );

  if (schema) {
    const valSpinner = ora("Validating against schema...").start();
    const { errors, warnings } = validateLocalAgainstSchema(local, schema);
    if (errors.length) {
      valSpinner.fail(
        ERR(`Schema validation failed: ${errors.length} error(s)`),
      );
      for (const e of errors) console.log(ERR(`  ✖ ${e}`));
      if (!opts.force) {
        const { proceed } = await inquirer.prompt([
          {
            type: "confirm",
            name: "proceed",
            message: "Push anyway?",
            default: false,
          },
        ]);
        if (!proceed) {
          console.log(DIM("\n  Aborted.\n"));
          process.exit(0);
        }
      }
    } else {
      valSpinner.succeed(
        SUCCESS(
          "Validation passed" +
            (warnings.length ? ` (${warnings.length} warnings)` : ""),
        ),
      );
      if (warnings.length)
        for (const w of warnings) console.log(WARN(`  ⚠ ${w}`));
    }
  }

  if (await fs.pathExists(originPath)) {
    const buffer = await fs.readFile(originPath);
    const { data: origin } = BinaryCompiler.decompile(buffer, apiKey);
    const diff = computeDiff(origin.data, local);
    const hasPendingChanges =
      diff.added.length > 0 ||
      diff.removed.length > 0 ||
      diff.modified.length > 0;

    if (!hasPendingChanges && !opts.force) {
      console.log(
        SUCCESS(
          "\n  ✔  Everything up-to-date. No pending changesets to push.\n",
        ),
      );
      return;
    }
  }

  if (opts.dryRun) {
    console.log(WARN("\n  Dry-run mode — nothing will be pushed.\n"));
    console.log(DIM("  Would push unified changeset:"));
    for (const slug of Object.keys(local.pages))
      console.log(DIM(`    page       ${slug}`));
    for (const [id, data] of Object.entries(local.collections))
      console.log(
        DIM(
          `    collection ${id} (${Array.isArray(data) ? data.length : 1} items)`,
        ),
      );
    if (Object.keys(local.globals).length)
      console.log(
        DIM(`    globals    ${Object.keys(local.globals).length} keys`),
      );
    console.log();
    return;
  }

  const pushSpinner = ora(
    "Packaging and pushing local workspace live...",
  ).start();

  try {
    if (schema) {
      pushSpinner.text = "Syncing and Publishing Schema...";
      await nexusFetch(`${apiUrl}/content/schema/${projectId}/draft`, apiKey, {
        method: "PATCH",
        body: { schema },
      });
      await nexusFetch(
        `${apiUrl}/content/schema/${projectId}/publish`,
        apiKey,
        { method: "POST" },
      );
    }

    pushSpinner.text = "Uploading Content Data...";
    const unifiedData = {
      ...local.pages,
      ...local.collections,
      globals: local.globals,
    };
    await nexusFetch(`${apiUrl}/content/${projectId}/data`, apiKey, {
      method: "PUT",
      body: { data: unifiedData },
    });

    const originPayload = {
      projectId,
      pulledAt: new Date().toISOString(),
      data: {
        pages: local.pages,
        collections: local.collections,
        globals: local.globals,
      },
    };
    const compiledOrigin = BinaryCompiler.compile(
      originPayload,
      apiKey,
      projectId,
    );
    await fs.writeFile(originPath, compiledOrigin);

    pushSpinner.succeed(SUCCESS("Push & Publish completed successfully!"));
    console.log(
      SUCCESS(
        `  ✔  Schema published and all changes successfully synced to GN-Apex Global Edge.\n`,
      ),
    );
  } catch (error: any) {
    pushSpinner.fail(ERR("Push transaction failed"));
    console.error(ERR(`   Error: ${error.message}`));
    process.exit(1);
  }
}

// ── VALIDATE ──────────────────────────────────────────────────────────────────
async function cmdValidate() {
  printBanner("Schema Validator");

  const { apiKey } = getCredentials();

  let schema = null;
  try {
    schema = await readSchema(apiKey);
  } catch {
    console.log(ERR("  No schema found. Run `npx apex pull` first.\n"));
    process.exit(1);
  }

  const local = await getLocalData(apiKey);
  const spinner = ora("Validating local data...").start();
  await sleep(200);

  const { errors, warnings } = validateLocalAgainstSchema(local, schema);
  spinner.stop();

  if (errors.length === 0 && warnings.length === 0) {
    console.log(
      SUCCESS("\n  ✔  All local data is valid and matches the schema.\n"),
    );
    return;
  }

  if (errors.length) {
    console.log(ERR(`\n  ✖  ${errors.length} error(s) found:\n`));
    for (const e of errors) console.log(ERR(`     • ${e}`));
  }
  if (warnings.length) {
    console.log(WARN(`\n  ⚠  ${warnings.length} warning(s):\n`));
    for (const w of warnings) console.log(WARN(`     • ${w}`));
  }
  console.log();
  if (errors.length > 0) process.exit(1);
}

// ── SCHEMA ────────────────────────────────────────────────────────────────────
async function cmdSchema(opts: any) {
  printBanner("Schema Inspector");
  const { apiKey, projectId, apiUrl } = getCredentials(opts);

  let schema = null;
  try {
    schema = await readSchema(apiKey);
  } catch {
    console.log(
      ERR("  No schema found. Run `npx apex pull` or `npx apex init` first.\n"),
    );
    process.exit(1);
  }

  if (opts.refresh && apiKey && projectId) {
    const s = ora("Refreshing schema from API...").start();
    try {
      let fresh = await nexusFetch(
        `${apiUrl}/content/schema/${projectId}`,
        apiKey,
      );
      if (fresh?.draft) fresh = fresh.draft;
      await writeSchema(fresh, apiKey, projectId);
      schema = fresh;
      s.succeed(SUCCESS("Schema refreshed"));
    } catch (e: any) {
      s.warn(WARN("Could not refresh: " + e.message));
    }
  }

  console.log(chalk.bold("\n  Schema Summary\n"));
  const t = new Table({
    head: [
      DIM("Type"),
      DIM("API Key"),
      DIM("Fields"),
      DIM("Versioning"),
      DIM("Cache"),
    ],
    style: { head: [], border: [] },
  });

  for (const node of [...(schema.pages || []), ...(schema.collections || [])]) {
    t.push([
      node.type === "COLLECTION"
        ? chalk.cyan("Collection")
        : chalk.magenta("Singleton"),
      chalk.white(node.apiKey),
      chalk.white(String(node.fields?.length || 0)),
      node.enableVersioning ? SUCCESS("✔") : DIM("—"),
      chalk.white(node.cacheStrategy || "stale-while-revalidate"),
    ]);
  }
  console.log(t.toString());

  if (opts.fields) {
    const target = [
      ...(schema.pages || []),
      ...(schema.collections || []),
    ].find((n) => n.apiKey === opts.fields);
    if (!target) {
      console.log(ERR(`\n  Node '${opts.fields}' not found in schema.\n`));
      return;
    }
    console.log(chalk.bold(`\n  Fields: ${target.name} (${target.apiKey})\n`));
    const ft = new Table({
      head: [DIM("Name"), DIM("Type"), DIM("Required"), DIM("Default")],
      style: { head: [], border: [] },
    });
    for (const f of target.fields || []) {
      ft.push([
        chalk.white(f.name),
        chalk.cyan(f.type),
        f.validation?.required ? SUCCESS("✔") : DIM("—"),
        f.defaultValue !== undefined
          ? chalk.white(JSON.stringify(f.defaultValue))
          : DIM("—"),
      ]);
    }
    console.log(ft.toString());
  }
  console.log();
}

// ── TYPES ─────────────────────────────────────────────────────────────────────
async function cmdTypes(opts: any) {
  printBanner("TypeScript Definition Generator");

  const { apiKey, projectId, apiUrl } = getCredentials(opts);

  let schema = null;
  try {
    schema = await readSchema(apiKey);
  } catch {
    console.log(ERR("  No schema found. Run `npx apex pull` first.\n"));
    process.exit(1);
  }

  if (opts.refresh && apiKey && projectId) {
    const s = ora("Refreshing schema...").start();
    try {
      let fresh = await nexusFetch(
        `${apiUrl}/content/schema/${projectId}`,
        apiKey,
      );
      if (fresh?.draft) fresh = fresh.draft;
      schema = fresh;
      await fs.writeJson(path.join(process.cwd(), SCHEMA_FILE), schema, {
        spaces: 2,
      });
      s.succeed(SUCCESS("Schema refreshed"));
    } catch (e: any) {
      s.warn(WARN("Using cached schema: " + e.message));
    }
  }

  const spinner = ora("Generating TypeScript definitions...").start();
  const types = generateTypesFromSchema(schema);
  const outPath = path.resolve(
    process.cwd(),
    opts.output || "types/nexus.d.ts",
  );
  await fs.ensureDir(path.dirname(outPath));
  await fs.writeFile(outPath, types);
  spinner.succeed(
    SUCCESS(`Types written to ${path.relative(process.cwd(), outPath)}`),
  );

  const lines = types.split("\n").length;
  const nodes = (schema.pages?.length || 0) + (schema.collections?.length || 0);
  console.log(DIM(`\n  ${nodes} interfaces · ${lines} lines\n`));
}

// ── STATUS ────────────────────────────────────────────────────────────────────
async function cmdStatus(opts: any) {
  printBanner("Project Status");

  const { apiKey, projectId, apiUrl } = requireCredentials(opts);
  const config = await readConfig();
  const lock = await readLock();
  const local = await getLocalData();

  const t = new Table({ style: { head: [], border: [] } });
  t.push(
    [DIM("  Project ID"), chalk.white(projectId)],
    [DIM("  SDK Version"), chalk.white(GNAPEX_VERSION)],
    [
      DIM("  Initialized"),
      chalk.white(lock ? new Date(lock.initializedAt).toLocaleString() : "—"),
    ],
    [DIM("  Workspace"), chalk.white(config?.workspace || "GENERAL")],
    [DIM("  Framework"), chalk.white(config?.framework || "—")],
    [
      DIM("  Local Pages"),
      chalk.white(String(Object.keys(local.pages).length)),
    ],
    [
      DIM("  Local Cols"),
      chalk.white(String(Object.keys(local.collections).length)),
    ],
    [
      DIM("  Features"),
      chalk.white((config?.features || []).join(", ") || "—"),
    ],
  );
  console.log("\n" + t.toString());

  const spinner = ora("Fetching remote project status...").start();
  try {
    const res = await nexusFetch(`${apiUrl}/projects/${projectId}`, apiKey, {
      timeout: 10000,
    });
    const proj = res?.data || res;
    spinner.succeed(SUCCESS("Remote: Connected"));

    const rt = new Table({ style: { head: [], border: [] } });
    rt.push(
      [DIM("  Project Name"), chalk.white(proj.name || "—")],
      [DIM("  Status"), chalk.white(proj.status || "—")],
      [DIM("  Type"), chalk.white(proj.type || "—")],
      [DIM("  Live URL"), proj.liveUrl ? chalk.cyan(proj.liveUrl) : DIM("—")],
      [
        DIM("  Last Updated"),
        chalk.white(
          proj.updatedAt ? new Date(proj.updatedAt).toLocaleString() : "—",
        ),
      ],
      [DIM("  Subscription"), chalk.white(proj.subscriptionTier || "—")],
    );
    console.log("\n" + rt.toString());
  } catch (err: any) {
    spinner.warn(WARN("Remote: Could not connect (" + err.message + ")"));
  }
  console.log();
}

// ── PRODUCTION DEPLOYMENT CORE ───────────────────────────────────────────────
class ApexError extends Error {
  code: string;
  hint?: string;
  retryable: boolean;
  stage?: string;
  constructor(
    message: string,
    options: {
      code?: string;
      hint?: string;
      retryable?: boolean;
      stage?: string;
    } = {},
  ) {
    super(message);
    this.name = "ApexError";
    this.code = options.code || "APEX_INTERNAL_ERROR";
    this.hint = options.hint;
    this.retryable = !!options.retryable;
    this.stage = options.stage;
  }
}

function formatBytes(bytes: number) {
  if (!Number.isFinite(bytes) || bytes < 1024)
    return `${Math.max(0, bytes || 0)} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let value = bytes / 1024;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return `${value.toFixed(value >= 10 ? 1 : 2)} ${units[i]}`;
}

async function sha256File(filePath: string): Promise<string> {
  return await new Promise((resolve, reject) => {
    const hash = crypto.createHash("sha256");
    const stream = fs.createReadStream(filePath);
    stream.on("error", reject);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("end", () => resolve(hash.digest("hex")));
  });
}

function getGitMetadata() {
  const run = (cmd: string) => {
    try {
      return execSync(cmd, {
        cwd: process.cwd(),
        stdio: ["ignore", "pipe", "ignore"],
      })
        .toString()
        .trim();
    } catch {
      return undefined;
    }
  };
  const commit = run("git rev-parse HEAD");
  if (!commit) return undefined;
  return {
    commit,
    branch: run("git rev-parse --abbrev-ref HEAD"),
    message: run("git log -1 --pretty=%s"),
    dirty: !!run("git status --porcelain"),
  };
}

async function runDeployPreflight(projectId: string, framework: any) {
  const root = process.cwd();
  const checks = [
    {
      label: "Project directory accessible",
      ok: await fs.pathExists(root),
      code: "APEX_PREFLIGHT_DIRECTORY",
    },
    {
      label: "Package manifest detected",
      ok: await fs.pathExists(path.join(root, "package.json")),
      code: "APEX_PREFLIGHT_PACKAGE",
    },
    {
      label: "Supported Node.js runtime",
      ok: semver.gte(process.version, "18.0.0"),
      code: "APEX_PREFLIGHT_NODE",
    },
    {
      label: "Framework detected",
      ok: !!(framework?.id || framework?.name),
      code: "APEX_PREFLIGHT_FRAMEWORK",
    },
    {
      label: "GN-Apex project linked",
      ok: !!projectId,
      code: "APEX_PREFLIGHT_PROJECT",
    },
  ];
  for (const check of checks) {
    if (check.ok) console.log(`  ${SUCCESS("✔")}  ${chalk.white(check.label)}`);
    else
      throw new ApexError(check.label, {
        code: check.code,
        stage: "preflight",
        hint: "Run `apex init` or correct the project configuration before deploying.",
      });
  }
}

function renderApexError(error: any) {
  const err =
    error instanceof ApexError
      ? error
      : new ApexError(
          scrubOutput(error?.message || "An unexpected error occurred."),
          { code: error?.code || "APEX_INTERNAL_ERROR" },
        );
  console.error("\n" + ERR("✖  GN-Apex operation failed"));
  if (err.stage) console.error(DIM(`   Stage: ${err.stage}`));
  console.error(DIM(`   ${scrubOutput(err.message)}`));
  console.error(DIM(`   Error code: ${err.code}`));
  if (err.hint) console.error(DIM(`   Hint: ${err.hint}`));
  if (err.retryable)
    console.error(
      DIM(
        "   This failure may be temporary. You can safely run the command again.",
      ),
    );
}

// ── DEPLOY (GN-APEX MANAGED PRODUCTION DEPLOYMENT) ───────────────────────────
async function createDeploymentArchive(): Promise<{
  archivePath: string;
  cleanup: () => Promise<void>;
}> {
  const root = process.cwd();
  const archivePath = path.join(
    os.tmpdir(),
    `apex-deploy-${Date.now()}-${crypto.randomBytes(4).toString("hex")}.tar.gz`,
  );
  const pkg = tryReadJson(path.join(root, "package.json")) || {};
  const ignores = [
    ".git",
    "node_modules",
    ".next/cache",
    ".open-next",
    ".wrangler",
    ".nexus",
    ".gnapex",
    ".nx",
    ".env",
    ".env.local",
    ".env.production",
    ".env.development",
  ];
  const extra = Array.isArray(pkg?.gnapex?.ignore) ? pkg.gnapex.ignore : [];
  const args = [
    "-czf",
    archivePath,
    ...[...ignores, ...extra].flatMap((x) => ["--exclude", x]),
    ".",
  ];
  try {
    execSync(`tar ${args.map((x) => JSON.stringify(String(x))).join(" ")}`, {
      cwd: root,
      stdio: "pipe",
    });
  } catch (error: any) {
    if (fs.existsSync(archivePath) && fs.statSync(archivePath).size > 100) {
      // Archive was created successfully! Proceed.
    } else {
      throw new ApexError(
        `Could not package the deployment artifact. ${scrubOutput(error?.message || "")}`.trim(),
        {
          code: "APEX_ARTIFACT_PACKAGE_FAILED",
          stage: "packaging",
          hint: "Check file permissions and ensure the project directory is readable.",
        },
      );
    }
  }
  return {
    archivePath,
    cleanup: async () => {
      try {
        await fs.remove(archivePath);
      } catch {}
    },
  };
}

async function uploadDeploymentArtifact(
  uploadUrl: string,
  archivePath: string,
  deploymentToken?: string,
) {
  const stat = await fs.stat(archivePath);
  const body = fs.createReadStream(archivePath) as any;
  let response: any;
  try {
    response = await fetch(uploadUrl, {
      method: "PUT",
      headers: {
        "Content-Type": "application/gzip",
        "Content-Length": String(stat.size),
        ...(deploymentToken
          ? { Authorization: `Bearer ${deploymentToken}` }
          : {}),
        "X-GN-Apex-Artifact": "source-archive",
      },
      body,
    } as any);
  } catch (error: any) {
    throw new ApexError(
      "Connection to GN-Apex was interrupted while transferring the artifact.",
      {
        code: "APEX_NETWORK_UPLOAD_FAILED",
        stage: "upload",
        retryable: true,
        hint: "Check your connection and run `apex deploy` again.",
      },
    );
  }
  if (!response.ok)
    throw new ApexError(
      `Artifact transfer failed with HTTP ${response.status}.`,
      {
        code: "APEX_ARTIFACT_UPLOAD_REJECTED",
        stage: "upload",
        retryable: response.status >= 500,
      },
    );
}

// tools/cli.ts

async function cmdDeploy(opts: any) {
  printBanner("Production Deployment");
  let artifact:
    | { archivePath: string; cleanup: () => Promise<void> }
    | undefined;

  const wranglerPath = path.resolve(process.cwd(), "wrangler.json");
  const wranglerTomlPath = path.resolve(process.cwd(), "wrangler.toml");
  const openNextPath = path.resolve(process.cwd(), "open-next.config.ts");
  const dotWranglerPath = path.resolve(process.cwd(), ".wrangler");
  const dotOpenNextPath = path.resolve(process.cwd(), ".open-next");

  try {
    const { apiKey, projectId, apiUrl } = requireCredentials(opts);
    const environment = opts.environment || "production";
    const framework = detectFramework();

    console.log(chalk.bold("\n  Preflight checks\n"));
    await runDeployPreflight(projectId, framework);

    // [1/6] Verify Project Access
    const verify = ora("\n[1/6] Verifying GN-Apex project access...").start();
    const response = await nexusFetch(
      `${apiUrl}/projects/${projectId}`,
      apiKey,
    );
    const projectData = response?.data || response;

    verify.succeed(
      SUCCESS(`Connected to ${projectData?.name || "GN-Apex project"}`),
    );

    // Remote GitHub Pipeline Check
    const hasRepository = !!(
      projectData?.githubOwner && projectData?.githubRepo
    );
    if (hasRepository) {
      const git = getGitMetadata();
      const remote = ora("[2/6] Starting GN-Apex managed release...").start();
      const deployment = await nexusFetch(
        `${apiUrl}/projects/${projectId}/deploy`,
        apiKey,
        {
          method: "POST",
          body: { environment, trigger: "apex-cli", source: "repository", git },
          timeout: 60000,
        },
      );
      remote.succeed(SUCCESS("Managed deployment started"));
      console.log(
        DIM(
          `  Deployment: ${chalk.white(deployment?.deploymentId || deployment?.id || "queued")}`,
        ),
      );
      console.log(
        DIM(
          `  Source:     ${chalk.white(`${projectData.githubOwner}/${projectData.githubRepo}`)}`,
        ),
      );
      console.log(
        SUCCESS(
          "\n  GN-Apex is building and releasing this project through managed infrastructure.\n",
        ),
      );
      return;
    }

    // [2/6] Next.js Production Build
    const build = ora("[2/6] Building production application...").start();
    try {
      const pm = detectPackageManager();
      execSync(`${pm} run build`, {
        stdio: "pipe",
        env: {
          ...process.env,
          NODE_ENV: "production",
          NODE_OPTIONS: "--dns-result-order=ipv4first",
        },
      });
      build.succeed(
        SUCCESS(
          `Production build complete (${framework.name || framework.id || "Next.js"})`,
        ),
      );
    } catch (error: any) {
      const fullError =
        error?.stdout?.toString() ||
        error?.stderr?.toString() ||
        error?.message ||
        "Production build failed.";
      throw new ApexError(scrubOutput(fullError.trim()), {
        code: "APEX_BUILD_FAILED",
        stage: "build",
        hint: "Fix the build error locally, verify with your package manager, then deploy again.",
      });
    }

    // [3/6] Package Artifact
    const archiveSpinner = ora(
      "[3/6] Packaging deployment artifact...",
    ).start();
    artifact = await createDeploymentArchive();
    const artifactSize = (await fs.stat(artifact.archivePath)).size;
    archiveSpinner.succeed(
      SUCCESS(`Artifact packaged (${formatBytes(artifactSize)})`),
    );

    // [4/6] Verify Integrity
    const checksumSpinner = ora(
      "[4/6] Verifying artifact integrity...",
    ).start();
    const sha256 = await sha256File(artifact.archivePath);
    checksumSpinner.succeed(
      SUCCESS(`SHA-256 verified (${sha256.slice(0, 16)}…)`),
    );

    // [5/6] Secure Authorization Token from NestJS Backend
    const sessionSpinner = ora(
      "[5/6] Securing GN-Apex deployment authorization...",
    ).start();

    const git = getGitMetadata();
    const session = await nexusFetch(
      `${apiUrl}/devops/projects/${projectId}/deploy/token`,
      apiKey,
      {
        method: "POST",
        timeout: 60000,
        body: {
          environment,
          framework: framework.id,
          cliVersion: GNAPEX_VERSION,
          git,
          artifact: {
            name: path.basename(artifact.archivePath),
            format: "tar.gz",
            size: artifactSize,
            sha256,
          },
        },
      },
    );

    const data = session?.data || session;
    const token = data?.token;
    const accountId = data?.accountId;
    const d1DatabaseId = data?.d1DatabaseId;
    const deploymentId = data?.deploymentId || token || projectId;

    if (!token || typeof token !== "string" || token.trim().length === 0) {
      throw new ApexError(
        "GN-Apex Control Plane did not return a valid deployment token.",
        {
          code: "APEX_TOKEN_INVALID",
          stage: "authorization",
        },
      );
    }

    sessionSpinner.succeed(
      SUCCESS(`Deployment authorization ready (${token.slice(0, 16)}...)`),
    );

    // 🛡️ Resolve the exact project name matching your backend Cloudflare project
    // [6/6] Transfer and Deploy
    const proj = projectData?.data || projectData;
    const cfProject = (
      session?.projectName ||
      session?.data?.projectName ||
      proj?.cloudflareProjectName ||
      proj?.subdomain ||
      proj?.name ||
      projectId
    )
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9-_]/g, "-");

    const uploadSpinner = ora(
      `[6/6] Transferring release to GN-Apex Edge (${cfProject})...`,
    ).start();

    try {
      const wranglerPkgPath = require.resolve("wrangler/package.json");
      const wranglerPkg = await fs.readJson(wranglerPkgPath);
      const binRelativePath =
        typeof wranglerPkg.bin === "string"
          ? wranglerPkg.bin
          : wranglerPkg.bin?.wrangler || "bin/wrangler.js";
      const wranglerBin = path.resolve(
        path.dirname(wranglerPkgPath),
        binRelativePath,
      );

      const distDir = fs.existsSync(path.resolve(process.cwd(), "out"))
        ? "out"
        : ".next";

      // 🛡️ FIX: Remove heavy Turbopack compiler cache so files stay under Cloudflare's 25MB limit
      const nextCacheDir = path.resolve(process.cwd(), ".next", "cache");
      if (fs.existsSync(nextCacheDir)) {
        await fs.remove(nextCacheDir);
      }

      // 🛡️ Stop spinner and stream live Wrangler logs directly to terminal
      uploadSpinner.stop();
      console.log(DIM(`  --- Live Edge Logs (Project: ${cfProject}) ---`));

      execSync(
        `node ${wranglerBin} pages deploy ${distDir} --project-name=${cfProject} --branch=main --commit-dirty=true`,
        {
          stdio: "inherit", // 👈 INHERIT STREAMS EVERYTHING LIVE TO YOUR TERMINAL
          env: {
            ...process.env,
            CLOUDFLARE_API_TOKEN: token,
            CLOUDFLARE_ACCOUNT_ID: accountId,
            NO_COLOR: "1",
            CI: "true",
            NODE_OPTIONS: "--dns-result-order=ipv4first",
          },
        },
      );

      console.log(DIM("  ----------------------------------------------\n"));
      console.log(SUCCESS(`  ✔  Edge transfer complete (${cfProject})\n`));
    } catch (error: any) {
      console.error(ERR("\n✖ Edge transfer failed. See live logs above.\n"));
      process.exit(1);
    }

    // Finalize Deployment Record in Backend
    const finalize = ora("Finalizing managed deployment...").start();
    const complete = await nexusFetch(
      `${apiUrl}/devops/projects/${projectId}/deploy/complete`,
      apiKey,
      {
        method: "POST",
        timeout: 60000,
        body: {
          deploymentId,
          environment,
          status: "success",
          source: "apex-cli",
          artifact: { size: artifactSize, sha256 },
          git,
        },
      },
    );
    finalize.succeed(SUCCESS("Deployment accepted for managed release"));

    const finalData = complete?.data || complete;
    const liveUrl =
      finalData?.liveUrl ||
      projectData?.liveUrl ||
      (projectData?.subdomain
        ? `https://${projectData.subdomain}.gnapex.com`
        : undefined);

    console.log(
      chalk.gray("\n  ─────────────────────────────────────────────────────"),
    );
    console.log(
      `  ${SUCCESS("✔")}  GN-Apex deployment pipeline is now running.`,
    );
    console.log(
      `  Deployment ID: ${chalk.bold.white(deploymentId.slice(0, 16))}...`,
    );
    if (liveUrl) {
      console.log(
        `  🌍  ${chalk.bold.white("Live URL:")}  ${chalk.bold.cyan(liveUrl)}`,
      );
    }
    console.log(
      DIM(
        "  Your application remains inside the GN-Apex deployment experience. No third-party account login was requested or opened.",
      ),
    );
    console.log(
      chalk.gray("  ─────────────────────────────────────────────────────\n"),
    );
  } catch (error: any) {
    renderApexError(error);
    process.exitCode = 1;
  } finally {
    await artifact?.cleanup();
    const cleanupPaths = [
      wranglerPath,
      wranglerTomlPath,
      openNextPath,
      dotWranglerPath,
      dotOpenNextPath,
    ];
    for (const p of cleanupPaths) {
      try {
        if (await fs.pathExists(p)) await fs.remove(p);
      } catch {}
    }
  }
}

function isStaticExport() {
  for (const f of ["next.config.ts", "next.config.mjs", "next.config.js"]) {
    try {
      const c = fs.readFileSync(path.join(process.cwd(), f), "utf8");
      if (/output\s*[:=]\s*['"]export['"]/.test(c)) return true;
    } catch {}
  }
  return false;
}

// ─── LOCAL DATA MANAGEMENT NOTICE  ──────────────────────────────────
function printLocalManagementNotice() {
  printBanner("Local Workspace Manager");

  console.log(
    `  Your local staging database is fully compiled and secured inside the\n` +
      `  ${chalk.cyan(".nx/local/")} directory using cryptographic ${chalk.bold(".nx")} binary files.\n` +
      `  This keeps your local sandbox 100% secure and offline-ready.\n`,
  );

  const t = new Table({
    head: [chalk.bold.cyan("Command"), chalk.bold.cyan("Description")],
    style: { head: [], border: [] },
  });

  t.push(
    [
      chalk.white("npx apex local list"),
      DIM("Browse decrypted local pages, collections, and item counts"),
    ],
    [
      chalk.white("npx apex local init-templates"),
      DIM("Scaffold empty default files based on your schema.nx"),
    ],
    [
      chalk.white("npx apex local reset"),
      DIM("Purge all local data and reset files to empty schema defaults"),
    ],
    [
      chalk.white("npx apex studio"),
      DIM("Launch the interactive, visual offline Content Studio"),
    ],
  );

  console.log(t.toString() + "\n");
  console.log(
    `  ${WARN("💡  Tip:")} Run ${chalk.white("npx apex local list")} to inspect your current local directory.\n`,
  );
}

// ── LOCAL ──────────────────────────────────────────────────────────────────────
async function cmdLocal(sub: string, opts: any) {
  await assertInitialized();

  const { apiKey, projectId } = requireCredentials(opts);

  if (sub === "list") {
    printBanner("Local Data Browser");
    const local = await getLocalData(apiKey);
    let schema = null;
    try {
      schema = await readSchema(apiKey);
    } catch {}

    console.log(chalk.bold("\n  Pages\n"));
    for (const [slug, data] of Object.entries(local.pages)) {
      const pageSchema = schema?.pages?.find((p: any) => p.apiKey === slug);
      const label = pageSchema?.name || slug;
      console.log(`   • ${chalk.white(label)} ${DIM(`(slug: ${slug})`)}`);
    }

    console.log(chalk.bold("\n  Collections\n"));
    for (const [id, data] of Object.entries(local.collections)) {
      const colSchema = schema?.collections?.find((c: any) => c.apiKey === id);
      const label = colSchema?.name || id;
      console.log(
        `   • ${chalk.white(label)} ${DIM(`(id: ${id}, count: ${Array.isArray(data) ? data.length : 1})`)}`,
      );
    }
    console.log();
  } else if (sub === "init-templates") {
    const initSpinner = ora(
      "Generating missing local data templates...",
    ).start();
    let schema = null;
    try {
      schema = await readSchema(apiKey);
    } catch {}

    if (!schema) {
      initSpinner.fail(ERR("Missing schema.nx file. Pull first."));
      return;
    }

    let pagesCreated = 0,
      colsCreated = 0;

    for (const sp of schema.pages || []) {
      const localPagePath = path.join(
        process.cwd(),
        LOCAL_DATA_DIR,
        "pages",
        `${sp.apiKey}.nx`,
      );
      if (!(await fs.pathExists(localPagePath))) {
        const emptyPageData = buildEmptyFromSchema(sp.fields);
        await writeLocalData(
          "page",
          sp.apiKey,
          emptyPageData,
          apiKey,
          projectId,
        );
        pagesCreated++;
      }
    }

    for (const sc of schema.collections || []) {
      const localColPath = path.join(
        process.cwd(),
        LOCAL_DATA_DIR,
        "collections",
        `${sc.apiKey}.nx`,
      );
      if (!(await fs.pathExists(localColPath))) {
        const emptyColData = [buildEmptyFromSchema(sc.fields)];
        await writeLocalData(
          "collection",
          sc.apiKey,
          emptyColData,
          apiKey,
          projectId,
        );
        colsCreated++;
      }
    }

    initSpinner.succeed(
      SUCCESS(
        `Local data initialized: ${pagesCreated} pages, ${colsCreated} collections`,
      ),
    );
  } else if (sub === "reset") {
    printBanner("Local Data Reset");
    let schema = null;
    try {
      schema = await readSchema(apiKey);
    } catch {
      console.log(ERR("  No schema found.\n"));
      process.exit(1);
    }

    const { confirm } = await inquirer.prompt([
      {
        type: "confirm",
        name: "confirm",
        message: WARN(
          "This will reset all local data to empty schema values. Are you sure?",
        ),
        default: false,
      },
    ]);
    if (!confirm) {
      console.log(DIM("\n  Aborted.\n"));
      process.exit(0);
    }

    const s = ora("Resetting local data to schema defaults...").start();
    for (const node of schema.pages || []) {
      await writeLocalData(
        "page",
        node.apiKey,
        buildEmptyFromSchema(node.fields),
        apiKey,
        projectId,
      );
    }
    for (const node of schema.collections || []) {
      await writeLocalData(
        "collection",
        node.apiKey,
        [buildEmptyFromSchema(node.fields)],
        apiKey,
        projectId,
      );
    }
    s.succeed(SUCCESS("Local data reset to empty schema binary values"));
    console.log(DIM("  Run `npx apex pull` to re-populate from remote.\n"));
  }
}

// ── DOCTOR ────────────────────────────────────────────────────────────────────
async function cmdDoctor() {
  printBanner("CLI Health Check");

  const cwd = process.cwd();
  const checks = [];

  checks.push({
    label: "Node.js ≥ 18",
    ok: semver.gte(process.version, "18.0.0"),
    hint: "Upgrade Node.js",
  });
  checks.push({
    label: ".nx/ initialized",
    ok: await fs.pathExists(path.join(cwd, LOCK_FILE)),
    hint: "Run: npx apex init",
  });
  checks.push({
    label: "config.nx",
    ok: await fs.pathExists(path.join(cwd, CONFIG_FILE)),
    hint: "Re-run init",
  });
  checks.push({
    label: "schema.nx",
    ok: await fs.pathExists(path.join(cwd, SCHEMA_FILE)),
    hint: "Run: npx apex pull",
  });
  checks.push({
    label: ".env / credentials",
    ok: detectEnvFiles().length > 0,
    hint: "Create .env.local with GNAPEX_API_KEY and GNAPEX_PROJECT_ID",
  });

  loadEnv();
  checks.push({
    label: "GNAPEX_PROJECT_ID set",
    ok: !!(process.env.GNAPEX_PROJECT_ID || process.env.NEXT_PUBLIC_GNAPEX_ID),
    hint: "Add to .env.local",
  });
  checks.push({
    label: "GNAPEX_API_KEY set",
    ok: !!(process.env.GNAPEX_API_KEY || process.env.NEXT_PUBLIC_GNAPEX_KEY),
    hint: "Add to .env.local",
  });

  const pkg = tryReadJson(path.join(cwd, "package.json")) || {};
  const hasSdkInstalled = !!{ ...pkg.dependencies, ...pkg.devDependencies }[
    "@gnapex/sdk"
  ];
  checks.push({
    label: "@gnapex/sdk installed",
    ok: hasSdkInstalled,
    hint: "Run: npm add @gnapex/sdk",
  });

  console.log(chalk.bold("\n  Health Check Results\n"));
  let allOk = true;
  for (const c of checks) {
    if (!c.ok) allOk = false;
    console.log(
      `  ${c.ok ? SUCCESS("✔") : ERR("✖")}  ${c.ok ? chalk.white(c.label) : WARN(c.label)}${!c.ok ? DIM("  →  " + c.hint) : ""}`,
    );
  }

  if (allOk) {
    console.log(SUCCESS("\n  ✔  All checks passed. SDK is healthy.\n"));
  } else {
    const failed = checks.filter((c) => !c.ok).length;
    console.log(
      WARN(`\n  ${failed} issue(s) found. Address the items above.\n`),
    );
    process.exit(1);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CLI PROGRAM
// ─────────────────────────────────────────────────────────────────────────────

const program = new Command();

program
  .name("apex")
  .description("GN-Apex Production CLI")
  .version(GNAPEX_VERSION, "-V, --version", "Print SDK version")
  .addHelpText(
    "before",
    `\n${gradient(["#00D4FF", "#7B2FFF"])("GN-APEX")} ${chalk.white("Enterprise CLI")} ${DIM("v" + GNAPEX_VERSION)}\n`,
  );

program.hook("preAction", async (thisCommand, actionCommand) => {
  const name = actionCommand.name();
  if (!PRE_INIT_COMMANDS.has(name)) {
    await assertInitialized();
  }
});

program
  .command("init")
  .description("Initialize GN-Apex in your project (enterprise wizard)")
  .action(cmdInit);
program
  .command("pull")
  .description("Pull content & schema from remote to local cache")
  .option("-k, --api-key <key>", "API Key")
  .option("-p, --project-id <id>", "Project ID")
  .option("-u, --api-url <url>", "API URL")
  .option("-f, --force", "Overwrite existing cache")
  .option("--no-local", "Skip writing to .nx/local/")
  .action(async (opts) => {
    await cmdPull({ ...opts, writeLocal: opts.local });
  });
program
  .command("push")
  .description("Push local content to GN-Apex remote")
  .option("-k, --api-key <key>", "API Key")
  .option("-p, --project-id <id>", "Project ID")
  .option("-u, --api-url <url>", "API URL")
  .option("--dry-run", "Validate and preview without uploading")
  .option("-f, --force", "Push even if validation fails")
  .action(async (opts) => {
    await cmdPush(opts);
  });
program
  .command("validate")
  .description("Validate local data against the content schema")
  .action(cmdValidate);
program
  .command("diff")
  .description("Show pending local changes compared to upstream (git-like)")
  .action(async () => {
    await assertInitialized();
    await cmdDiff();
  });
program
  .command("schema")
  .description("Inspect the content schema")
  .option("-r, --refresh", "Re-fetch schema from remote")
  .option("--fields <apiKey>", "Show field details for a specific node")
  .option("-k, --api-key <key>", "API Key")
  .option("-p, --project-id <id>", "Project ID")
  .option("-u, --api-url <url>", "API URL")
  .action(async (opts) => {
    await cmdSchema(opts);
  });
program
  .command("types")
  .description("Generate TypeScript definitions from schema")
  .option("-o, --output <path>", "Output file (default: types/nexus.d.ts)")
  .option("-r, --refresh", "Re-fetch schema before generating")
  .option("-k, --api-key <key>", "API Key")
  .action(async (opts) => {
    await cmdTypes(opts);
  });
program
  .command("status")
  .description("Show project status and health")
  .option("-k, --api-key <key>", "API Key")
  .option("-p, --project-id <id>", "Project ID")
  .option("-u, --api-url <url>", "API URL")
  .action(async (opts) => {
    await cmdStatus(opts);
  });
program
  .command("deploy")
  .description("Deploy project to the GN-Apex Global Edge Network")
  .option(
    "-e, --environment <env>",
    "Environment (production|staging)",
    "production",
  )
  .option("-k, --api-key <key>", "API Key")
  .option("-p, --project-id <id>", "Project ID")
  .option("-u, --api-url <url>", "API URL")
  .action(async (opts) => {
    await cmdDeploy(opts);
  });
program
  .command("local [command]")
  .description("Manage local content data (list | init-templates | reset)")
  .action(async (sub, opts) => {
    if (!sub) {
      printLocalManagementNotice();
      return;
    }
    await cmdLocal(sub, opts);
  });
program
  .command("studio")
  .description("Spin up the local, offline Content Studio on GN-Apex Edge")
  .option("--port <port>", "Port to run the local server", "4646")
  .option("-k, --api-key <key>", "API Key")
  .option("-p, --project-id <id>", "Project ID")
  .option("-u, --api-url <url>", "API URL")
  .action(async (opts) => {
    await assertInitialized();
    await cmdStudio(opts);
  });
program
  .command("doctor")
  .description("Diagnose SDK setup issues")
  .action(cmdDoctor);
program
  .command("seed")
  .description("Alias for `push` — seeds local content to remote")
  .option("-k, --api-key <key>", "API Key")
  .option("-p, --project-id <id>", "Project ID")
  .option("--dry-run", "Preview without uploading")
  .action(async (opts) => {
    await cmdPush(opts);
  });

program.parse(process.argv);
