// packages/client-sdk/tools/cli.ts
import { Command } from "commander";
import fs from "fs-extra";
import path from "path";
import fetch from "node-fetch";
import dotenv from "dotenv";
import chalk from "chalk";
import ora from "ora";
// Load environment variables
dotenv.config({ path: path.resolve(process.cwd(), ".env.local") });
dotenv.config({ path: path.resolve(process.cwd(), ".env") });
const program = new Command();
program.name("nexus").description("GnApex CLI Tool").version("1.0.0");
program
  .command("pull")
  .description("Pull latest content from GnApex to local cache")
  .option("-k, --api-key <key>", "GnApex API Key")
  .option("-p, --project-id <id>", "GnApex Project ID")
  .option("-u, --api-url <url>", "GnApex API URL")
  .option("-o, --output <path>", "Output directory (default: .nexus)")
  .option("-f, --force", "Force overwrite existing cache")
  .action(syncContent);
program
  .command("seed")
  .description("Seed content from local files to GnApex")
  .option("-i, --input <path>", "Input directory (default: .nexus/seed)")
  .option("-p, --project-id <id>", "GnApex Project ID")
  .option("-k, --api-key <key>", "GnApex API Key")
  .option("-u, --api-url <url>", "GnApex API URL")
  .option("--dry-run", "Validate seed data without uploading")
  .action(seedContent);
program
  .command("deploy")
  .description("Trigger a production deployment")
  .option("-p, --project-id <id>", "GnApex Project ID")
  .option("-k, --api-key <key>", "GnApex API Key")
  .option("-u, --api-url <url>", "GnApex API URL")
  .option("-e, --environment <env>", "Deployment environment", "production")
  .action(triggerDeploy);
program
  .command("status")
  .description("Check project status and content statistics")
  .option("-p, --project-id <id>", "GnApex Project ID")
  .option("-k, --api-key <key>", "GnApex API Key")
  .option("-u, --api-url <url>", "GnApex API URL")
  .action(checkStatus);
program
  .command("init")
  .description("Initialize GnApex in your project")
  .action(initProject);
async function syncContent(options) {
  console.log(chalk.bold.cyan("\n🚀 GnApex CLI - Content Sync\n"));
  const apiKey =
    options.apiKey ||
    process.env.NEXUS_API_KEY ||
    process.env.NEXT_PUBLIC_NEXUS_KEY;
  const projectId =
    options.projectId ||
    process.env.NEXUS_PROJECT_ID ||
    process.env.NEXT_PUBLIC_NEXUS_ID;
  const apiUrl =
    options.apiUrl ||
    process.env.NEXUS_API_URL ||
    process.env.NEXT_PUBLIC_NEXUS_API_URL ||
    "https://api.nexushub.com/v1";
  const outputDir = options.output || ".nexus";
  if (!apiKey || !projectId) {
    console.error(chalk.red("❌ Missing API Key or Project ID"));
    console.log(
      chalk.gray(
        "Set NEXUS_API_KEY and NEXUS_PROJECT_ID in .env or use --api-key and --project-id flags",
      ),
    );
    process.exit(1);
  }
  const spinner = ora(
    `Fetching content for project: ${chalk.green(projectId)}...`,
  ).start();
  try {
    // Check if cache exists and prompt for confirmation
    const cacheDir = path.join(process.cwd(), outputDir);
    const cacheFile = path.join(cacheDir, "cache.json");
    if (fs.existsSync(cacheFile) && !options.force) {
      spinner.stop();
      console.log(
        chalk.yellow(
          "⚠️  Cache file already exists. Use --force to overwrite.",
        ),
      );
      process.exit(0);
    }
    // Fetch all content types
    const [pages, collections, globals] = await Promise.all([
      fetchWithAuth(`${apiUrl}/content/${projectId}/pages`, apiKey),
      fetchCollections(`${apiUrl}/content/${projectId}`, apiKey, projectId),
      fetchWithAuth(`${apiUrl}/projects/${projectId}/globals`, apiKey),
    ]);
    // Structure data for cache
    const cacheData = {
      pages: pages.data || pages,
      collections,
      globals: globals.data || globals,
      meta: {
        pulledAt: new Date().toISOString(),
        projectId,
        apiUrl,
        count: {
          pages: (pages.data || pages).length,
          collections: Object.keys(collections).length,
        },
      },
    };
    // Write to .nexus/cache.json
    await fs.ensureDir(cacheDir);
    await fs.writeJson(cacheFile, cacheData, { spaces: 2 });
    spinner.succeed(chalk.green("Content synced successfully!"));
    console.log(chalk.gray(`   📁 Saved to: ${cacheFile}`));
    console.log(chalk.gray(`   📊 Pages: ${cacheData.meta.count.pages}`));
    console.log(
      chalk.gray(`   📚 Collections: ${cacheData.meta.count.collections}`),
    );
    console.log(chalk.yellow(`   ⚡ Mode: Offline / Local Cache Enabled`));
  } catch (error) {
    spinner.fail(chalk.red("Failed to sync content"));
    console.error(chalk.red(`   Error: ${error.message}`));
    if (error.message.includes("401") || error.message.includes("403")) {
      console.log(chalk.yellow("   🔑 Check your API key and permissions"));
    } else if (error.message.includes("404")) {
      console.log(
        chalk.yellow("   🔍 Project not found. Check your project ID"),
      );
    }
    process.exit(1);
  }
}
async function fetchWithAuth(url, apiKey) {
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "User-Agent": "GnApex-CLI/1.0.0",
    },
    timeout: 30000, // 30 second timeout
  });
  if (!response.ok) {
    throw new Error(`API Error ${response.status}: ${response.statusText}`);
  }
  return response.json();
}
async function fetchCollections(baseUrl, apiKey, projectId) {
  // First get all collections
  const collectionsRes = await fetch(`${baseUrl}/collections`, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
  });
  if (!collectionsRes.ok) {
    return {};
  }
  const collections = await collectionsRes.json();
  const result = {};
  // Fetch items for each collection (with concurrency limit)
  const MAX_CONCURRENT = 3;
  const chunks = [];
  for (let i = 0; i < collections.data.length; i += MAX_CONCURRENT) {
    chunks.push(collections.data.slice(i, i + MAX_CONCURRENT));
  }
  for (const chunk of chunks) {
    await Promise.all(
      chunk.map(async (collection) => {
        try {
          const itemsRes = await fetch(
            `${baseUrl}/collections/${collection.id}/items?limit=1000`,
            {
              headers: {
                Authorization: `Bearer ${apiKey}`,
                "Content-Type": "application/json",
              },
            },
          );
          if (itemsRes.ok) {
            const itemsData = await itemsRes.json();
            result[collection.slug || collection.id] =
              itemsData.data || itemsData.items || [];
          }
        } catch (error) {
          console.warn(
            chalk.yellow(
              `⚠️  Failed to fetch collection ${collection.id}:`,
              error,
            ),
          );
        }
      }),
    );
  }
  return result;
}
async function seedContent(options) {
  console.log(chalk.bold.cyan("\n🌱 GnApex CLI - Content Seeding\n"));
  const apiKey = options.apiKey || process.env.NEXUS_API_KEY;
  const projectId = options.projectId || process.env.NEXUS_PROJECT_ID;
  const apiUrl =
    options.apiUrl ||
    process.env.NEXUS_API_URL ||
    "https://api.nexushub.com/v1";
  const inputDir = options.input || ".nexus/seed";
  const dryRun = options.dryRun || false;
  if (!apiKey || !projectId) {
    console.error(chalk.red("❌ Missing API Key or Project ID"));
    process.exit(1);
  }
  const seedPath = path.join(process.cwd(), inputDir);
  if (!fs.existsSync(seedPath)) {
    console.error(chalk.red(`❌ Seed directory not found: ${seedPath}`));
    console.log(chalk.gray("Create a seed directory with your content files:"));
    console.log(chalk.gray("  mkdir -p .nexus/seed"));
    console.log(
      chalk.gray("  # Add pages.json, collections/ folder, globals.json"),
    );
    process.exit(1);
  }
  const spinner = ora("Validating seed data...").start();
  try {
    // Read seed files
    const pagesFile = path.join(seedPath, "pages.json");
    const collectionsDir = path.join(seedPath, "collections");
    const globalsFile = path.join(seedPath, "globals.json");
    let pageCount = 0;
    let collectionCount = 0;
    let itemCount = 0;
    if (fs.existsSync(pagesFile)) {
      const pages = await fs.readJson(pagesFile);
      pageCount = pages.length;
      if (!dryRun) {
        spinner.text = `Seeding ${pages.length} pages...`;
        await seedPages(pages, apiUrl, projectId, apiKey);
      }
    }
    if (fs.existsSync(collectionsDir)) {
      if (!dryRun) {
        spinner.text = "Seeding collections...";
        const counts = await seedCollections(
          collectionsDir,
          apiUrl,
          projectId,
          apiKey,
        );
        collectionCount = counts.collections;
        itemCount = counts.items;
      } else {
        const files = await fs.readdir(collectionsDir);
        collectionCount = files.filter((f) => f.endsWith(".json")).length;
      }
    }
    if (fs.existsSync(globalsFile)) {
      const globals = await fs.readJson(globalsFile);
      if (!dryRun) {
        spinner.text = "Seeding globals...";
        await seedGlobals(globals, apiUrl, projectId, apiKey);
      }
    }
    if (dryRun) {
      spinner.succeed(chalk.green("Seed data validated successfully!"));
      console.log(chalk.gray(`   📄 Pages: ${pageCount}`));
      console.log(chalk.gray(`   📚 Collections: ${collectionCount}`));
      console.log(chalk.gray(`   📦 Items: ${itemCount}`));
    } else {
      spinner.succeed(chalk.green("Content seeded successfully!"));
    }
  } catch (error) {
    spinner.fail(chalk.red("Failed to seed content"));
    console.error(chalk.red(`   Error: ${error.message}`));
    process.exit(1);
  }
}
async function seedPages(pages, apiUrl, projectId, apiKey) {
  const results = [];
  for (const page of pages) {
    try {
      const response = await fetch(`${apiUrl}/content/${projectId}/pages`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(page),
      });
      if (response.ok) {
        results.push({ slug: page.slug, success: true });
      } else {
        results.push({
          slug: page.slug,
          success: false,
          error: response.statusText,
        });
      }
    } catch (error) {
      results.push({ slug: page.slug, success: false, error: error.message });
    }
  }
  // Log results
  const successful = results.filter((r) => r.success);
  const failed = results.filter((r) => !r.success);
  if (failed.length > 0) {
    console.warn(chalk.yellow(`   ⚠️  ${failed.length} pages failed:`));
    failed.forEach((f) => {
      console.log(chalk.gray(`     - ${f.slug}: ${f.error}`));
    });
  }
}
async function seedCollections(collectionsDir, apiUrl, projectId, apiKey) {
  const files = await fs.readdir(collectionsDir);
  const jsonFiles = files.filter((f) => f.endsWith(".json"));
  let totalItems = 0;
  for (const file of jsonFiles) {
    const collectionName = path.basename(file, ".json");
    const filePath = path.join(collectionsDir, file);
    const items = await fs.readJson(filePath);
    // First create collection
    try {
      await fetch(`${apiUrl}/content/${projectId}/collections`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: collectionName,
          slug: collectionName,
          description: `Auto-generated from seed data`,
        }),
      });
      // Then seed items
      let itemCount = 0;
      for (const item of items) {
        try {
          await fetch(
            `${apiUrl}/content/${projectId}/collections/${collectionName}/items`,
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${apiKey}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify(item),
            },
          );
          itemCount++;
        } catch (error) {
          console.warn(
            chalk.yellow(`     Failed to create item in ${collectionName}`),
          );
        }
      }
      console.log(
        chalk.gray(
          `   ✅ Created collection ${collectionName} with ${itemCount} items`,
        ),
      );
      totalItems += itemCount;
    } catch (error) {
      console.warn(
        chalk.yellow(
          `   ❌ Failed to create collection ${collectionName}: ${error.message}`,
        ),
      );
    }
  }
  return { collections: jsonFiles.length, items: totalItems };
}
async function seedGlobals(globals, apiUrl, projectId, apiKey) {
  try {
    await fetch(`${apiUrl}/projects/${projectId}/globals`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(globals),
    });
    console.log(chalk.gray("   ✅ Created globals"));
  } catch (error) {
    console.warn(
      chalk.yellow(`   ❌ Failed to create globals: ${error.message}`),
    );
  }
}
async function triggerDeploy(options) {
  console.log(chalk.bold.cyan("\n🚀 GnApex CLI - Trigger Deployment\n"));
  const apiKey = options.apiKey || process.env.NEXUS_API_KEY;
  const projectId = options.projectId || process.env.NEXUS_PROJECT_ID;
  const apiUrl =
    options.apiUrl ||
    process.env.NEXUS_API_URL ||
    "https://api.nexushub.com/v1";
  const environment = options.environment || "production";
  if (!apiKey || !projectId) {
    console.error(chalk.red("❌ Missing API Key or Project ID"));
    process.exit(1);
  }
  const spinner = ora(`Triggering ${environment} deployment...`).start();
  try {
    const response = await fetch(`${apiUrl}/projects/${projectId}/deploy`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        environment,
        trigger: "cli",
        timestamp: new Date().toISOString(),
      }),
    });
    if (response.ok) {
      const data = await response.json();
      spinner.succeed(chalk.green("Deployment triggered successfully!"));
      console.log(chalk.gray(`   🔗 Deployment ID: ${data.deploymentId}`));
      console.log(chalk.gray(`   🌍 Environment: ${environment}`));
      console.log(
        chalk.gray(`   ⏰ Started at: ${new Date().toLocaleTimeString()}`),
      );
    } else {
      throw new Error(`API Error ${response.status}: ${response.statusText}`);
    }
  } catch (error) {
    spinner.fail(chalk.red("Failed to trigger deployment"));
    console.error(chalk.red(`   Error: ${error.message}`));
    process.exit(1);
  }
}
async function checkStatus(options) {
  console.log(chalk.bold.cyan("\n📊 GnApex CLI - Project Status\n"));
  const apiKey = options.apiKey || process.env.NEXUS_API_KEY;
  const projectId = options.projectId || process.env.NEXUS_PROJECT_ID;
  const apiUrl =
    options.apiUrl ||
    process.env.NEXUS_API_URL ||
    "https://api.nexushub.com/v1";
  if (!apiKey || !projectId) {
    console.error(chalk.red("❌ Missing API Key or Project ID"));
    process.exit(1);
  }
  const spinner = ora("Fetching project status...").start();
  try {
    const response = await fetch(`${apiUrl}/projects/${projectId}/status`, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
    });
    if (response.ok) {
      const data = await response.json();
      spinner.succeed(chalk.green("Project status retrieved!"));
      console.log(chalk.gray(`   📋 Project: ${data.project.name}`));
      console.log(chalk.gray(`   🆔 ID: ${data.project.id}`));
      console.log(chalk.gray(`   📄 Pages: ${data.stats.pages}`));
      console.log(chalk.gray(`   📚 Collections: ${data.stats.collections}`));
      console.log(chalk.gray(`   👥 Users: ${data.stats.users}`));
      console.log(
        chalk.gray(
          `   🕒 Last Updated: ${new Date(data.project.updatedAt).toLocaleString()}`,
        ),
      );
    } else {
      throw new Error(`API Error ${response.status}: ${response.statusText}`);
    }
  } catch (error) {
    spinner.fail(chalk.red("Failed to fetch project status"));
    console.error(chalk.red(`   Error: ${error.message}`));
    process.exit(1);
  }
}
async function initProject() {
  console.log(chalk.bold.cyan("\n🎯 GnApex CLI - Project Initialization\n"));
  // Create .nexus directory
  const nexusDir = path.join(process.cwd(), ".nexus");
  const seedDir = path.join(nexusDir, "seed");
  const collectionsDir = path.join(seedDir, "collections");
  try {
    await fs.ensureDir(collectionsDir);
    // Create example files
    const examplePages = [
      {
        slug: "home",
        title: "Welcome to Our Site",
        content: "This is the home page content.",
        seo: {
          title: "Home Page",
          description: "Welcome to our amazing website",
        },
      },
      {
        slug: "about",
        title: "About Us",
        content: "Learn more about our company.",
        seo: {
          title: "About Page",
          description: "Learn about our company and mission",
        },
      },
    ];
    const exampleCollection = [
      {
        title: "First Blog Post",
        content: "This is the content of the first blog post.",
        author: "Admin",
        published: true,
      },
      {
        title: "Second Blog Post",
        content: "This is another blog post example.",
        author: "Admin",
        published: true,
      },
    ];
    const exampleGlobals = {
      siteName: "My Awesome Site",
      navigation: [
        { label: "Home", href: "/" },
        { label: "About", href: "/about" },
      ],
      footer: {
        copyright: "© 2024 My Site",
      },
    };
    // Write example files
    await fs.writeJson(path.join(seedDir, "pages.json"), examplePages, {
      spaces: 2,
    });
    await fs.writeJson(
      path.join(collectionsDir, "blog_posts.json"),
      exampleCollection,
      { spaces: 2 },
    );
    await fs.writeJson(path.join(seedDir, "globals.json"), exampleGlobals, {
      spaces: 2,
    });
    // Create .gitignore
    const gitignorePath = path.join(nexusDir, ".gitignore");
    await fs.writeFile(gitignorePath, "cache.json\n");
    // Create README
    const readmePath = path.join(nexusDir, "README.md");
    const readmeContent = `# GnApex Content Seed

This directory contains seed data for your GnApex project.

## Structure

- \`pages.json\` - Static pages (home, about, contact, etc.)
- \`collections/\` - Dynamic content collections
- \`globals.json\` - Global site settings

## Usage

1. Edit the seed files with your content
2. Run \`npx apex seed\` to upload to GnApex
3. Run \`npx apex pull\` to sync content locally

## Notes

- The \`cache.json\` file is ignored by git (contains local copies)
- Use the CLI to keep content in sync between local and production
`;
    await fs.writeFile(readmePath, readmeContent);
    console.log(chalk.green("✅ Project initialized successfully!"));
    console.log(chalk.gray("\n📁 Created directory structure:"));
    console.log(chalk.gray(`   ${nexusDir}/`));
    console.log(chalk.gray(`   ├── seed/`));
    console.log(chalk.gray(`   │   ├── pages.json (example pages)`));
    console.log(chalk.gray(`   │   ├── collections/`));
    console.log(chalk.gray(`   │   │   └── blog_posts.json (example)`));
    console.log(chalk.gray(`   │   └── globals.json (site settings)`));
    console.log(chalk.gray(`   ├── .gitignore`));
    console.log(chalk.gray(`   └── README.md`));
    console.log(chalk.yellow("\n🚀 Next steps:"));
    console.log(chalk.gray("   1. Edit the seed files with your content"));
    console.log(chalk.gray("   2. Set your API credentials in .env:"));
    console.log(chalk.gray("      NEXUS_API_KEY=your_key_here"));
    console.log(chalk.gray("      NEXUS_PROJECT_ID=your_project_id_here"));
    console.log(chalk.gray("   3. Run \`npx apex seed\` to upload content"));
  } catch (error) {
    console.error(
      chalk.red(`❌ Failed to initialize project: ${error.message}`),
    );
    process.exit(1);
  }
}
program.parse(process.argv);
