# GN-Apex SDK — Security Architecture & Audit Wiki

> Internal engineering reference. Companion to `SECURITY.md` (the public-facing policy). This page tracks _why_ the current design looks the way it does, where its trust boundaries sit, and the open findings from the September 2026 audit of v1.1.0.

---

## 1. Purpose

`SECURITY.md` tells integrators what to do. This page is for maintainers: it explains the trust model, documents how the audit was performed so it can be re-run, and tracks findings to closure.

---

## 2. Trust boundaries

The SDK spans three trust zones that are easy to blur because "zero-config" means a lot happens automatically:

1. **Browser runtime (untrusted environment).** Anything running here — analytics, fingerprinting, rich-text rendering, auth session checks — executes in a context the end user (or a malicious script on the same page) can inspect and influence. Secrets must never live here beyond the public key.
2. **GN-Apex/Cloudflare edge (semi-trusted).** Owns cache purge and invalidation; the SDK treats its responses as authoritative for content freshness.
3. **Local filesystem / CLI environment (trusted, developer-only).** `LocalCache`, `BinaryCompiler`, and the CLI tooling assume a trusted developer machine or CI runner — but the arguments passed into them (slugs, collection IDs) may still originate from request-time, untrusted input if a calling app forwards them carelessly. This is the boundary finding #2 below crosses.

---

## 3. Component notes

### Analytics & fingerprinting (`src/analytics/`)

Automatic canvas fingerprinting (`fingerprint.ts`) plus persistent `localStorage`-backed visitor IDs are on by default with no opt-out surfaced to the integrator. This is a deliberate product choice (stable anonymous identity without cookies), but it means every GN-Apex site ships browser fingerprinting on page one unless the integrator intervenes. Combined with `AuthProvider` auto-calling `identify()` with the user's email on session rehydration, personal data flows into analytics with zero explicit consent step.

### Content rendering (`src/components/NexusRenders.tsx`)

`NexusRichText` and `NexusLongText` are the documented, "zero-config" way to render CMS field values, and both use raw `dangerouslySetInnerHTML`. There is no sanitization library in the dependency tree (`grep` for `sanitiz|dompurify|xss` across `src/` returns nothing). This is fine only as long as every value that ever reaches these components is written exclusively by trusted CMS admins — a constraint the SDK doesn't enforce or even document today.

### Local cache & binary format (`src/content/`)

`BinaryCompiler` wraps content in AES-256-CBC with an HMAC-SHA256 integrity signature, keyed by `sha256(apiKey)`. Read this as **tamper-detection**, not confidentiality: the key is deterministic from a single secret with no per-install salt or KDF (no PBKDF2/scrypt/HKDF), so anyone with the API key can derive the same key. That's an acceptable trade-off for its actual job (catch corrupted/tampered local `.nx` files) but the code comments ("secure," "cryptographic integrity") oversell it as a confidentiality boundary, which has previously led people to assume it protects content from anyone without the key. It doesn't.

`LocalCache.getPage(slug)` / `getCollection(collectionId)` build filesystem paths by directly interpolating the argument (`path.resolve(cwd, baseDir, "pages", \`${slug}.nx\`)`). No character allowlist. If a calling app does something like `nexus.getPage(params.slug)` in a catch-all route — the exact pattern the README recommends — an unvalidated path segment reaches the filesystem layer.

### Auth (`src/auth/context.tsx`)

Uses the public per-project key as a bearer token for identifying the _project_, with the comment confirming session identity is intentionally handled by the backend via cookies or public tokens rather than a master key in the browser — a sound separation of concerns. Not independently verified in this audit: whether cross-origin `fetch` calls to `config.apiUrl` correctly carry session cookies (no `credentials: "include"` was observed in `getHeaders()`-driven requests). Worth confirming against your actual domain topology (same-site proxy vs. cross-origin API host) rather than assuming it works.

### HTTP resilience (`src/http.ts`, `src/content/strategies.ts`)

Good design in most respects: `ExponentialBackoff` correctly declines to retry non-retryable `4xx` (except `429`), requests carry IDs, timeouts abort cleanly. The gap is `CircuitBreaker.recordFailure()` being called unconditionally in `http.ts`'s catch block — it doesn't distinguish a `404` from a `NETWORK_ERROR` from a `500`. Default threshold is 5 failures / 30s reset, so five unrelated 404s (broken links, bots) will open the circuit for everyone.

---

## 4. Audit findings log

| ID    | Severity | Area              | Summary                                                                                                                                                                             | Status                                                                               |
| ----- | -------- | ----------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| SEC-1 | High     | Content rendering | Unsanitized `dangerouslySetInnerHTML` in `NexusRichText`/`NexusLongText`; no sanitizer in the dependency tree.                                                                      | Open — mitigation documented in `SECURITY.md`                                        |
| SEC-2 | Medium   | Local cache       | Unvalidated `slug`/`collectionId` interpolated into filesystem paths; path traversal exposure if caller forwards raw input.                                                         | Open — mitigation documented in `SECURITY.md`                                        |
| SEC-3 | Medium   | Analytics/privacy | Canvas fingerprinting + auto `identify()` with email, on by default, no consent gate.                                                                                               | Open — product decision needed, not just a code fix                                  |
| SEC-4 | Medium   | HTTP layer        | Circuit breaker counts 404s as failures, can trip on normal traffic.                                                                                                                | Open — fix is well-scoped (filter by status/error type in `recordFailure` call site) |
| SEC-5 | Low      | Crypto messaging  | `BinaryCompiler` docstrings describe an unsalted `sha256(apiKey)` key derivation as "secure," overstating its confidentiality guarantee versus its actual role as tamper-detection. | Open — documentation-only fix                                                        |
| SEC-6 | Low      | Auth              | Unconfirmed whether session cookies survive cross-origin `fetch` calls in `context.tsx` (no `credentials: "include"` observed).                                                     | Needs verification against real deployment topology                                  |

---

## 5. How this audit was performed (reproducible)

From a clean extraction of the package:

```bash
npm install
npm run type-check      # passed clean
npm run test:coverage   # failed to even start — jest.config.js uses
                         # module.exports under "type": "module"
# after renaming jest.config.js -> jest.config.cjs:
npx jest --coverage --config jest.config.cjs
                         # 6/6 suites failed, 18/61 tests failed,
                         # ~36% coverage vs. an 80% configured threshold
npm run build            # fails: references ../app/studio, not present
                         # in this package's own zip
npx tsup                 # tsup alone builds clean (ESM+CJS+d.ts)
```

Source-level checks:

```bash
grep -rn "dangerouslySetInnerHTML" src
grep -rni "sanitiz|dompurify|xss" src package.json   # no hits
grep -rniE "TODO|FIXME|HACK" src                     # no hits
```

Re-run these before signing off on any future release — a prior green build does not guarantee the current source passes, given finding SEC-4's root config was silently broken.

---

## 6. Fix roadmap (suggested priority)

1. **SEC-1 (XSS)** and **SEC-4 (circuit breaker)** — both are narrow, well-understood code fixes with outsized blast radius. Fix first.
2. **SEC-2 (path traversal)** — add slug validation at the `LocalCache` boundary.
3. **Test infra** — fix `jest.config.js` → `.cjs` (or convert to ESM config), then treat the 80% threshold as a real CI gate, not an aspirational number.
4. **SEC-3 (consent)** — needs a product/legal decision on default-on fingerprinting before it's a pure engineering task.
5. **SEC-5 / SEC-6** — documentation and verification, respectively; low effort, do opportunistically.
