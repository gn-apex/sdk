// tsup.config.ts
import { defineConfig } from "tsup";

export default defineConfig([
  // ─── Build 1: Core client ─────────────────────────
  {
    entry: [
      "src/index.ts",
      "src/content/local-cache-server.ts",
      "src/content/local-cache-client.ts",
      "src/content/binary-compiler.ts",
    ],
    format: ["esm", "cjs"],
    dts: true,
    clean: true,
    splitting: false,
    minify: false,
    external: [
      "react",
      "react-dom",
      "next",
      /^next\/.*/,
      "fs",
      "path",
      "os",
      "crypto",
    ],
  },

  // ─── Build 2: React entrypoint ───────────────────
  {
    entry: ["src/react.ts"],
    format: ["esm", "cjs"],
    dts: true,
    clean: false,
    splitting: true,
    minify: false,
    external: [
      "react",
      "react-dom",
      "next",
      /^next\/.*/,
      "fs",
      "path",
      "os",
      "crypto",
    ],
  },

  // ─── Build 3: Standalone CLI tool ─────────────────
  {
    entry: ["tools/cli.ts"],
    format: ["cjs"],
    platform: "node",
    // 🛡️ Bundle CLI libraries so npx apex runs standalone on any computer
    noExternal: [
      "chalk",
      "ora",
      "node-fetch",
      "figlet",
      "gradient-string",
      "inquirer",
      "cli-table3",
      "commander",
      "semver",
      "fs-extra",
      "dotenv",
    ],
    minify: true,
    banner: {
      js: "#!/usr/bin/env node",
    },
  },
]);
